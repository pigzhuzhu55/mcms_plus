/*   */ package com.baidu.ueditor.define;
/*   */ 
/*   */ public enum ActionState {
/* 4 */   UNKNOW_ERROR;
/*   */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-ueditor\1.0.4\ms-ueditor-1.0.4.jar!\com\baid\\ueditor\define\ActionState.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */