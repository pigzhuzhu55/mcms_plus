/*    */ package com.baidu.ueditor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class App
/*    */ {
/* 11 */   public static void main(String[] args) { System.out.println("Hello World!"); }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-ueditor\1.0.4\ms-ueditor-1.0.4.jar!\com\baid\\ueditor\App.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */