/*     */ package net.mingsoft.upgrade.action;
/*     */ 
/*     */ import cn.hutool.core.io.FileUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import cn.hutool.http.HttpRequest;
/*     */ import cn.hutool.http.HttpUtil;
/*     */ import com.alibaba.druid.pool.DruidDataSource;
/*     */ import io.swagger.annotations.ApiOperation;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.zip.ZipException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.base.entity.ResultJson;
/*     */ import net.mingsoft.basic.action.BasicAction;
/*     */ import net.mingsoft.basic.biz.IModelBiz;
/*     */ import net.mingsoft.basic.biz.IRoleModelBiz;
/*     */ import net.mingsoft.basic.entity.ModelEntity;
/*     */ import net.mingsoft.basic.entity.RoleModelEntity;
/*     */ import net.mingsoft.basic.util.BasicUtil;
/*     */ import net.mingsoft.basic.util.SpringUtil;
/*     */ import net.mingsoft.basic.util.StringUtil;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.client.ClientProtocolException;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.conn.HttpHostConnectException;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.impl.client.HttpClients;
/*     */ import org.apache.ibatis.jdbc.ScriptRunner;
/*     */ import org.apache.tools.zip.ZipEntry;
/*     */ import org.apache.tools.zip.ZipFile;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.annotation.Value;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.bind.annotation.PostMapping;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.RequestMethod;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import springfox.documentation.annotations.ApiIgnore;
/*     */ 
/*     */ @Controller("upgrader")
/*     */ @RequestMapping({"/${ms.manager.path}/upgrader"})
/*     */ public class UpgraderAction
/*     */   extends BasicAction {
/*  66 */   private String html = "<html><head><title>价值源自分享！</title></head><body style=\"padding-top: 5%;background-color: #ffffff;\"><center>\t<img src=\"http://cdn.mingsoft.net/global/mstore/{result/}.png\" />\t<div>\t\t<p style=\"clear: both; margin: 30px auto 20px auto; line-height: 35px; font-size: 20px; color: #7e7e7e;\">{message/}</p>\t</div></center></body></html>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Value("${ms.mstore.http:http://store.mingsoft.net}")
/*     */   private String MS_MSTORE_HTTP;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Value("${ms.mstore.host:store.mingsoft.net}")
/*     */   private String MS_MSTORE_HOST;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Autowired
/*     */   private IModelBiz modelBiz;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Autowired
/*     */   private IRoleModelBiz roleModelBiz;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ResponseBody
/*     */   @RequestMapping(value = {"/sync"}, method = {RequestMethod.GET})
/*     */   public void sync(HttpServletRequest request, HttpServletResponse response) {
/* 100 */     String sync = ((HttpRequest)HttpUtil.createPost(this.MS_MSTORE_HTTP + "/mstore/sync.do").header("ms", "upgrader")).execute().body();
/* 101 */     outJson(response, sync);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void reModel(ModelEntity modelParent, String parentIds, int mangerRoleId, List<RoleModelEntity> roleModels, int parentId) {
/* 113 */     modelParent.setModelIsMenu((ObjectUtil.isNotNull(modelParent.getModelChildList()) && modelParent.getModelChildList().size() > 0) ? 
/* 114 */         Integer.valueOf(1) : Integer.valueOf(0));
/*     */     
/* 116 */     modelParent.setModelModelId(parentId);
/* 117 */     modelParent.setModelDatetime(new Timestamp(System.currentTimeMillis()));
/* 118 */     modelParent.setModelParentIds(parentIds);
/* 119 */     ModelEntity modelParentEntity = this.modelBiz.getEntityByModelCode(modelParent.getModelCode());
/* 120 */     if (modelParentEntity == null) {
/* 121 */       this.modelBiz.saveEntity((BaseEntity)modelParent);
/* 122 */       RoleModelEntity roleModel = new RoleModelEntity();
/* 123 */       roleModel.setRoleId(mangerRoleId);
/* 124 */       roleModel.setModelId(modelParent.getModelId());
/* 125 */       roleModels.add(roleModel);
/*     */     } else {
/* 127 */       modelParent.setModelId(modelParentEntity.getModelId());
/* 128 */       this.modelBiz.updateEntity((BaseEntity)modelParent);
/*     */     } 
/* 130 */     if (ObjectUtil.isNotNull(modelParent.getModelChildList()) && modelParent.getModelChildList().size() > 0) {
/* 131 */       for (ModelEntity modelEntity : modelParent.getModelChildList()) {
/* 132 */         reModel(modelEntity, StringUtils.isBlank(parentIds) ? (modelParent.getModelId() + "") : (parentIds + "," + modelParent.getModelId()), mangerRoleId, roleModels, modelParent.getModelId());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @ApiOperation("菜单导入接口")
/*     */   @PostMapping({"/import"})
/*     */   public void importMenu(String menuStr, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 140 */     if (StringUtils.isBlank(menuStr)) {
/* 141 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("menu") }));
/*     */       return;
/*     */     } 
/* 144 */     this.modelBiz.jsonToModel(menuStr, getManagerBySession(request).getManagerRoleID());
/* 145 */     outJson(response, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ResponseBody
/*     */   @RequestMapping({"/setup"})
/*     */   public void setup(HttpServletRequest request, HttpServletResponse response) throws ClientProtocolException, IOException {
/* 159 */     String cookie = BasicUtil.getString("cookie");
/* 160 */     String id = BasicUtil.getString("id");
/*     */     
/* 162 */     CloseableHttpClient httpclient = HttpClients.createDefault();
/* 163 */     String url = this.MS_MSTORE_HTTP + "/people/mstore/" + id + "/setup.do";
/* 164 */     HttpPost httpPost = new HttpPost(url);
/* 165 */     httpPost.setHeader("Host", this.MS_MSTORE_HOST);
/* 166 */     httpPost.setHeader("ms", "upgrader");
/* 167 */     httpPost.setHeader("accept", "");
/* 168 */     httpPost.setHeader("method", "setup");
/* 169 */     httpPost.setHeader("cookie", cookie);
/* 170 */     httpPost.setHeader("Content-Type", "text/html;charset=UTF-8");
/* 171 */     Object object = null;
/*     */     try {
/* 173 */       object = httpclient.execute((HttpUriRequest)httpPost);
/* 174 */     } catch (HttpHostConnectException e) {
/* 175 */       e.printStackTrace();
/* 176 */       outString(response, this.html.replace("{result/}", "false").replace("{message/}", "链接MStore失败，请回到主界面重试！"));
/*     */       return;
/*     */     } 
/* 179 */     HttpEntity entity = object.getEntity();
/* 180 */     InputStream in = entity.getContent();
/*     */     
/* 182 */     String zipfile = "";
/* 183 */     String pack = "";
/* 184 */     String source = "";
/* 185 */     String menuStr = "";
/*     */     try {
/* 187 */       zipfile = object.getHeaders("fileName")[0].getValue();
/* 188 */       pack = object.getHeaders("pack")[0].getValue();
/* 189 */       source = object.getHeaders("source")[0].getValue();
/* 190 */     } catch (ArrayIndexOutOfBoundsException e) {
/* 191 */       outString(response, this.html.replace("{result/}", "false").replace("{message/}", "安装包获取失败，请回到主界面重试！"));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 196 */     if (StringUtils.isNotBlank(pack)) {
/* 197 */       ResultJson result = new ResultJson();
/* 198 */       if (!checkModel(pack)) {
/* 199 */         if (source.equals("yes")) {
/* 200 */           outString(response, this.html.replace("{result/}", result.isResult() + "").replace("{message/}", "请先使用源码加载模块到系统！ <form  method=\"post\" target='_blank' action=" + this.MS_MSTORE_HTTP + "/people/mstore/down.do><input name=\"id\" style=\"display:none\" value=\"" + id + "\"/><input  type=\"submit\" value=\"下载源码\" style='    width: 104px;height: 34px;border: none;background-color: #0099ff;color: #ffffff;font-size: 14px;cursor: pointer;'/></form> "));
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */           
/* 208 */           outString(response, this.html.replace("{result/}", result.isResult() + "").replace("{message/}", "请先加载源码或Maven依赖到系统！"));
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 215 */     if (StringUtil.isBlank(zipfile)) {
/*     */       return;
/*     */     }
/*     */     
/* 219 */     File classesFile = new File(ClassUtils.getDefaultClassLoader().getResource("").getPath());
/*     */     
/* 221 */     if (!FileUtil.exist(classesFile)) {
/* 222 */       FileUtil.mkdir(classesFile);
/*     */     }
/*     */     
/* 225 */     File zFile = new File(ClassUtils.getDefaultClassLoader().getResource("").getPath() + zipfile);
/*     */     try {
/* 227 */       FileOutputStream fout = new FileOutputStream(zFile);
/* 228 */       int l = -1;
/* 229 */       byte[] tmp = new byte[1024];
/* 230 */       while ((l = in.read(tmp)) != -1) {
/* 231 */         fout.write(tmp, 0, l);
/*     */       }
/*     */       
/* 234 */       fout.flush();
/* 235 */       fout.close();
/*     */     } finally {
/*     */       
/* 238 */       in.close();
/*     */     } 
/* 240 */     httpclient.close();
/*     */     
/* 242 */     String entryName = "";
/* 243 */     List<File> sqlFiles = new ArrayList<>();
/* 244 */     List<File> files = new ArrayList<>();
/* 245 */     List<File> classFiles = new ArrayList<>();
/* 246 */     File menu = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 251 */       ZipFile zipFile = new ZipFile(zFile);
/*     */ 
/*     */       
/* 254 */       File unzipFile = new File(ClassUtils.getDefaultClassLoader().getResource("").getPath());
/*     */       
/* 256 */       Enumeration<? extends ZipEntry> zipEnum = zipFile.getEntries();
/*     */ 
/*     */       
/* 259 */       while (zipEnum.hasMoreElements()) {
/*     */         
/* 261 */         ZipEntry entry = zipEnum.nextElement();
/*     */         try {
/* 263 */           entryName = new String(entry.getName().getBytes("utf-8"));
/* 264 */           if (entryName.indexOf(".DS_Store") > -1) {
/*     */             continue;
/*     */           }
/*     */           
/* 268 */           if (entryName.indexOf(File.separator) > -1) {
/* 269 */             FileUtil.mkdir(entryName.substring(0, entryName.indexOf(File.separator)));
/*     */           }
/* 271 */         } catch (UnsupportedEncodingException e) {
/*     */           
/* 273 */           e.printStackTrace();
/*     */         } 
/*     */         
/* 276 */         if (entry.isDirectory()) {
/* 277 */           (new File(unzipFile.getAbsolutePath() + File.separator + entryName)).mkdirs();
/*     */           continue;
/*     */         } 
/*     */         try {
/* 281 */           File temp = new File(unzipFile.getAbsolutePath() + File.separator + entryName);
/* 282 */           InputStream input = zipFile.getInputStream(entry);
/* 283 */           OutputStream output = new FileOutputStream(temp);
/*     */           
/* 285 */           if (entryName.indexOf(".sql") > 0) {
/* 286 */             sqlFiles.add(new File(unzipFile.getAbsolutePath() + File.separator + entryName));
/*     */           }
/* 288 */           if (entryName.indexOf(".class") > 0) {
/* 289 */             classFiles.add(new File(unzipFile.getAbsolutePath() + File.separator + entryName));
/*     */           }
/* 291 */           if (entryName.indexOf(".json") > 0) {
/* 292 */             menu = new File(unzipFile.getAbsolutePath() + File.separator + entryName);
/*     */           }
/* 294 */           byte[] buffer = new byte[8192];
/* 295 */           int readLen = 0;
/* 296 */           while ((readLen = input.read(buffer, 0, 8192)) != -1) {
/* 297 */             output.write(buffer, 0, readLen);
/*     */           }
/* 299 */           output.flush();
/* 300 */           output.close();
/* 301 */           input.close();
/* 302 */           input = null;
/* 303 */           output = null;
/* 304 */         } catch (IOException e) {
/*     */           
/* 306 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 311 */       zipFile.close();
/*     */     }
/* 313 */     catch (ZipException e1) {
/*     */       
/* 315 */       e1.printStackTrace();
/* 316 */     } catch (IOException e1) {
/*     */       
/* 318 */       e1.printStackTrace();
/*     */     } 
/*     */ 
/*     */     
/* 322 */     if (sqlFiles.size() > 0) {
/*     */       
/*     */       try {
/*     */         
/* 326 */         DruidDataSource dds = (DruidDataSource)SpringUtil.getBean(request.getServletContext(), "dataSource");
/* 327 */         ScriptRunner runner = new ScriptRunner((Connection)dds.getConnection());
/* 328 */         runner.setErrorLogWriter(null);
/* 329 */         runner.setLogWriter(null);
/* 330 */         runner.setSendFullScript(true);
/* 331 */         FileReader reader = null;
/* 332 */         for (File sql : sqlFiles) {
/* 333 */           reader = new FileReader(sql);
/* 334 */           runner.runScript(reader);
/*     */         } 
/* 336 */         runner.closeConnection();
/* 337 */         reader.close();
/* 338 */       } catch (FileNotFoundException e) {
/*     */         
/* 340 */         e.printStackTrace();
/* 341 */       } catch (SQLException e) {
/* 342 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 347 */     if (menu != null)
/*     */     {
/*     */       
/* 350 */       menuStr = FileUtil.readUtf8String(menu);
/*     */     }
/*     */ 
/*     */     
/* 354 */     int mangerRoleId = getManagerBySession(request).getManagerRoleID();
/* 355 */     this.modelBiz.jsonToModel(menuStr, mangerRoleId);
/*     */     
/* 357 */     if (classFiles.size() > 0) {
/*     */ 
/*     */       
/* 360 */       ClassLoader cload = new URLClassLoader(new URL[] { (new File(ClassUtils.getDefaultClassLoader().getResource("").getPath())).toURI().toURL() }, Thread.currentThread().getContextClassLoader());
/*     */       try {
/* 362 */         for (File cls : classFiles) {
/* 363 */           String className = cls.getPath().substring(cls.getPath().indexOf("classes") + 8, cls
/* 364 */               .getPath().length() - 6);
/* 365 */           className = className.replace("/", ".").replace("\\", ".");
/* 366 */           Class<?> clzss = Class.forName(className, true, cload);
/* 367 */           Object obj = clzss.newInstance();
/* 368 */           Method[] method = clzss.getDeclaredMethods();
/* 369 */           for (Method m : method) {
/* 370 */             if (m.toString().indexOf("public ") > -1) {
/*     */               try {
/* 372 */                 Object returnObj = m.invoke(obj, new Object[0]);
/* 373 */                 if (returnObj instanceof ResultJson) {
/* 374 */                   ResultJson result = (ResultJson)returnObj;
/* 375 */                   if (!result.isResult()) {
/* 376 */                     outString(response, this.html.replace("{result/}", "false")
/* 377 */                         .replace("{message/}", result.getResultMsg()));
/*     */                     return;
/*     */                   } 
/*     */                 } 
/* 381 */               } catch (IllegalArgumentException e) {
/*     */                 
/* 383 */                 e.printStackTrace();
/* 384 */               } catch (InvocationTargetException e) {
/*     */                 
/* 386 */                 e.printStackTrace();
/*     */               }
/*     */             
/*     */             }
/*     */           }
/*     */         
/*     */         }
/*     */       
/* 394 */       } catch (ClassNotFoundException e1) {
/*     */         
/* 396 */         e1.printStackTrace();
/* 397 */       } catch (InstantiationException e1) {
/*     */         
/* 399 */         e1.printStackTrace();
/* 400 */       } catch (IllegalAccessException e1) {
/*     */         
/* 402 */         e1.printStackTrace();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 408 */     zFile.delete();
/* 409 */     for (File f : files) {
/* 410 */       f.delete();
/*     */     }
/* 412 */     outString(response, this.html.replace("{result/}", "true").replace("{message/}", "安装升级成功！"));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkModel(String className) {
/*     */     try {
/* 418 */       Class<?> clazz = Class.forName(className);
/* 419 */     } catch (ClassNotFoundException e) {
/* 420 */       e.printStackTrace();
/* 421 */       return false;
/*     */     } 
/* 423 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-upgrader\1.0.13\ms-upgrader-1.0.13.jar!\net\mingsof\\upgrade\action\UpgraderAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */