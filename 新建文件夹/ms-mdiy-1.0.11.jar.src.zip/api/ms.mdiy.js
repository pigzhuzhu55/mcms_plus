/**
 * 通用自定义引用js
 */
(function() {
  
    let mdiy = {};
   
    if(typeof ms.mdiy != "object") {
        window.ms.mdiy = mdiy;
    }

}());