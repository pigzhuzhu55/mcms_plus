/*     */ package net.mingsoft.mdiy.util;
/*     */ 
/*     */ import cn.hutool.core.io.FileUtil;
/*     */ import freemarker.cache.FileTemplateLoader;
/*     */ import freemarker.cache.TemplateLoader;
/*     */ import freemarker.core.ParseException;
/*     */ import freemarker.template.Configuration;
/*     */ import freemarker.template.MalformedTemplateNameException;
/*     */ import freemarker.template.Template;
/*     */ import freemarker.template.TemplateException;
/*     */ import freemarker.template.TemplateNotFoundException;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Map;
/*     */ import net.mingsoft.basic.util.BasicUtil;
/*     */ import net.mingsoft.mdiy.parser.TagParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParserUtil
/*     */ {
/*     */   public static final String TEMPLATES = "templets";
/*     */   public static final String HTML = "html";
/*     */   public static final String MOBILE = "m";
/*     */   public static final String INDEX = "index";
/*     */   public static final String HTML_SUFFIX = ".html";
/*     */   public static final String PAGE_LIST = "list-";
/*     */   public static final String HTM_SUFFIX = ".htm";
/*     */   public static final String IS_DO = "isDo";
/*     */   public static final String URL = "url";
/*     */   public static final String COLUMN = "column";
/*     */   public static final String ID = "id";
/*     */   public static final String TABLE_NAME = "tableName";
/*     */   public static final String MODEL_NAME = "modelName";
/*     */   public static final String DO_SUFFIX = ".do";
/*     */   public static final String PAGE = "pageTag";
/*     */   public static final String PAGE_NO = "pageNo";
/*     */   public static final String SIZE = "size";
/*     */   public static final String TYPE_ID = "typeid";
/*     */   public static final String APP_ID = "appId";
/*     */   public static boolean IS_SINGLE = true;
/* 117 */   public static Configuration cfg = new Configuration();
/*     */   
/* 119 */   public static FileTemplateLoader ftl = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public static String buildTempletPath() { return buildTempletPath(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String buildTempletPath(String path) {
/* 138 */     return BasicUtil.getRealPath("templets") + File.separator + BasicUtil.getAppId() + File.separator + 
/* 139 */       BasicUtil.getApp().getAppStyle() + ((path != null) ? (File.separator + path) : "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   public static String buildMobileHtmlPath(String path) { return BasicUtil.getRealPath("html") + File.separator + BasicUtil.getAppId() + File.separator + "m" + File.separator + path + ".html"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   public static String buildHtmlPath(String path) { return BasicUtil.getRealPath("html") + File.separator + BasicUtil.getAppId() + File.separator + path + ".html"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasMobileFile(String path) {
/* 168 */     if (FileUtil.exist(buildTempletPath("m" + File.separator + path))) {
/* 169 */       return true;
/*     */     }
/* 171 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String generate(String templatePath, Map<String, String> params, boolean isMobile) throws TemplateNotFoundException, MalformedTemplateNameException, ParseException, IOException {
/* 192 */     if (IS_SINGLE) {
/* 193 */       params.put("url", BasicUtil.getUrl());
/*     */     }
/*     */     
/* 196 */     params.put("html", "html");
/*     */     
/* 198 */     params.put("appId", Integer.valueOf(BasicUtil.getAppId()));
/* 199 */     if (ftl == null || !buildTempletPath().equals(ftl.baseDir.getPath())) {
/* 200 */       ftl = new FileTemplateLoader(new File(buildTempletPath()));
/* 201 */       cfg.setNumberFormat("#");
/* 202 */       cfg.setTemplateLoader((TemplateLoader)ftl);
/*     */     } 
/*     */     
/* 205 */     Template template = cfg.getTemplate((isMobile ? (BasicUtil.getApp().getAppMobileStyle() + File.separator) : "") + templatePath, "utf-8");
/*     */     
/* 207 */     StringWriter writer = new StringWriter();
/* 208 */     TagParser tag = null;
/* 209 */     String content = null;
/*     */     try {
/* 211 */       template.process(null, writer);
/* 212 */       tag = new TagParser(writer.toString(), params);
/* 213 */       content = tag.rendering();
/* 214 */       return content;
/* 215 */     } catch (TemplateException e) {
/* 216 */       e.printStackTrace();
/*     */       
/* 218 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String read(String templatePath, boolean isMobile) throws TemplateNotFoundException, MalformedTemplateNameException, ParseException, IOException {
/* 233 */     if (ftl == null || !buildTempletPath().equals(ftl.baseDir.getPath())) {
/* 234 */       ftl = new FileTemplateLoader(new File(buildTempletPath()));
/* 235 */       cfg.setNumberFormat("#");
/* 236 */       cfg.setTemplateLoader((TemplateLoader)ftl);
/*     */     } 
/*     */     
/* 239 */     Template template = cfg.getTemplate((isMobile ? (BasicUtil.getApp().getAppMobileStyle() + File.separator) : "") + templatePath, "utf-8");
/*     */     
/* 241 */     StringWriter writer = new StringWriter();
/* 242 */     TagParser tag = null;
/* 243 */     String content = null;
/*     */     try {
/* 245 */       template.process(null, writer);
/* 246 */       return writer.toString();
/* 247 */     } catch (TemplateException e) {
/* 248 */       e.printStackTrace();
/*     */       
/* 250 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdi\\util\ParserUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */