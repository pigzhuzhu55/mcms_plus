/*     */ package net.mingsoft.mdiy.util;
/*     */ 
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import com.alibaba.fastjson.JSON;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.basic.util.BasicUtil;
/*     */ import net.mingsoft.basic.util.SpringUtil;
/*     */ import net.mingsoft.mdiy.biz.IDictBiz;
/*     */ import net.mingsoft.mdiy.entity.DictEntity;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DictUtil
/*     */ {
/*     */   public static DictEntity get(String dictLabel, String dictType) {
/*  23 */     DictEntity dict = new DictEntity();
/*  24 */     dict.setDictLabel(dictLabel);
/*  25 */     dict.setDictType(dictType);
/*  26 */     dict.setAppId(BasicUtil.getAppId());
/*  27 */     return (DictEntity)((IDictBiz)SpringUtil.getBean(IDictBiz.class)).getEntity((BaseEntity)dict);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DictEntity get(String dictType, String dictLabel, String dictValue) {
/*  36 */     DictEntity dict = new DictEntity();
/*  37 */     dict.setDictLabel(dictLabel);
/*  38 */     dict.setDictType(dictType);
/*  39 */     dict.setDictValue(dictValue);
/*  40 */     dict.setAppId(BasicUtil.getAppId());
/*  41 */     return (DictEntity)((IDictBiz)SpringUtil.getBean(IDictBiz.class)).getEntity((BaseEntity)dict);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getToJson(String dictType, String dictLabel, String dictValue) {
/*  50 */     DictEntity dict = new DictEntity();
/*  51 */     dict.setDictLabel(dictLabel);
/*  52 */     dict.setDictType(dictType);
/*  53 */     dict.setDictValue(dictValue);
/*  54 */     dict.setAppId(BasicUtil.getAppId());
/*  55 */     DictEntity dictEntity = (DictEntity)((IDictBiz)SpringUtil.getBean(IDictBiz.class)).getEntity((BaseEntity)dict);
/*  56 */     return JSON.toJSONString(dictEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<DictEntity> list(String dictType) {
/*  64 */     DictEntity dict = new DictEntity();
/*  65 */     dict.setDictType(dictType);
/*  66 */     dict.setAppId(BasicUtil.getAppId());
/*  67 */     return ((IDictBiz)SpringUtil.getBean(IDictBiz.class)).query((BaseEntity)dict);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public static String listJson(String dictType) { return JSON.toJSONString(list(dictType)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDictValue(String dictType, String dictLabel, String defaultValue) {
/*  86 */     if (StringUtils.isNotBlank(dictType) && StringUtils.isNotBlank(dictLabel)) {
/*  87 */       DictEntity dictEntity = get(dictType, dictLabel, null);
/*  88 */       if (ObjectUtil.isNotNull(dictEntity)) {
/*  89 */         return dictEntity.getDictValue();
/*     */       }
/*     */     } 
/*  92 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public static String getDictValue(String dictType, String dictLabel) { return getDictValue(dictType, dictLabel, ""); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDictLabel(String dictType, String dictValue, String defaultValue) {
/* 110 */     if (StringUtils.isNotBlank(dictType) && StringUtils.isNotBlank(dictValue)) {
/* 111 */       DictEntity dictEntity = get(dictType, null, dictValue);
/* 112 */       if (ObjectUtil.isNotNull(dictEntity)) {
/* 113 */         return dictEntity.getDictLabel();
/*     */       }
/*     */     } 
/* 116 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public static String getDictLabel(String dictType, String dictValue) { return getDictLabel(dictType, dictValue, ""); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDictLabels(String dictType, String dictValues, String defaultValue) {
/* 134 */     if (StringUtils.isNotBlank(dictType) && StringUtils.isNotBlank(dictValues)) {
/* 135 */       List<String> labels = new ArrayList();
/* 136 */       String[] values = dictValues.split(",");
/* 137 */       for (int i = 0; i < values.length; i++) {
/* 138 */         String value = values[i];
/* 139 */         String dictLabel = getDictLabel(dictType, value, defaultValue);
/* 140 */         if (!StringUtils.isBlank(dictLabel)) {
/* 141 */           labels.add(dictLabel);
/*     */         }
/*     */       } 
/* 144 */       return StringUtils.join(labels, ",");
/*     */     } 
/* 146 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getJsonByValues(String dictType, String dictValues) {
/* 156 */     List<DictEntity> labels = new ArrayList();
/* 157 */     if (StringUtils.isNotBlank(dictType) && StringUtils.isNotBlank(dictValues)) {
/* 158 */       String[] values = dictValues.split(",");
/* 159 */       for (int i = 0; i < values.length; i++) {
/* 160 */         String value = values[i];
/* 161 */         DictEntity dictEntity = get(dictType, null, value);
/* 162 */         if (ObjectUtil.isNotNull(dictEntity)) {
/* 163 */           labels.add(dictEntity);
/*     */         }
/*     */       } 
/*     */     } 
/* 167 */     return JSON.toJSONString(labels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 177 */   public static String getDictLabels(String dictType, String dictValues) { return getDictLabels(dictType, dictValues, ""); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getJsonByLabels(String dictType, String dictLabels) {
/* 185 */     List<DictEntity> values = new ArrayList();
/* 186 */     if (StringUtils.isNotBlank(dictType) && StringUtils.isNotBlank(dictLabels)) {
/* 187 */       String[] labels = dictLabels.split(",");
/* 188 */       for (int i = 0; i < labels.length; i++) {
/* 189 */         String value = labels[i];
/* 190 */         DictEntity dictEntity = get(dictType, value, null);
/* 191 */         if (ObjectUtil.isNotNull(dictEntity)) {
/* 192 */           values.add(dictEntity);
/*     */         }
/*     */       } 
/*     */     } 
/* 196 */     return JSON.toJSONString(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDictValues(String dictType, String dictLabels, String defaultValue) {
/* 206 */     if (StringUtils.isNotBlank(dictType) && StringUtils.isNotBlank(dictLabels)) {
/* 207 */       List<String> values = new ArrayList();
/* 208 */       String[] labels = dictLabels.split(",");
/* 209 */       for (int i = 0; i < labels.length; i++) {
/* 210 */         String value = labels[i];
/* 211 */         values.add(getDictValue(dictType, value, defaultValue));
/*     */       } 
/* 213 */       return StringUtils.join(values, ",");
/*     */     } 
/* 215 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public static String getDictValues(String dictType, String dictLabels) { return getDictValues(dictType, dictLabels, ""); }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdi\\util\DictUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */