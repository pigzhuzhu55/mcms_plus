/*    */ package net.mingsoft.mdiy.constant.e;
/*    */ 
/*    */ import net.mingsoft.base.constant.e.BaseEnum;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum FieldEnum
/*    */   implements BaseEnum
/*    */ {
/* 15 */   TEXT("text"),
/*    */ 
/*    */ 
/*    */   
/* 19 */   TEXTAREA("textarea"),
/*    */ 
/*    */ 
/*    */   
/* 23 */   HTML("html"),
/*    */ 
/*    */ 
/*    */   
/* 27 */   INT("int"),
/*    */ 
/*    */ 
/*    */   
/* 31 */   FLOAT("float"),
/*    */ 
/*    */ 
/*    */   
/* 35 */   DATE("date"),
/*    */ 
/*    */ 
/*    */   
/* 39 */   IMAGE("image"),
/*    */ 
/*    */ 
/*    */   
/* 43 */   FILE("file"),
/*    */ 
/*    */ 
/*    */   
/* 47 */   OPTION("option"),
/*    */ 
/*    */ 
/*    */   
/* 51 */   RADIO("radio"),
/*    */ 
/*    */ 
/*    */   
/* 55 */   CHECKBOX("checkbox");
/*    */ 
/*    */   
/*    */   private String text;
/*    */ 
/*    */ 
/*    */   
/* 62 */   FieldEnum(String text) { this.text = text; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 72 */   public String toString() { return this.text; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 79 */   public int toInt() { return 0; }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\constant\e\FieldEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */