/*    */ package net.mingsoft.mdiy.constant.e;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.mingsoft.base.constant.e.BaseEnum;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum DiyFormFieldEnum
/*    */   implements BaseEnum
/*    */ {
/* 17 */   TEXT(1, "字符"),
/* 18 */   DATE(2, "日期"),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 23 */   TEXTAREA(3, "文本"),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 28 */   INT(4, "整型"),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   FLOAT(5, "小数");
/*    */ 
/*    */   
/*    */   private Object code;
/*    */   
/*    */   private int id;
/*    */ 
/*    */   
/*    */   DiyFormFieldEnum(int id, Object code) {
/* 42 */     this.code = code;
/* 43 */     this.id = id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   public int toInt() { return this.id; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 63 */   public String toString() { return this.code.toString(); }
/*    */ 
/*    */ 
/*    */   
/*    */   public static Map toMap() {
/* 68 */     Map<String, String> map = new HashMap<>();
/* 69 */     for (DiyFormFieldEnum e : values()) {
/* 70 */       map.put(e.toInt() + "", e.toString());
/*    */     }
/* 72 */     return map;
/*    */   }
/*    */   
/*    */   public static DiyFormFieldEnum get(int id) {
/* 76 */     for (DiyFormFieldEnum e : values()) {
/* 77 */       if (e.toInt() == id) {
/* 78 */         return e;
/*    */       }
/*    */     } 
/* 81 */     return null;
/*    */   }
/*    */   
/*    */   public static DiyFormFieldEnum get(String str) {
/* 85 */     for (DiyFormFieldEnum e : values()) {
/* 86 */       if (e.toString().equals(str)) {
/* 87 */         return e;
/*    */       }
/*    */     } 
/* 90 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\constant\e\DiyFormFieldEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */