/*    */ package net.mingsoft.mdiy.constant.e;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.mingsoft.base.constant.e.BaseEnum;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ContentModelFieldEnum
/*    */   implements BaseEnum
/*    */ {
/* 17 */   TEXT(1, "单行"), TEXTAREA(2, "多行"), HTML(3, "html"), INT(4, "整型"), FLOAT(5, "小数"), DATE(6, "日期"), IMAGE(7, "图片"),
/* 18 */   ATTACH(8, "附件"), OPTION(9, "下拉框"), RADIO(10, "单选"), CHECKBOX(11, "多选");
/*    */ 
/*    */   
/*    */   private int id;
/*    */   
/*    */   private String text;
/*    */ 
/*    */   
/*    */   ContentModelFieldEnum(int id, String text) {
/* 27 */     this.id = id;
/* 28 */     this.text = text;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public int toInt() { return this.id; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   public String toString() { return this.text; }
/*    */ 
/*    */   
/*    */   public static Map toMap() {
/* 51 */     Map<String, String> map = new HashMap<>();
/* 52 */     for (ContentModelFieldEnum e : values()) {
/* 53 */       map.put(e.toInt() + "", e.toString());
/*    */     }
/* 55 */     return map;
/*    */   }
/*    */   
/*    */   public static ContentModelFieldEnum get(int id) {
/* 59 */     for (ContentModelFieldEnum e : values()) {
/* 60 */       if (e.toInt() == id) {
/* 61 */         return e;
/*    */       }
/*    */     } 
/* 64 */     return null;
/*    */   }
/*    */   
/*    */   public static ContentModelFieldEnum get(String str) {
/* 68 */     for (ContentModelFieldEnum e : values()) {
/* 69 */       if (e.toString().equals(str)) {
/* 70 */         return e;
/*    */       }
/*    */     } 
/* 73 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\constant\e\ContentModelFieldEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */