/*    */ package net.mingsoft.mdiy.constant.e;
/*    */ 
/*    */ import net.mingsoft.base.constant.e.BaseEnum;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum FieldSearchEnum
/*    */   implements BaseEnum
/*    */ {
/* 14 */   NOT("0"),
/*    */ 
/*    */ 
/*    */   
/* 18 */   IS("1");
/*    */   private Object code;
/*    */   
/* 21 */   FieldSearchEnum(Object code) { this.code = code; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 28 */   public int toInt() { return Integer.valueOf(this.code + "").intValue(); }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\constant\e\FieldSearchEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */