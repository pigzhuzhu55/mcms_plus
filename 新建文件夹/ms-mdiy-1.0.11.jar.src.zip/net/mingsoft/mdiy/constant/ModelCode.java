/*    */ package net.mingsoft.mdiy.constant;
/*    */ 
/*    */ import net.mingsoft.base.constant.e.BaseEnum;
/*    */ 
/*    */ 
/*    */ public enum ModelCode
/*    */   implements BaseEnum
/*    */ {
/*  9 */   ADMIN_LOGIN("00000000"),
/*    */ 
/*    */ 
/*    */   
/* 13 */   ROLE("01010000"),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 18 */   CITY("10990000"),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 23 */   ROLE_MANAGER("01020000"),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 28 */   APP("02010000"),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   CMS_COLUMN("02990000"),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   SCHOOL("10980000");
/*    */ 
/*    */ 
/*    */   
/*    */   private String code;
/*    */ 
/*    */ 
/*    */   
/* 46 */   ModelCode(String code) { this.code = code; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   public String toString() { return this.code; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 67 */   public int toInt() { return Integer.parseInt(this.code); }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\constant\ModelCode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */