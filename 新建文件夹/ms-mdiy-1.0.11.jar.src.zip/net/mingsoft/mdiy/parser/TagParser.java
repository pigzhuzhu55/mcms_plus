/*     */ package net.mingsoft.mdiy.parser;
/*     */ 
/*     */ import com.alibaba.druid.util.StringUtils;
/*     */ import freemarker.cache.StringTemplateLoader;
/*     */ import freemarker.cache.TemplateLoader;
/*     */ import freemarker.template.Configuration;
/*     */ import freemarker.template.Template;
/*     */ import freemarker.template.TemplateException;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.basic.util.SpringUtil;
/*     */ import net.mingsoft.mdiy.biz.ITagBiz;
/*     */ import net.mingsoft.mdiy.biz.ITagSqlBiz;
/*     */ import net.mingsoft.mdiy.entity.TagEntity;
/*     */ import net.mingsoft.mdiy.entity.TagSqlEntity;
/*     */ import net.mingsoft.mdiy.parser.bean.TagBean;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TagParser
/*     */ {
/*     */   private String content;
/*  49 */   private Map data = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private NamedParameterJdbcTemplate jdbc;
/*     */ 
/*     */   
/*  56 */   protected final Logger LOG = LoggerFactory.getLogger(getClass());
/*     */ 
/*     */   
/*     */   private ITagBiz tagBiz;
/*     */ 
/*     */   
/*     */   private ITagSqlBiz tagSqlBiz;
/*     */ 
/*     */   
/*  65 */   private List<String> tagKeys = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int pageSize;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private Map<String, TagBean> tags = new HashMap<>();
/*     */ 
/*     */   
/*  78 */   public TagParser(String content) { this(content, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TagParser(String content, Map map) {
/*  86 */     this.content = content;
/*     */     
/*  88 */     this.tagBiz = (ITagBiz)SpringUtil.getBean(ITagBiz.class);
/*  89 */     this.tagSqlBiz = (ITagSqlBiz)SpringUtil.getBean(ITagSqlBiz.class);
/*  90 */     this.jdbc = (NamedParameterJdbcTemplate)SpringUtil.getBean(NamedParameterJdbcTemplate.class);
/*     */     
/*  92 */     if (map != null) {
/*  93 */       this.data.putAll(map);
/*     */     }
/*  95 */     parser();
/*     */   }
/*     */ 
/*     */   
/*  99 */   public String getContent() { return this.content; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TagParser parser() {
/* 107 */     parserSingle().parserData();
/* 108 */     parserDoublue().parserData();
/* 109 */     this.content = parserFreemarker(this.content);
/* 110 */     rendering();
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */   
/* 115 */   private TagParser parserData() { return parserData(this.data); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TagParser parserData(Map<String, List> root) {
/* 127 */     Map<Object, Object> map = new HashMap<>();
/*     */     
/* 129 */     for (String tagName : this.tagKeys) {
/* 130 */       if (root.get(tagName) != null) {
/*     */         continue;
/*     */       }
/* 133 */       TagBean tagBean = this.tags.get(tagName);
/*     */       
/* 135 */       TagEntity tag = new TagEntity();
/*     */       
/* 137 */       tag.setTagName(tagName.split("_")[0].replace("ms:", ""));
/* 138 */       tag = (TagEntity)this.tagBiz.getEntity((BaseEntity)tag);
/* 139 */       if (tag == null) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 144 */       if (tagBean != null) {
/* 145 */         Map<Object, Object> tagParams = new HashMap<>();
/*     */         
/* 147 */         tagParams.putAll(this.data);
/* 148 */         tagParams.putAll(tagBean.getParams());
/* 149 */         Map<Object, Object> refs = new HashMap<>();
/*     */         
/* 151 */         Object tagRefs = tagBean.getParams().get("refs");
/* 152 */         if (tagRefs != null) {
/*     */           
/* 154 */           Object obj = root.get(tagRefs.toString().trim());
/* 155 */           Map mapData = (Map)obj;
/* 156 */           Iterator it = mapData.keySet().iterator();
/*     */           
/* 158 */           while (it.hasNext()) {
/* 159 */             List<Map> list = (List)mapData.get(it.next());
/*     */ 
/*     */             
/* 162 */             for (int i = 0; i < list.size(); i++)
/*     */             {
/* 164 */               Map<?, ?> row = list.get(i);
/*     */               
/* 166 */               tagParams.putAll(row);
/*     */ 
/*     */               
/* 169 */               List<TagSqlEntity> sqlList = this.tagSqlBiz.query(Integer.parseInt(tag.getId()));
/* 170 */               String sql = rendering(tagParams, ((TagSqlEntity)sqlList.get(0)).getTagSql());
/*     */ 
/*     */               
/* 173 */               Map<String, Object> whereParams = new HashMap<>();
/* 174 */               List _list = this.jdbc.queryForList(sql, whereParams);
/*     */ 
/*     */               
/* 177 */               root.put(tagName + row.get("id"), _list);
/*     */ 
/*     */               
/* 180 */               if (tagBean.getParams().get("ref") != null) {
/* 181 */                 refs.put(tagBean.getParams().get("ref").toString() + row.get("id"), _list);
/* 182 */                 root.put((String)tagBean.getParams().get("ref"), refs);
/* 183 */                 TagBean child = tagBean.getChild();
/* 184 */                 String ftl = "";
/* 185 */                 if (child != null) {
/* 186 */                   String temp = tagBean.getContent().replace(child.getContent(), child.getBeginTag().split(":")[1].trim() + "${item.id}");
/* 187 */                   ftl = parserFreemarker(temp);
/*     */                 } else {
/* 189 */                   ftl = parserFreemarker(tagBean.getContent());
/*     */                 } 
/* 191 */                 String cont = rendering(root, ftl.replace(tagName, tagName + row.get("id")));
/* 192 */                 this.content = this.content.replace(tagName + row.get("id"), cont);
/*     */               }
/* 194 */               else if (_list != null) {
/* 195 */                 String ftl = parserFreemarker(tagBean.getContent());
/* 196 */                 String cont = rendering(root, ftl.replace(tagName, tagName + row.get("id")));
/* 197 */                 this.content = this.content.replace(tagName + row.get("id"), cont);
/*     */               }
/*     */             
/*     */             }
/*     */           
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 206 */           List<TagSqlEntity> sqlList = this.tagSqlBiz.query(Integer.parseInt(tag.getId()));
/*     */           
/* 208 */           String sql = rendering(tagParams, ((TagSqlEntity)sqlList.get(0)).getTagSql());
/*     */           
/* 210 */           Map<String, Object> whereParams = new HashMap<>();
/* 211 */           List list = this.jdbc.queryForList(sql, whereParams);
/* 212 */           root.put(tagName, list);
/*     */ 
/*     */           
/* 215 */           if (tagBean.getParams().get("ref") != null) {
/* 216 */             refs.put(tagBean.getParams().get("ref").toString(), list);
/* 217 */             root.put((String)tagBean.getParams().get("ref"), refs);
/*     */             
/* 219 */             TagBean child = tagBean.getChild();
/*     */             
/* 221 */             String temp = tagBean.getContent().replace(child.getContent(), child.getBeginTag().split(":")[1].trim() + "${item.id}");
/*     */             
/* 223 */             String ftl = parserFreemarker(temp);
/*     */             
/* 225 */             String cont = rendering(root, ftl);
/*     */             
/* 227 */             this.content = this.content.replace(tagBean.getContent(), cont);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 232 */         if (tagBean.getParams().get("ispaging") != null)
/* 233 */           this.data.remove("ispaging"); 
/*     */         continue;
/*     */       } 
/* 236 */       List<TagSqlEntity> sqlList = this.tagSqlBiz.query(Integer.parseInt(tag.getId()));
/* 237 */       String sql = rendering(this.data, ((TagSqlEntity)sqlList.get(0)).getTagSql());
/* 238 */       Map<String, Object> whereParams = new HashMap<>();
/* 239 */       List<Map<Object, Object>> list = this.jdbc.queryForList(sql, whereParams);
/*     */       
/* 241 */       if (list.size() == 0) {
/*     */         
/* 243 */         Map<Object, Object> article = new HashMap<>();
/* 244 */         list.add(article);
/*     */       } 
/* 246 */       root.put(tagName, (List)list.get(0));
/*     */     } 
/*     */ 
/*     */     
/* 250 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getPageSize(String content) {
/* 259 */     Pattern r = Pattern.compile("\\{ms.*?}");
/* 260 */     Matcher m = r.matcher(content);
/* 261 */     int index = 0;
/*     */     
/* 263 */     TagBean pageTag = null;
/*     */ 
/*     */     
/* 266 */     while (m.find()) {
/* 267 */       TagBean tagBean = new TagBean();
/* 268 */       String line = m.group(0);
/* 269 */       String tag = line.split(" ")[0].replace("{", "").replace("}", "");
/* 270 */       String newTag = tag + "_" + index;
/* 271 */       content = content.replace(line, line.replace(tag, newTag));
/* 272 */       tagBean.setBeginTag(line.replace(tag, newTag));
/* 273 */       tagBean.setEndTag("{/" + newTag.split(":")[1] + "}");
/*     */       
/* 275 */       String[] temp = line.replace("}", "").replace(newTag, "").split(" ");
/*     */       
/* 277 */       for (String p : temp) {
/* 278 */         if (!StringUtils.isEmpty(p)) {
/* 279 */           String[] _p = p.split("=");
/*     */           
/* 281 */           if (_p.length == 2) {
/* 282 */             tagBean.getParams().put(p.split("=")[0], p.split("=")[1]);
/*     */             
/* 284 */             if (p.split("=")[0].equalsIgnoreCase("ispaging") && p.split("=")[1].equals("true")) {
/* 285 */               pageTag = tagBean;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 290 */       tagBean.setContent(line.replace(tag, newTag));
/* 291 */       if (pageTag != null) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 297 */     if (pageTag == null) {
/* 298 */       return 0;
/*     */     }
/* 300 */     if (pageTag.getParams().get("size") != null) {
/* 301 */       return Integer.parseInt((new StringBuilder()).append(pageTag.getParams().get("size")).append("").toString());
/*     */     }
/* 303 */     return 20;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TagParser parserDoublue() {
/* 321 */     Pattern r = Pattern.compile("\\{ms.*?}");
/* 322 */     Matcher m = r.matcher(this.content);
/* 323 */     int index = 0;
/*     */ 
/*     */ 
/*     */     
/* 327 */     while (m.find()) {
/* 328 */       TagBean tagBean = new TagBean();
/* 329 */       String line = m.group(0);
/*     */       
/* 331 */       String tag = line.split(" ")[0].replace("{", "").replace("}", "");
/*     */       
/* 333 */       String newTag = tag + "_" + index;
/* 334 */       this.content = this.content.replace(line, line.replace(tag, newTag));
/* 335 */       tagBean.setBeginTag(line.replace(tag, newTag));
/* 336 */       tagBean.setEndTag("{/" + newTag.split(":")[1] + "}");
/* 337 */       String[] temp = line.replace("}", "").replace(newTag, "").split(" ");
/* 338 */       for (String p : temp) {
/* 339 */         if (!StringUtils.isEmpty(p)) {
/* 340 */           String[] _p = p.split("=");
/* 341 */           if (_p.length == 2) {
/* 342 */             tagBean.getParams().put(p.split("=")[0], p.split("=")[1]);
/*     */           }
/*     */         } 
/*     */       } 
/* 346 */       tagBean.setContent(line.replace(tag, newTag));
/*     */       
/* 348 */       this.tags.put(newTag.split(":")[1], tagBean);
/* 349 */       this.tagKeys.add(newTag.split(":")[1]);
/* 350 */       index++;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 356 */     for (int i = this.tagKeys.size() - 1; i >= 0; i--) {
/* 357 */       String endTag = ((String)this.tagKeys.get(i)).split("_")[0];
/* 358 */       TagBean tag = this.tags.get(this.tagKeys.get(i));
/* 359 */       if (tag != null) {
/*     */ 
/*     */         
/* 362 */         String p = tag.getContent().replace("{", "\\{") + "([\\w\\W]*?)\\{/ms:" + endTag + "}";
/* 363 */         Pattern pt = Pattern.compile(p);
/* 364 */         Matcher mt = pt.matcher(this.content);
/* 365 */         while (mt.find()) {
/* 366 */           String temp = mt.group(0).replace("/ms:" + endTag + "}", "/" + (String)this.tagKeys.get(i) + "}");
/* 367 */           TagBean tagBean = this.tags.get(this.tagKeys.get(i));
/* 368 */           tagBean.setContent(temp);
/* 369 */           this.content = this.content.replace(mt.group(0), temp);
/*     */         } 
/*     */       } 
/* 372 */     }  return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String parserFreemarker(String content) {
/* 382 */     for (String str : this.tagKeys) {
/* 383 */       if (str.indexOf("if") > -1) {
/* 384 */         String _if = ((TagBean)this.tags.get(str)).getBeginTag().replace("{ms:" + str, "<#if ").replace("}", ">");
/* 385 */         content = content.replace(((TagBean)this.tags.get(str)).getBeginTag(), _if);
/* 386 */         content = content.replace(((TagBean)this.tags.get(str)).getEndTag(), "</#if>");
/* 387 */         content = content.replace("{/ms:if}", "</#if>");
/*     */         continue;
/*     */       } 
/* 390 */       if (this.tags.get(str) == null) {
/*     */         continue;
/*     */       }
/* 393 */       content = content.replace(((TagBean)this.tags.get(str)).getBeginTag(), "<#list " + str
/* 394 */           .replace("ms:", "") + " as item>");
/* 395 */       content = content.replace(((TagBean)this.tags.get(str)).getEndTag(), "</#list>");
/*     */     } 
/*     */ 
/*     */     
/* 399 */     content = content.replace("{ms:else}", "<#else>");
/* 400 */     Pattern p = Pattern.compile("\\[.*?/]");
/* 401 */     Matcher mt = p.matcher(content);
/* 402 */     while (mt.find()) {
/* 403 */       String field = mt.group(0);
/* 404 */       if (field.indexOf("field.") > 0) {
/* 405 */         field = mt.group(0).replace("[field.", "${item.").replace("/]", "!''}").replace("]", "!''}");
/*     */       }
/* 407 */       else if (field.indexOf("_root:") > 0) {
/* 408 */         field = mt.group(0).replace("[_root:", "${").replace("/]", "}").replace("]", "}");
/*     */       } 
/* 410 */       content = content.replace(mt.group(0), field);
/*     */     } 
/* 412 */     return content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TagParser parserSingle() {
/* 425 */     Pattern pattern = Pattern.compile("\\{ms:+[\\S].[^\\{}]+?/}");
/* 426 */     Matcher matcher = pattern.matcher(this.content);
/* 427 */     while (matcher.find()) {
/* 428 */       String text = matcher.group(0);
/* 429 */       this.content = this.content.replace(text, matcher.group(0).replace("ms:", "").replace("{", "${").replace("/}", "!''}"));
/* 430 */       String key = text.split(":")[1].split("\\.")[0];
/*     */       
/* 432 */       this.tagKeys.add(key);
/* 433 */       this.tags.put(key, null);
/*     */     } 
/* 435 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String rendering(Map map) {
/* 444 */     if (map != null) {
/* 445 */       this.data.putAll(map);
/*     */     }
/* 447 */     return rendering(this.data, this.content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 456 */   public String rendering() { return rendering(this.data, this.content); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String rendering(Map root, String content) {
/* 468 */     Configuration cfg = new Configuration();
/* 469 */     StringTemplateLoader stringLoader = new StringTemplateLoader();
/* 470 */     stringLoader.putTemplate("template", content);
/* 471 */     cfg.setNumberFormat("#");
/* 472 */     cfg.setTemplateLoader((TemplateLoader)stringLoader);
/*     */     try {
/* 474 */       Template template = cfg.getTemplate("template", "utf-8");
/* 475 */       StringWriter writer = new StringWriter();
/*     */       try {
/* 477 */         template.process(root, writer);
/* 478 */         content = writer.toString();
/* 479 */       } catch (TemplateException e) {
/* 480 */         e.printStackTrace();
/* 481 */         this.LOG.debug(content);
/*     */       } 
/* 483 */     } catch (IOException e) {
/* 484 */       e.printStackTrace();
/* 485 */       this.LOG.debug(content);
/*     */     } 
/* 487 */     return content;
/*     */   }
/*     */ 
/*     */   
/* 491 */   public int getPageSize() { return this.pageSize; }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\parser\TagParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */