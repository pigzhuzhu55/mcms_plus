/*     */ package net.mingsoft.mdiy.parser.bean;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TagBean
/*     */ {
/*  21 */   private Map params = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String content;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String beginTag;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String endTag;
/*     */ 
/*     */ 
/*     */   
/*     */   private TagBean child;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public String getContent() { return this.content; }
/*     */ 
/*     */ 
/*     */   
/*  49 */   public void setContent(String content) { this.content = content; }
/*     */ 
/*     */ 
/*     */   
/*  53 */   public Map getParams() { return this.params; }
/*     */ 
/*     */ 
/*     */   
/*  57 */   public void setParams(Map params) { this.params = params; }
/*     */ 
/*     */ 
/*     */   
/*  61 */   public String getBeginTag() { return this.beginTag; }
/*     */ 
/*     */ 
/*     */   
/*  65 */   public void setBeginTag(String beginTag) { this.beginTag = beginTag; }
/*     */ 
/*     */ 
/*     */   
/*  69 */   public String getEndTag() { return this.endTag; }
/*     */ 
/*     */ 
/*     */   
/*  73 */   public void setEndTag(String endTag) { this.endTag = endTag; }
/*     */ 
/*     */   
/*     */   public TagBean getChild() {
/*  77 */     if (this.child == null) {
/*     */       
/*  79 */       String p = "\\{ms:.*? ";
/*  80 */       Pattern r = Pattern.compile(p);
/*  81 */       Matcher m = r.matcher(this.content);
/*  82 */       int i = 0;
/*  83 */       String child = null;
/*  84 */       while (m.find()) {
/*  85 */         if (i == 1) {
/*  86 */           child = m.group();
/*     */         }
/*  88 */         i++;
/*     */       } 
/*     */       
/*  91 */       if (child != null) {
/*  92 */         this.child = new TagBean();
/*  93 */         this.child.setBeginTag(child);
/*     */         
/*  95 */         p = "\\" + child.trim() + "([\\s\\S]*)\\" + child.replace("{ms:", "{/").trim() + "}";
/*  96 */         r = Pattern.compile(p);
/*  97 */         m = r.matcher(this.content);
/*  98 */         while (m.find()) {
/*  99 */           this.child.setContent(m.group());
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 104 */     return this.child;
/*     */   }
/*     */ 
/*     */   
/* 108 */   public void setChild(TagBean child) { this.child = child; }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\parser\bean\TagBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */