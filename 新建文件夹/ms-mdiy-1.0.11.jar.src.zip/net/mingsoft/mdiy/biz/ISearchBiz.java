package net.mingsoft.mdiy.biz;

import net.mingsoft.basic.biz.IBasicBiz;
import net.mingsoft.mdiy.entity.SearchEntity;

public interface ISearchBiz extends IBasicBiz {
  SearchEntity getById(int paramInt);
}


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\biz\ISearchBiz.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */