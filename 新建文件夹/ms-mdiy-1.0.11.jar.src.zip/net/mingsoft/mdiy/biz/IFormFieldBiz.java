package net.mingsoft.mdiy.biz;

import java.util.List;
import net.mingsoft.base.biz.IBaseBiz;
import net.mingsoft.mdiy.entity.FormFieldEntity;

public interface IFormFieldBiz extends IBaseBiz {
  List<FormFieldEntity> queryByDiyFormId(int paramInt);
  
  FormFieldEntity getByFieldName(Integer paramInteger, String paramString);
}


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\biz\IFormFieldBiz.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */