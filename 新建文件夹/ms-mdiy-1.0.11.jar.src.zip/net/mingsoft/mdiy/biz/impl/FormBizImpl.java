/*     */ package net.mingsoft.mdiy.biz.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.mingsoft.base.biz.impl.BaseBizImpl;
/*     */ import net.mingsoft.base.dao.IBaseDao;
/*     */ import net.mingsoft.mdiy.biz.IFormBiz;
/*     */ import net.mingsoft.mdiy.constant.e.DiyFormFieldEnum;
/*     */ import net.mingsoft.mdiy.dao.IFormDao;
/*     */ import net.mingsoft.mdiy.dao.IFormFieldDao;
/*     */ import net.mingsoft.mdiy.entity.FormEntity;
/*     */ import net.mingsoft.mdiy.entity.FormFieldEntity;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Service;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Service
/*     */ public class FormBizImpl
/*     */   extends BaseBizImpl
/*     */   implements IFormBiz
/*     */ {
/*     */   private static final String FORM_ID = "FROMID";
/*     */   private static final String DATE = "DATE";
/*     */   private static final String ID = "ID";
/*     */   @Autowired
/*     */   private IFormDao formDao;
/*     */   @Autowired
/*     */   private IFormFieldDao formFieldDao;
/*     */   
/*  70 */   protected IBaseDao getDao() { return (IBaseDao)this.formDao; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveDiyFormData(int formId, Map params) {
/*  76 */     FormEntity dfe = (FormEntity)this.formDao.getEntity(Integer.valueOf(formId));
/*  77 */     if (dfe == null) {
/*     */       return;
/*     */     }
/*  80 */     String tableName = dfe.getFormTableName();
/*  81 */     List<FormFieldEntity> filedList = this.formFieldDao.queryByDiyFormId(formId);
/*  82 */     if (filedList == null) {
/*     */       return;
/*     */     }
/*  85 */     Map<String, Integer> values = builderSqlMap(filedList, params);
/*  86 */     values.put("FROMID", Integer.valueOf(formId));
/*  87 */     values.put("DATE", new Date());
/*  88 */     this.formFieldDao.insertBySQL(tableName, values);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map queryDiyFormData(int diyFormId, int appId, Map whereMap) {
/*  94 */     FormEntity dfe = (FormEntity)this.formDao.getEntity(Integer.valueOf(diyFormId));
/*  95 */     if (dfe != null) {
/*  96 */       List<FormFieldEntity> fieldList = this.formFieldDao.queryByDiyFormId(diyFormId);
/*  97 */       List<Map<String, String>> fields = new ArrayList<>();
/*  98 */       Map<String, String> field = new HashMap<>();
/*     */       
/* 100 */       List<String> keys = new ArrayList<>();
/* 101 */       for (int i = 0; i < fieldList.size(); i++) {
/* 102 */         field.put(((FormFieldEntity)fieldList.get(i)).getDiyFormFieldFieldName(), ((FormFieldEntity)fieldList.get(i)).getDiyFormFieldTipsName());
/* 103 */         fields.add(field);
/* 104 */         keys.add(((FormFieldEntity)fieldList.get(i)).getDiyFormFieldFieldName().toLowerCase());
/*     */       } 
/* 106 */       Map<Object, Object> wheres = new HashMap<>();
/* 107 */       wheres.put("FROMID", Integer.valueOf(diyFormId));
/*     */       
/* 109 */       if (whereMap != null) {
/*     */         
/* 111 */         Set<String> whereStr = whereMap.keySet();
/*     */         
/* 113 */         String[] array = whereStr.toArray(new String[whereStr.size()]);
/*     */         
/* 115 */         for (String str : array) {
/*     */           
/* 117 */           if (!keys.contains(str)) {
/* 118 */             whereStr.remove(str);
/*     */           }
/*     */         } 
/*     */         
/* 122 */         for (FormFieldEntity formFieldEntity : fieldList) {
/* 123 */           for (String key : whereStr) {
/* 124 */             if (DiyFormFieldEnum.INT.toInt() == formFieldEntity.getDiyFormFieldType() || DiyFormFieldEnum.FLOAT
/* 125 */               .toInt() == formFieldEntity.getDiyFormFieldType()) {
/* 126 */               wheres.put(key, whereMap.get(key)); continue;
/*     */             } 
/* 128 */             wheres.put(key, "'" + whereMap.get(key) + "'");
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 133 */         List list = this.formDao.queryBySQL(dfe.getFormTableName(), fields, wheres, Integer.valueOf(0), Integer.valueOf(10), null);
/* 134 */         wheres.put("list", list);
/*     */       } 
/* 136 */       wheres.put("fields", fieldList);
/* 137 */       return wheres;
/*     */     } 
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteQueryDiyFormData(int id, int diyFormId) {
/* 145 */     FormEntity dfe = (FormEntity)this.formDao.getEntity(Integer.valueOf(diyFormId));
/* 146 */     Map<Object, Object> wheres = new HashMap<>();
/* 147 */     wheres.put("FROMID", Integer.valueOf(diyFormId));
/* 148 */     wheres.put("ID", Integer.valueOf(id));
/* 149 */     this.formDao.deleteBySQL(dfe.getFormTableName(), wheres);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int countDiyFormData(int diyFormId, int appId) {
/* 155 */     FormEntity dfe = (FormEntity)this.formDao.getEntity(Integer.valueOf(diyFormId));
/* 156 */     Map<Object, Object> wheres = new HashMap<>();
/* 157 */     wheres.put("FROMID", Integer.valueOf(diyFormId));
/* 158 */     return this.formDao.countBySQL(dfe.getFormTableName(), wheres);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map builderSqlMap(List<FormFieldEntity> listField, Map params) {
/* 169 */     Map<Object, Object> mapParams = new HashMap<>();
/*     */     
/* 171 */     for (int i = 0; i < listField.size(); i++) {
/* 172 */       FormFieldEntity field = listField.get(i);
/*     */       
/* 174 */       String fieldName = field.getDiyFormFieldFieldName();
/* 175 */       String fieldNameLowerCase = field.getDiyFormFieldFieldName().toLowerCase();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 189 */       if (!StringUtils.isBlank((new StringBuilder()).append(params.get(fieldNameLowerCase)).append("").toString())) {
/*     */         
/* 191 */         mapParams.put(fieldName, params.get(fieldNameLowerCase));
/*     */       } else {
/*     */         
/* 194 */         mapParams.put(fieldName, params.get(fieldName));
/*     */       } 
/*     */     } 
/*     */     
/* 198 */     return mapParams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 204 */   public void createDiyFormTable(String table, Map<Object, List> fileds) { this.formDao.createDiyFormTable(table, fileds); }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\biz\impl\FormBizImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */