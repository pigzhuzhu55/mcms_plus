/*    */ package net.mingsoft.mdiy.biz.impl;
/*    */ 
/*    */ import net.mingsoft.base.biz.impl.BaseBizImpl;
/*    */ import net.mingsoft.base.dao.IBaseDao;
/*    */ import net.mingsoft.mdiy.biz.ITableBiz;
/*    */ import net.mingsoft.mdiy.dao.ITableDao;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.stereotype.Service;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Service("tableBizImpl")
/*    */ public class TableBizImpl
/*    */   extends BaseBizImpl
/*    */   implements ITableBiz
/*    */ {
/*    */   @Autowired
/*    */   private ITableDao tableDao;
/*    */   
/* 51 */   protected IBaseDao getDao() { return (IBaseDao)this.tableDao; }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\biz\impl\TableBizImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */