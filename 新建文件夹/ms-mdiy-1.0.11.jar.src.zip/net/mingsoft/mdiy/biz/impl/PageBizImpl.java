/*    */ package net.mingsoft.mdiy.biz.impl;
/*    */ 
/*    */ import net.mingsoft.base.biz.impl.BaseBizImpl;
/*    */ import net.mingsoft.base.dao.IBaseDao;
/*    */ import net.mingsoft.mdiy.biz.IPageBiz;
/*    */ import net.mingsoft.mdiy.dao.IPageDao;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.stereotype.Service;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Service("pageBizImpl")
/*    */ public class PageBizImpl
/*    */   extends BaseBizImpl
/*    */   implements IPageBiz
/*    */ {
/*    */   @Autowired
/*    */   private IPageDao pageDao;
/*    */   
/* 55 */   protected IBaseDao getDao() { return (IBaseDao)this.pageDao; }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\biz\impl\PageBizImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */