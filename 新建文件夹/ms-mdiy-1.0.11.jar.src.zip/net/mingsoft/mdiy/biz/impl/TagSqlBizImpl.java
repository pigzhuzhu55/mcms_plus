/*    */ package net.mingsoft.mdiy.biz.impl;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.mingsoft.base.biz.impl.BaseBizImpl;
/*    */ import net.mingsoft.base.dao.IBaseDao;
/*    */ import net.mingsoft.base.entity.BaseEntity;
/*    */ import net.mingsoft.mdiy.biz.ITagSqlBiz;
/*    */ import net.mingsoft.mdiy.dao.ITagSqlDao;
/*    */ import net.mingsoft.mdiy.entity.TagSqlEntity;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.stereotype.Service;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Service("tagSqlBizImpl")
/*    */ public class TagSqlBizImpl
/*    */   extends BaseBizImpl
/*    */   implements ITagSqlBiz
/*    */ {
/*    */   @Autowired
/*    */   private ITagSqlDao tagSqlDao;
/*    */   
/* 49 */   protected IBaseDao getDao() { return (IBaseDao)this.tagSqlDao; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<TagSqlEntity> query(int tagId) {
/* 55 */     TagSqlEntity sql = new TagSqlEntity();
/* 56 */     sql.setTagId(Integer.valueOf(tagId));
/* 57 */     return this.tagSqlDao.query((BaseEntity)sql);
/*    */   }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\biz\impl\TagSqlBizImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */