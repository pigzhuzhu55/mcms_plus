/*    */ package net.mingsoft.mdiy.biz.impl;
/*    */ 
/*    */ import net.mingsoft.base.biz.impl.BaseBizImpl;
/*    */ import net.mingsoft.base.dao.IBaseDao;
/*    */ import net.mingsoft.base.entity.BaseEntity;
/*    */ import net.mingsoft.basic.util.BasicUtil;
/*    */ import net.mingsoft.mdiy.biz.IDictBiz;
/*    */ import net.mingsoft.mdiy.dao.IDictDao;
/*    */ import net.mingsoft.mdiy.entity.DictEntity;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.stereotype.Service;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Service("dictBizImpl")
/*    */ public class DictBizImpl
/*    */   extends BaseBizImpl
/*    */   implements IDictBiz
/*    */ {
/*    */   @Autowired
/*    */   private IDictDao dictDao;
/*    */   
/* 54 */   protected IBaseDao getDao() { return (IBaseDao)this.dictDao; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DictEntity getByTypeAndLabel(String dictType, String dictLabel) {
/* 60 */     DictEntity dict = new DictEntity();
/* 61 */     dict.setDictType(dictType);
/* 62 */     dict.setDictLabel(dictLabel);
/* 63 */     dict.setAppId(BasicUtil.getAppId());
/* 64 */     return (DictEntity)this.dictDao.getByEntity((BaseEntity)dict);
/*    */   }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\biz\impl\DictBizImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */