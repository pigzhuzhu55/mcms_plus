/*    */ package net.mingsoft.mdiy.biz.impl;
/*    */ 
/*    */ import net.mingsoft.base.dao.IBaseDao;
/*    */ import net.mingsoft.base.entity.BaseEntity;
/*    */ import net.mingsoft.basic.biz.impl.BasicBizImpl;
/*    */ import net.mingsoft.basic.util.BasicUtil;
/*    */ import net.mingsoft.mdiy.biz.ISearchBiz;
/*    */ import net.mingsoft.mdiy.dao.ISearchDao;
/*    */ import net.mingsoft.mdiy.entity.SearchEntity;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.stereotype.Service;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Service("searchBiz")
/*    */ public class SearchBizImpl
/*    */   extends BasicBizImpl
/*    */   implements ISearchBiz
/*    */ {
/*    */   @Autowired
/*    */   private ISearchDao searchDao;
/*    */   
/* 65 */   protected IBaseDao getDao() { return (IBaseDao)this.searchDao; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SearchEntity getById(int searchId) {
/* 71 */     SearchEntity search = new SearchEntity();
/* 72 */     search.setAppId(BasicUtil.getAppId());
/* 73 */     search.setSearchId(searchId);
/* 74 */     Object obj = this.searchDao.getByEntity((BaseEntity)search);
/* 75 */     return (obj != null) ? (SearchEntity)obj : null;
/*    */   }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\biz\impl\SearchBizImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */