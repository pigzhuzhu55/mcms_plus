package net.mingsoft.mdiy.biz;

import net.mingsoft.base.biz.IBaseBiz;
import net.mingsoft.mdiy.entity.DictEntity;

public interface IDictBiz extends IBaseBiz {
  DictEntity getByTypeAndLabel(String paramString1, String paramString2);
}


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\biz\IDictBiz.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */