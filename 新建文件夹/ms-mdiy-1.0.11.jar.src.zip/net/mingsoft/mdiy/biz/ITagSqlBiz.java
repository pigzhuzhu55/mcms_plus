package net.mingsoft.mdiy.biz;

import java.util.List;
import net.mingsoft.base.biz.IBaseBiz;
import net.mingsoft.mdiy.entity.TagSqlEntity;

public interface ITagSqlBiz extends IBaseBiz {
  List<TagSqlEntity> query(int paramInt);
}


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\biz\ITagSqlBiz.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */