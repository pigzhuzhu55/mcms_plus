package net.mingsoft.mdiy.biz;

import net.mingsoft.base.biz.IBaseBiz;

public interface ITagBiz extends IBaseBiz {}


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\biz\ITagBiz.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */