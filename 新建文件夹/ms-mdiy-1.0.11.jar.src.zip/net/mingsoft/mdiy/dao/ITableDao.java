package net.mingsoft.mdiy.dao;

import net.mingsoft.base.dao.IBaseDao;

public interface ITableDao extends IBaseDao {}


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\dao\ITableDao.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */