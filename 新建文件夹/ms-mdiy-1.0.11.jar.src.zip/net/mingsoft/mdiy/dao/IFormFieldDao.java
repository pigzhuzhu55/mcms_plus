package net.mingsoft.mdiy.dao;

import java.util.List;
import net.mingsoft.base.dao.IBaseDao;
import net.mingsoft.mdiy.entity.FormFieldEntity;
import org.apache.ibatis.annotations.Param;

public interface IFormFieldDao extends IBaseDao {
  List<FormFieldEntity> queryByDiyFormId(@Param("diyFormFieldFormId") int paramInt);
  
  FormFieldEntity getByFieldName(@Param("diyFormFieldFormId") Integer paramInteger, @Param("diyFormFieldFieldName") String paramString);
}


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\dao\IFormFieldDao.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */