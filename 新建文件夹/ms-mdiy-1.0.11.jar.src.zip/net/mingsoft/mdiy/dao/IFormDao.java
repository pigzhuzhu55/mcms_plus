package net.mingsoft.mdiy.dao;

import java.util.List;
import java.util.Map;
import net.mingsoft.base.dao.IBaseDao;
import org.apache.ibatis.annotations.Param;

public interface IFormDao extends IBaseDao {
  void createDiyFormTable(@Param("table") String paramString, @Param("fileds") Map<Object, List> paramMap);
}


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\dao\IFormDao.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */