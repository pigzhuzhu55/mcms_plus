/*    */ package net.mingsoft.mdiy.action;
/*    */ 
/*    */ import java.util.MissingResourceException;
/*    */ import net.mingsoft.basic.action.BaseAction;
/*    */ import net.mingsoft.mdiy.constant.Const;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BaseAction
/*    */   extends BaseAction
/*    */ {
/*    */   protected String getResString(String key) {
/* 16 */     String str = "";
/*    */     try {
/* 18 */       str = super.getResString(key);
/* 19 */     } catch (MissingResourceException e) {
/* 20 */       str = Const.RESOURCES.getString(key);
/*    */     } 
/*    */     
/* 23 */     return str;
/*    */   }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\action\BaseAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */