/*     */ package net.mingsoft.mdiy.action;
/*     */ 
/*     */ import com.alibaba.fastjson.serializer.SerializeFilter;
/*     */ import io.swagger.annotations.Api;
/*     */ import io.swagger.annotations.ApiImplicitParam;
/*     */ import io.swagger.annotations.ApiImplicitParams;
/*     */ import io.swagger.annotations.ApiOperation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.mingsoft.base.constant.e.TableEnum;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.base.filter.DateValueFilter;
/*     */ import net.mingsoft.base.filter.DoubleValueFilter;
/*     */ import net.mingsoft.base.util.JSONArray;
/*     */ import net.mingsoft.basic.bean.EUListBean;
/*     */ import net.mingsoft.basic.biz.IColumnBiz;
/*     */ import net.mingsoft.basic.entity.ColumnEntity;
/*     */ import net.mingsoft.basic.util.BasicUtil;
/*     */ import net.mingsoft.basic.util.StringUtil;
/*     */ import net.mingsoft.mdiy.biz.IContentModelBiz;
/*     */ import net.mingsoft.mdiy.biz.IContentModelFieldBiz;
/*     */ import net.mingsoft.mdiy.constant.e.ContentModelFieldEnum;
/*     */ import net.mingsoft.mdiy.entity.ContentModelEntity;
/*     */ import net.mingsoft.mdiy.entity.ContentModelFieldEntity;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.web.bind.annotation.GetMapping;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.PathVariable;
/*     */ import org.springframework.web.bind.annotation.PostMapping;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import springfox.documentation.annotations.ApiIgnore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Api("自定义模型字段接口")
/*     */ @Controller
/*     */ @RequestMapping({"/${ms.manager.path}/mdiy/contentModel/contentModelField"})
/*     */ public class ContentModelFieldAction
/*     */   extends BaseAction
/*     */ {
/*     */   @Autowired
/*     */   private IContentModelFieldBiz contentModelFieldBiz;
/*     */   @Autowired
/*     */   private IContentModelBiz contentModelBiz;
/*     */   @Autowired
/*     */   private IColumnBiz columnBiz;
/*     */   
/*     */   @GetMapping({"/{contentModelId}/index"})
/*     */   public String index(@PathVariable int contentModelId, HttpServletRequest request, @ApiIgnore ModelMap model, HttpServletResponse response) {
/*  68 */     model.addAttribute("contentModelId", Integer.valueOf(contentModelId));
/*  69 */     model.put("fieldTypes", ContentModelFieldEnum.toMap());
/*  70 */     return "/mdiy/content_model/index_filed";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("表单列表")
/*     */   @ApiImplicitParam(name = "contentModelId", value = "绑定内容模型表ID", required = true, paramType = "path")
/*     */   @GetMapping({"/{contentModelId}/list"})
/*     */   public void list(@PathVariable @ApiIgnore int contentModelId, HttpServletRequest request, @ApiIgnore ModelMap model, HttpServletResponse response) {
/*  83 */     BasicUtil.startPage();
/*  84 */     List contentModelFieldList = this.contentModelFieldBiz.queryListByCmid(contentModelId);
/*     */     
/*  86 */     model.put("fieldTypes", ContentModelFieldEnum.toMap());
/*  87 */     model.put("contentModelId", Integer.valueOf(contentModelId));
/*  88 */     model.addAttribute("contentModelFieldList", contentModelFieldList);
/*  89 */     outJson(response, JSONArray.toJSONString(new EUListBean(contentModelFieldList, (int)BasicUtil.endPage(contentModelFieldList).getTotal()), new SerializeFilter[] { (SerializeFilter)new DoubleValueFilter(), (SerializeFilter)new DateValueFilter() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("保存内容模型接口")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "fieldCmid", value = "绑定内容模型表ID", required = true, paramType = "query"), @ApiImplicitParam(name = "fieldTipsName", value = "字段提示文字", required = true, paramType = "query"), @ApiImplicitParam(name = "fieldFieldName", value = "字段名称", required = true, paramType = "query"), @ApiImplicitParam(name = "fieldType", value = "字段类型(1单行文本 2多行文本 3=HTML文本4=整数类型 5=小数类型6=时间类型7=图片8=附件类型9=使用option下拉框10=使用radio选项卡11=Checkbox多选框)", required = true, paramType = "query")})
/*     */   @PostMapping({"/save"})
/*     */   @ResponseBody
/*     */   public void save(@ModelAttribute @ApiIgnore ContentModelFieldEntity field, HttpServletRequest request, HttpServletResponse response) {
/* 111 */     ContentModelEntity contentModel = (ContentModelEntity)this.contentModelBiz.getEntity(field.getFieldCmid());
/*     */     
/* 113 */     if (!StringUtil.checkLength(field.getFieldTipsName(), 1, 30)) {
/* 114 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("content.model.field.tips.name"), "1", "30" }));
/*     */       return;
/*     */     } 
/* 117 */     if (!StringUtil.checkLength(field.getFieldFieldName(), 1, 30)) {
/* 118 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("content.model.field.column.ame"), "1", "30" }));
/*     */       
/*     */       return;
/*     */     } 
/* 122 */     if (this.contentModelFieldBiz.getEntityByCmId(field.getFieldCmid(), field.getFieldFieldName()) != null) {
/* 123 */       outJson(response, null, false, getResString("err.exist", new String[] { getResString("content.model.field") }));
/*     */       
/*     */       return;
/*     */     } 
/* 127 */     this.contentModelFieldBiz.saveEntity((BaseEntity)field);
/*     */ 
/*     */     
/* 130 */     Map<Object, Object> fileds = new HashMap<>();
/*     */     
/* 132 */     fileds.put("fieldName", field.getFieldFieldName());
/*     */     
/* 134 */     fileds.put("fieldType", field.getFieldColumnType());
/*     */     
/* 136 */     fileds.put("default", field.getFieldDefault());
/*     */     
/* 138 */     this.contentModelFieldBiz.alterTable(contentModel.getCmTableName(), fileds, TableEnum.ALTER_ADD);
/* 139 */     outJson(response, null, true, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("删除表单类型接口")
/*     */   @PostMapping({"/delete"})
/*     */   @ResponseBody
/*     */   public void delete(@RequestBody List<ContentModelFieldEntity> contentModelFields, HttpServletRequest request, HttpServletResponse response) {
/* 156 */     for (int i = 0; i < contentModelFields.size(); i++) {
/*     */       
/* 158 */       ContentModelFieldEntity field = (ContentModelFieldEntity)this.contentModelFieldBiz.getEntity(((ContentModelFieldEntity)contentModelFields.get(i)).getFieldId());
/* 159 */       this.contentModelFieldBiz.deleteEntity(((ContentModelFieldEntity)contentModelFields.get(i)).getFieldId());
/*     */       
/* 161 */       ContentModelEntity contentModel = (ContentModelEntity)this.contentModelBiz.getEntity(field.getFieldCmid());
/* 162 */       if (contentModel != null) {
/* 163 */         Map<String, Object> fields = new HashMap<>();
/*     */         
/* 165 */         fields.put("fieldName", field.getFieldFieldName());
/*     */         
/* 167 */         this.contentModelFieldBiz.alterTable(contentModel.getCmTableName(), fields, TableEnum.ALTER_DROP);
/*     */       } 
/*     */     } 
/* 170 */     outJson(response, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("编辑表单接口")
/*     */   @ApiImplicitParam(name = "filedId", value = "自增长ID", required = true, paramType = "path")
/*     */   @GetMapping({"/{filedId}/edit"})
/*     */   @ResponseBody
/*     */   public void edit(@PathVariable @ApiIgnore int filedId, HttpServletResponse response) {
/* 186 */     ContentModelFieldEntity contentModelField = (ContentModelFieldEntity)this.contentModelFieldBiz.getEntity(filedId);
/* 187 */     outJson(response, (BaseEntity)contentModelField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("更新内容模型接口")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "fieldCmid", value = "绑定内容模型表ID", required = true, paramType = "query"), @ApiImplicitParam(name = "fieldTipsName", value = "字段提示文字", required = false, paramType = "query"), @ApiImplicitParam(name = "fieldFieldName", value = "字段名称", required = false, paramType = "query"), @ApiImplicitParam(name = "fieldType", value = "字段类型(1单行文本 2多行文本 3=HTML文本4=整数类型 5=小数类型6=时间类型7=图片8=附件类型9=使用option下拉框10=使用radio选项卡11=Checkbox多选框)", required = false, paramType = "query"), @ApiImplicitParam(name = "fieldCmid", value = "字段名称", required = false, paramType = "query"), @ApiImplicitParam(name = "fieldLength", value = "字段名称", required = false, paramType = "query"), @ApiImplicitParam(name = "fieldDefault", value = "字段名称", required = false, paramType = "query"), @ApiImplicitParam(name = "fieldIsNull", value = "字段名称", required = false, paramType = "query"), @ApiImplicitParam(name = "fieldIsSearch", value = "字段名称", required = false, paramType = "query")})
/*     */   @PostMapping({"/update"})
/*     */   @ResponseBody
/*     */   public void update(@ModelAttribute @ApiIgnore ContentModelFieldEntity contentModelFieldEntity, HttpServletRequest request, HttpServletResponse response) {
/* 215 */     this.contentModelFieldBiz.updateEntity((BaseEntity)contentModelFieldEntity);
/* 216 */     outJson(response, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("返回cms模块的自定义模型的html页面（适用于cms模块）")
/*     */   @ApiImplicitParam(name = "columnId", value = "栏目编号", required = true, paramType = "path")
/*     */   @GetMapping({"/{columnId}/queryField"})
/*     */   public String queryField(@PathVariable @ApiIgnore int columnId, @ApiIgnore ModelMap model, HttpServletRequest request) {
/* 232 */     ColumnEntity column = (ColumnEntity)this.columnBiz.getEntity(columnId);
/* 233 */     if (column != null) {
/*     */       
/* 235 */       int fieldCmid = column.getColumnContentModelId();
/*     */       
/* 237 */       List<ContentModelFieldEntity> listField = this.contentModelFieldBiz.queryListByCmid(fieldCmid);
/* 238 */       int basicId = BasicUtil.getInt("basicId").intValue();
/*     */       
/* 240 */       if (basicId != 0) {
/*     */         
/* 242 */         ContentModelEntity contentModel = (ContentModelEntity)this.contentModelBiz.getEntity(fieldCmid);
/*     */         
/* 244 */         if (contentModel != null) {
/*     */           
/* 246 */           List<String> listFieldName = new ArrayList<>();
/*     */           
/* 248 */           for (int i = 0; i < listField.size(); i++) {
/* 249 */             ContentModelFieldEntity field = listField.get(i);
/* 250 */             listFieldName.add(field.getFieldFieldName());
/*     */           } 
/*     */           
/* 253 */           Map<String, Integer> where = new HashMap<>();
/* 254 */           where.put("basicId", Integer.valueOf(basicId));
/*     */           
/* 256 */           List<Map> fieldLists = this.contentModelFieldBiz.queryBySQL(contentModel.getCmTableName(), listFieldName, where);
/* 257 */           if (fieldLists != null && fieldLists.size() > 0) {
/* 258 */             Map filedValue = fieldLists.get(0);
/* 259 */             model.addAttribute("filedValue", filedValue);
/*     */           } 
/*     */         } 
/*     */       } 
/* 263 */       model.addAttribute("listField", listField);
/* 264 */       model.addAttribute("appId", Integer.valueOf(BasicUtil.getAppId()));
/*     */     } 
/* 266 */     return "/mdiy/content_model/content_model_field";
/*     */   }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\action\ContentModelFieldAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */