/*     */ package net.mingsoft.mdiy.action.people;
/*     */ 
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import com.alibaba.fastjson.serializer.SerializeFilter;
/*     */ import io.swagger.annotations.Api;
/*     */ import io.swagger.annotations.ApiImplicitParam;
/*     */ import io.swagger.annotations.ApiImplicitParams;
/*     */ import io.swagger.annotations.ApiOperation;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.base.filter.DateValueFilter;
/*     */ import net.mingsoft.base.filter.DoubleValueFilter;
/*     */ import net.mingsoft.base.util.JSONArray;
/*     */ import net.mingsoft.base.util.JSONObject;
/*     */ import net.mingsoft.basic.bean.EUListBean;
/*     */ import net.mingsoft.basic.util.BasicUtil;
/*     */ import net.mingsoft.basic.util.StringUtil;
/*     */ import net.mingsoft.mdiy.action.BaseAction;
/*     */ import net.mingsoft.mdiy.biz.ITableBiz;
/*     */ import net.mingsoft.mdiy.constant.Const;
/*     */ import net.mingsoft.mdiy.entity.TableEntity;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.web.bind.annotation.GetMapping;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.PostMapping;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import springfox.documentation.annotations.ApiIgnore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Api("自定义表管理接口")
/*     */ @Controller("peopleTableAction")
/*     */ @RequestMapping({"/people/mdiy/table"})
/*     */ public class TableAction
/*     */   extends BaseAction
/*     */ {
/*     */   @Autowired
/*     */   private ITableBiz tableBiz;
/*     */   
/*     */   @ApiOperation("查询自定义表列表")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "tableName", value = "自定义表名", required = false, paramType = "query"), @ApiImplicitParam(name = "tableMaster", value = "主表或主业务关键字", required = false, paramType = "query"), @ApiImplicitParam(name = "tableMasterId", value = "数据编号，主要关联主表编号", required = false, paramType = "query")})
/*     */   @GetMapping({"/list"})
/*     */   @ResponseBody
/*     */   public void list(@ModelAttribute @ApiIgnore TableEntity table, HttpServletResponse response, HttpServletRequest request) {
/*  91 */     BasicUtil.startPage();
/*  92 */     List tableList = this.tableBiz.query((BaseEntity)table);
/*  93 */     outJson(response, JSONArray.toJSONString(new EUListBean(tableList, (int)BasicUtil.endPage(tableList).getTotal()), new SerializeFilter[] { (SerializeFilter)new DoubleValueFilter(), (SerializeFilter)new DateValueFilter() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("获取自定义详情")
/*     */   @ApiImplicitParam(name = "id", value = "自定义表编号", required = true, paramType = "query")
/*     */   @GetMapping({"/get"})
/*     */   @ResponseBody
/*     */   public TableEntity get(@ModelAttribute @ApiIgnore TableEntity table, HttpServletResponse response, HttpServletRequest request) {
/* 128 */     if (table.getId() == null) {
/* 129 */       return null;
/*     */     }
/* 131 */     TableEntity _table = (TableEntity)this.tableBiz.getEntity(Integer.parseInt(table.getId()));
/* 132 */     return _table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("保存自定义表")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "appId", value = "站点编号", required = true, paramType = "query"), @ApiImplicitParam(name = "tableName", value = "自定义表名", required = true, paramType = "query"), @ApiImplicitParam(name = "tableMaster", value = "主表或主业务关键字", required = true, paramType = "query"), @ApiImplicitParam(name = "tableMasterId", value = "数据编号，主要关联主表编号", required = true, paramType = "query")})
/*     */   @PostMapping({"/save"})
/*     */   @ResponseBody
/*     */   public void save(@ModelAttribute @ApiIgnore TableEntity table, HttpServletResponse response, HttpServletRequest request) {
/* 174 */     if (StringUtils.isBlank(table.getTableMaster())) {
/* 175 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("table.master") }));
/*     */       return;
/*     */     } 
/* 178 */     if (!StringUtil.checkLength(table.getTableMaster() + "", 1, 255)) {
/* 179 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("table.master"), "1", "255" }));
/*     */       
/*     */       return;
/*     */     } 
/* 183 */     if (StringUtils.isBlank(table.getTableMasterId())) {
/* 184 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("table.master.id") }));
/*     */       return;
/*     */     } 
/* 187 */     if (!StringUtil.checkLength(table.getTableMasterId() + "", 1, 255)) {
/* 188 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("table.master.id"), "1", "255" }));
/*     */       
/*     */       return;
/*     */     } 
/* 192 */     this.tableBiz.saveEntity((BaseEntity)table);
/*     */     
/* 194 */     this.tableBiz.createTable(Const.TABLE_PREFIX + table.getId(), null);
/* 195 */     outJson(response, JSONObject.toJSONString(table));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("批量删除自定义表")
/*     */   @PostMapping({"/del"})
/*     */   @ResponseBody
/*     */   public void del(@RequestBody List<TableEntity> tables, HttpServletResponse response, HttpServletRequest request) {
/* 213 */     int[] ids = new int[tables.size()];
/* 214 */     for (int i = 0; i < tables.size(); i++) {
/* 215 */       if (ObjectUtil.isNotNull(tables.get(i))) {
/* 216 */         TableEntity table = (TableEntity)this.tableBiz.getEntity(Integer.parseInt(((TableEntity)tables.get(i)).getId()));
/* 217 */         if (ObjectUtil.isNotNull(table)) {
/* 218 */           this.tableBiz.dropTable(table.getTableName());
/*     */         }
/*     */       } 
/* 221 */       ids[i] = Integer.parseInt(((TableEntity)tables.get(i)).getId());
/*     */     } 
/* 223 */     this.tableBiz.delete(ids);
/* 224 */     outJson(response, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("更新自定义表信息")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "自定义表编号", required = true, paramType = "query"), @ApiImplicitParam(name = "appId", value = "站点编号", required = true, paramType = "query"), @ApiImplicitParam(name = "tableName", value = "自定义表名", required = true, paramType = "query"), @ApiImplicitParam(name = "tableMaster", value = "主表或主业务关键字", required = true, paramType = "query"), @ApiImplicitParam(name = "tableMasterId", value = "数据编号，主要关联主表编号", required = true, paramType = "query")})
/*     */   @PostMapping({"/update"})
/*     */   @ResponseBody
/*     */   public void update(@ModelAttribute @ApiIgnore TableEntity table, HttpServletResponse response, HttpServletRequest request) {
/* 268 */     if (StringUtils.isBlank(table.getId())) {
/* 269 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("id") }));
/*     */       return;
/*     */     } 
/* 272 */     if (!StringUtil.checkLength(table.getId() + "", 1, 11)) {
/* 273 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("id"), "1", "11" }));
/*     */       
/*     */       return;
/*     */     } 
/* 277 */     if (StringUtils.isBlank(table.getAppId() + "")) {
/* 278 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("app.id") }));
/*     */       return;
/*     */     } 
/* 281 */     if (!StringUtil.checkLength(table.getAppId() + "", 1, 11)) {
/* 282 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("app.id"), "1", "11" }));
/*     */       
/*     */       return;
/*     */     } 
/* 286 */     if (StringUtils.isBlank(table.getTableName())) {
/* 287 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("table.name") }));
/*     */       return;
/*     */     } 
/* 290 */     if (!StringUtil.checkLength(table.getTableName() + "", 1, 255)) {
/* 291 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("table.name"), "1", "255" }));
/*     */       
/*     */       return;
/*     */     } 
/* 295 */     if (StringUtils.isBlank(table.getTableMaster())) {
/* 296 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("table.master") }));
/*     */       return;
/*     */     } 
/* 299 */     if (!StringUtil.checkLength(table.getTableMaster() + "", 1, 255)) {
/* 300 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("table.master"), "1", "255" }));
/*     */       
/*     */       return;
/*     */     } 
/* 304 */     if (StringUtils.isBlank(table.getTableMasterId())) {
/* 305 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("table.master.id") }));
/*     */       return;
/*     */     } 
/* 308 */     if (!StringUtil.checkLength(table.getTableMasterId() + "", 1, 255)) {
/* 309 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("table.master.id"), "1", "255" }));
/*     */       return;
/*     */     } 
/* 312 */     this.tableBiz.updateEntity((BaseEntity)table);
/* 313 */     outJson(response, JSONObject.toJSONString(table));
/*     */   }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\action\people\TableAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */