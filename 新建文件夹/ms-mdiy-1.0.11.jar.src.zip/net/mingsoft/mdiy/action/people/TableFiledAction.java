/*     */ package net.mingsoft.mdiy.action.people;
/*     */ 
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import com.alibaba.fastjson.serializer.SerializeFilter;
/*     */ import io.swagger.annotations.Api;
/*     */ import io.swagger.annotations.ApiImplicitParam;
/*     */ import io.swagger.annotations.ApiImplicitParams;
/*     */ import io.swagger.annotations.ApiOperation;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.mingsoft.base.constant.e.TableEnum;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.base.filter.DateValueFilter;
/*     */ import net.mingsoft.base.filter.DoubleValueFilter;
/*     */ import net.mingsoft.base.util.JSONArray;
/*     */ import net.mingsoft.base.util.JSONObject;
/*     */ import net.mingsoft.basic.bean.EUListBean;
/*     */ import net.mingsoft.basic.util.BasicUtil;
/*     */ import net.mingsoft.basic.util.StringUtil;
/*     */ import net.mingsoft.mdiy.action.BaseAction;
/*     */ import net.mingsoft.mdiy.biz.ITableBiz;
/*     */ import net.mingsoft.mdiy.biz.ITableFiledBiz;
/*     */ import net.mingsoft.mdiy.constant.Const;
/*     */ import net.mingsoft.mdiy.constant.e.FieldEnum;
/*     */ import net.mingsoft.mdiy.entity.TableEntity;
/*     */ import net.mingsoft.mdiy.entity.TableFiledEntity;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.web.bind.annotation.GetMapping;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.PostMapping;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import springfox.documentation.annotations.ApiIgnore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Api("自定义表对应字段管理接口")
/*     */ @Controller("peopleTableFiledAction")
/*     */ @RequestMapping({"/people/mdiy/tableFiled"})
/*     */ public class TableFiledAction
/*     */   extends BaseAction
/*     */ {
/*     */   @Autowired
/*     */   private ITableFiledBiz tableFiledBiz;
/*     */   @Autowired
/*     */   private ITableBiz tableBiz;
/*     */   
/*     */   @ApiOperation("查询自定义表对应字段列表")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "tableId", value = "自定义表编号", required = false, paramType = "query"), @ApiImplicitParam(name = "tfName", value = "字段名称", required = false, paramType = "query"), @ApiImplicitParam(name = "tfType", value = "类型", required = false, paramType = "query"), @ApiImplicitParam(name = "tfDefault", value = "默认值", required = false, paramType = "query"), @ApiImplicitParam(name = "tfUnique", value = "描述", required = false, paramType = "query"), @ApiImplicitParam(name = "tfRequired", value = "0非必填1必填", required = false, paramType = "query"), @ApiImplicitParam(name = "tfConfig", value = "json配置", required = false, paramType = "query"), @ApiImplicitParam(name = "tfHelp", value = "帮助信息", required = false, paramType = "query")})
/*     */   @GetMapping({"/list"})
/*     */   @ResponseBody
/*     */   public void list(@ModelAttribute TableFiledEntity tableFiled, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 117 */     BasicUtil.startPage();
/* 118 */     List tableFiledList = this.tableFiledBiz.query((BaseEntity)tableFiled);
/* 119 */     outJson(response, JSONArray.toJSONString(new EUListBean(tableFiledList, (int)BasicUtil.endPage(tableFiledList).getTotal()), new SerializeFilter[] { (SerializeFilter)new DoubleValueFilter(), (SerializeFilter)new DateValueFilter() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("获取自定义表对应字段")
/*     */   @ApiImplicitParam(name = "id", value = "自定义表对应字段编号", required = true, paramType = "query")
/*     */   @GetMapping({"/get"})
/*     */   @ResponseBody
/*     */   public TableFiledEntity get(@ModelAttribute @ApiIgnore TableFiledEntity tableFiled, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 166 */     if (tableFiled.getId() == null) {
/* 167 */       return null;
/*     */     }
/* 169 */     TableFiledEntity _tableFiled = (TableFiledEntity)this.tableFiledBiz.getEntity(Integer.parseInt(tableFiled.getId()));
/* 170 */     return _tableFiled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("保存自定义表对应字段实体")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "tableId", value = "自定义表编号", required = true, paramType = "query"), @ApiImplicitParam(name = "tfName", value = "字段名称", required = true, paramType = "query"), @ApiImplicitParam(name = "tfType", value = "类型", required = true, paramType = "query"), @ApiImplicitParam(name = "tfDefault", value = "默认值", required = true, paramType = "query"), @ApiImplicitParam(name = "tfUnique", value = "描述", required = true, paramType = "query"), @ApiImplicitParam(name = "tfRequired", value = "0非必填1必填", required = true, paramType = "query"), @ApiImplicitParam(name = "tfConfig", value = "json配置", required = true, paramType = "query"), @ApiImplicitParam(name = "tfHelp", value = "帮助信息", required = true, paramType = "query")})
/*     */   @PostMapping({"/save"})
/*     */   @ResponseBody
/*     */   public void save(@ModelAttribute @ApiIgnore TableFiledEntity tableFiled, HttpServletResponse response, HttpServletRequest request) {
/* 226 */     if (StringUtils.isBlank(tableFiled.getTfName())) {
/* 227 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("tf.name") }));
/*     */       return;
/*     */     } 
/* 230 */     if (!StringUtil.checkLength(tableFiled.getTfName() + "", 1, 255)) {
/* 231 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tf.name"), "1", "255" }));
/*     */       
/*     */       return;
/*     */     } 
/* 235 */     if (StringUtils.isBlank(tableFiled.getTfType())) {
/* 236 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("tf.type") }));
/*     */       return;
/*     */     } 
/* 239 */     if (!StringUtil.checkLength(tableFiled.getTfType() + "", 1, 255)) {
/* 240 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tf.type"), "1", "255" }));
/*     */       
/*     */       return;
/*     */     } 
/* 244 */     if (!StringUtil.checkLength(tableFiled.getTfDefault() + "", 0, 255)) {
/* 245 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tf.default"), "0", "255" }));
/*     */       return;
/*     */     } 
/* 248 */     if (!StringUtil.checkLength(tableFiled.getTfDescription() + "", 0, 255)) {
/* 249 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tf.description"), "0", "255" }));
/*     */       return;
/*     */     } 
/* 252 */     if (!StringUtil.checkLength(tableFiled.getTfConfig() + "", 0, 255)) {
/* 253 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tf.config"), "0", "255" }));
/*     */       return;
/*     */     } 
/* 256 */     if (!StringUtil.checkLength(tableFiled.getTfHelp() + "", 0, 255)) {
/* 257 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tf.help"), "0", "255" }));
/*     */       return;
/*     */     } 
/* 260 */     TableFiledEntity _tableFiled = new TableFiledEntity();
/* 261 */     _tableFiled.setTableId(tableFiled.getTableId());
/* 262 */     _tableFiled.setTfName(tableFiled.getTfName());
/* 263 */     List<TableFiledEntity> list = this.tableFiledBiz.query((BaseEntity)_tableFiled);
/*     */     
/* 265 */     if (list.size() > 0) {
/* 266 */       outJson(response, null, false, getResString("err.exist", new String[] { getResString("tf.name") }));
/*     */       return;
/*     */     } 
/* 269 */     TableEntity table = (TableEntity)this.tableBiz.getEntity(tableFiled.getTableId().intValue());
/* 270 */     this.tableFiledBiz.saveEntity((BaseEntity)tableFiled);
/*     */     
/* 272 */     String fieldType = "varchar(500)";
/* 273 */     if (FieldEnum.DATE.toString().equals(tableFiled.getTfType())) {
/* 274 */       fieldType = "date";
/* 275 */       tableFiled.setTfDefault(null);
/*     */     } 
/* 277 */     if (FieldEnum.INT.toString().equals(tableFiled.getTfType())) {
/* 278 */       fieldType = "int(11)";
/*     */     }
/*     */     
/* 281 */     Map<Object, Object> fileds = new HashMap<>();
/*     */     
/* 283 */     fileds.put("fieldName", Const.TABLE_FILED_PREFIX + tableFiled.getId());
/*     */     
/* 285 */     fileds.put("fieldType", fieldType);
/*     */     
/* 287 */     fileds.put("default", tableFiled.getTfDefault());
/*     */     
/* 289 */     this.tableFiledBiz.alterTable(Const.TABLE_PREFIX + table.getId(), fileds, TableEnum.ALTER_ADD);
/* 290 */     outJson(response, JSONObject.toJSONString(tableFiled));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("批量删除自定义表对应字段")
/*     */   @ApiImplicitParam(name = "ids", value = "自定义表对应字段编号，多个用逗号隔开", required = true, paramType = "path")
/*     */   @PostMapping({"/del"})
/*     */   @ResponseBody
/*     */   public void del(HttpServletResponse response, HttpServletRequest request) {
/* 309 */     int[] ids = BasicUtil.getInts("ids", ",");
/* 310 */     if (ObjectUtil.isNull(ids)) {
/* 311 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("ids") }));
/*     */       return;
/*     */     } 
/* 314 */     for (int i = 0; i < ids.length; i++) {
/*     */       
/* 316 */       TableFiledEntity tableField = (TableFiledEntity)this.tableFiledBiz.getEntity(ids[i]);
/* 317 */       if (ObjectUtil.isNotNull(tableField)) {
/* 318 */         Map<String, Object> fields = new HashMap<>();
/*     */         
/* 320 */         fields.put("fieldName", Const.TABLE_FILED_PREFIX + ids[i]);
/*     */         
/* 322 */         this.tableFiledBiz.alterTable(Const.TABLE_PREFIX + tableField.getTableId(), fields, TableEnum.ALTER_DROP);
/*     */       } 
/*     */     } 
/* 325 */     this.tableFiledBiz.delete(ids);
/* 326 */     outJson(response, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("更新自定义表对应字段信息")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "自定义表对应字段编号", required = true, paramType = "query"), @ApiImplicitParam(name = "tfName", value = "字段名称", required = true, paramType = "query"), @ApiImplicitParam(name = "tfType", value = "类型", required = true, paramType = "query"), @ApiImplicitParam(name = "tfDefault", value = "默认值", required = true, paramType = "query"), @ApiImplicitParam(name = "tfUnique", value = "描述", required = true, paramType = "query"), @ApiImplicitParam(name = "tfRequired", value = "0非必填1必填", required = true, paramType = "query"), @ApiImplicitParam(name = "tfConfig", value = "json配置", required = true, paramType = "query"), @ApiImplicitParam(name = "tfHelp", value = "帮助信息", required = true, paramType = "query")})
/*     */   @PostMapping({"/update"})
/*     */   @ResponseBody
/*     */   public void update(@ModelAttribute @ApiIgnore TableFiledEntity tableFiled, HttpServletResponse response, HttpServletRequest request) {
/* 383 */     if (StringUtils.isBlank(tableFiled.getTfName())) {
/* 384 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("tf.name") }));
/*     */       return;
/*     */     } 
/* 387 */     if (!StringUtil.checkLength(tableFiled.getTfName() + "", 1, 255)) {
/* 388 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tf.name"), "1", "255" }));
/*     */       
/*     */       return;
/*     */     } 
/* 392 */     if (!StringUtil.checkLength(tableFiled.getTfDefault() + "", 0, 255)) {
/* 393 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tf.default"), "0", "255" }));
/*     */       return;
/*     */     } 
/* 396 */     if (!StringUtil.checkLength(tableFiled.getTfDescription() + "", 0, 255)) {
/* 397 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tf.description"), "0", "255" }));
/*     */       return;
/*     */     } 
/* 400 */     if (!StringUtil.checkLength(tableFiled.getTfConfig() + "", 0, 255)) {
/* 401 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tf.config"), "0", "255" }));
/*     */       return;
/*     */     } 
/* 404 */     if (!StringUtil.checkLength(tableFiled.getTfHelp() + "", 0, 255)) {
/* 405 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tf.help"), "0", "255" }));
/*     */       
/*     */       return;
/*     */     } 
/* 409 */     tableFiled.setTfType(null);
/* 410 */     this.tableFiledBiz.updateEntity((BaseEntity)tableFiled);
/* 411 */     outJson(response, JSONObject.toJSONString(tableFiled));
/*     */   }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\action\people\TableFiledAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */