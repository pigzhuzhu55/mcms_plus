/*     */ package net.mingsoft.mdiy.action;
/*     */ 
/*     */ import com.alibaba.fastjson.serializer.SerializeFilter;
/*     */ import io.swagger.annotations.Api;
/*     */ import io.swagger.annotations.ApiImplicitParam;
/*     */ import io.swagger.annotations.ApiImplicitParams;
/*     */ import io.swagger.annotations.ApiOperation;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.base.filter.DateValueFilter;
/*     */ import net.mingsoft.base.filter.DoubleValueFilter;
/*     */ import net.mingsoft.base.util.JSONArray;
/*     */ import net.mingsoft.base.util.JSONObject;
/*     */ import net.mingsoft.basic.bean.EUListBean;
/*     */ import net.mingsoft.basic.util.BasicUtil;
/*     */ import net.mingsoft.basic.util.StringUtil;
/*     */ import net.mingsoft.mdiy.biz.ITableBiz;
/*     */ import net.mingsoft.mdiy.entity.TableEntity;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.shiro.authz.annotation.RequiresPermissions;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.bind.annotation.GetMapping;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.PostMapping;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import springfox.documentation.annotations.ApiIgnore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Api("自定义表管理接口")
/*     */ @Controller
/*     */ @RequestMapping({"/${ms.manager.path}/mdiy/table"})
/*     */ public class TableAction
/*     */   extends BaseAction
/*     */ {
/*     */   @Autowired
/*     */   private ITableBiz tableBiz;
/*     */   
/*     */   @GetMapping({"/index"})
/*  58 */   public String index(HttpServletResponse response, HttpServletRequest request) { return "/mdiy/table/index"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("查询自定义表列表接口")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "tableName", value = "自定义表名", required = false, paramType = "query"), @ApiImplicitParam(name = "tableMaster", value = "主表或主业务关键字", required = false, paramType = "query"), @ApiImplicitParam(name = "tableMasterId", value = "数据编号，主要关联主表编号", required = false, paramType = "query")})
/*     */   @GetMapping({"/list"})
/*     */   @ResponseBody
/*     */   public void list(@ModelAttribute @ApiIgnore TableEntity table, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model, BindingResult result) {
/* 100 */     BasicUtil.startPage();
/* 101 */     List tableList = this.tableBiz.query((BaseEntity)table);
/* 102 */     outJson(response, JSONArray.toJSONString(new EUListBean(tableList, (int)BasicUtil.endPage(tableList).getTotal()), new SerializeFilter[] { (SerializeFilter)new DoubleValueFilter(), (SerializeFilter)new DateValueFilter() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @GetMapping({"/form"})
/*     */   public String form(@ModelAttribute TableEntity table, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 110 */     if (table.getId() != null) {
/* 111 */       BaseEntity tableEntity = this.tableBiz.getEntity(Integer.parseInt(table.getId()));
/* 112 */       model.addAttribute("tableEntity", tableEntity);
/*     */     } 
/* 114 */     return "/mdiy/table/form";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation(" 获取自定义表详情")
/*     */   @ApiImplicitParam(name = "id", value = "自定义表编号", required = true, paramType = "query")
/*     */   @GetMapping({"/get"})
/*     */   @ResponseBody
/*     */   public TableEntity get(@ModelAttribute @ApiIgnore TableEntity table, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 150 */     if (table.getId() == null) {
/* 151 */       return null;
/*     */     }
/* 153 */     TableEntity _table = (TableEntity)this.tableBiz.getEntity(Integer.parseInt(table.getId()));
/* 154 */     return _table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("保存自定义表")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "appId", value = "站点编号", required = true, paramType = "query"), @ApiImplicitParam(name = "tableName", value = "自定义表名", required = true, paramType = "query"), @ApiImplicitParam(name = "tableMaster", value = "主表或主业务关键字", required = true, paramType = "query"), @ApiImplicitParam(name = "tableMasterId", value = "数据编号，主要关联主表编号", required = true, paramType = "query")})
/*     */   @PostMapping({"/save"})
/*     */   @ResponseBody
/*     */   @RequiresPermissions({"mdiy:table:save"})
/*     */   public void save(@ModelAttribute @ApiIgnore TableEntity table, HttpServletResponse response, HttpServletRequest request, BindingResult result) {
/* 197 */     if (StringUtils.isBlank(table.getAppId() + "")) {
/* 198 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("app.id") }));
/*     */       return;
/*     */     } 
/* 201 */     if (!StringUtil.checkLength(table.getAppId() + "", 1, 11)) {
/* 202 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("app.id"), "1", "11" }));
/*     */       
/*     */       return;
/*     */     } 
/* 206 */     if (StringUtils.isBlank(table.getTableName())) {
/* 207 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("table.name") }));
/*     */       return;
/*     */     } 
/* 210 */     if (!StringUtil.checkLength(table.getTableName() + "", 1, 255)) {
/* 211 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("table.name"), "1", "255" }));
/*     */       
/*     */       return;
/*     */     } 
/* 215 */     if (StringUtils.isBlank(table.getTableMaster())) {
/* 216 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("table.master") }));
/*     */       return;
/*     */     } 
/* 219 */     if (!StringUtil.checkLength(table.getTableMaster() + "", 1, 255)) {
/* 220 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("table.master"), "1", "255" }));
/*     */       
/*     */       return;
/*     */     } 
/* 224 */     if (StringUtils.isBlank(table.getTableMasterId())) {
/* 225 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("table.master.id") }));
/*     */       return;
/*     */     } 
/* 228 */     if (!StringUtil.checkLength(table.getTableMasterId() + "", 1, 255)) {
/* 229 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("table.master.id"), "1", "255" }));
/*     */       return;
/*     */     } 
/* 232 */     this.tableBiz.saveEntity((BaseEntity)table);
/* 233 */     outJson(response, JSONObject.toJSONString(table));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("批量删除自定义表")
/*     */   @PostMapping({"/delete"})
/*     */   @ResponseBody
/*     */   @RequiresPermissions({"mdiy:table:del"})
/*     */   public void delete(@RequestBody List<TableEntity> tables, HttpServletResponse response, HttpServletRequest request) {
/* 252 */     int[] ids = new int[tables.size()];
/* 253 */     for (int i = 0; i < tables.size(); i++) {
/* 254 */       ids[i] = Integer.parseInt(((TableEntity)tables.get(i)).getId());
/*     */     }
/* 256 */     this.tableBiz.delete(ids);
/* 257 */     outJson(response, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation(" 更新自定义表信息")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "自定义表编号", required = true, paramType = "query"), @ApiImplicitParam(name = "appId", value = "站点编号", required = true, paramType = "query"), @ApiImplicitParam(name = "tableName", value = "自定义表名", required = true, paramType = "query"), @ApiImplicitParam(name = "tableMaster", value = "主表或主业务关键字", required = true, paramType = "query"), @ApiImplicitParam(name = "tableMasterId", value = "数据编号，主要关联主表编号", required = true, paramType = "query")})
/*     */   @PostMapping({"/update"})
/*     */   @ResponseBody
/*     */   @RequiresPermissions({"mdiy:table:update"})
/*     */   public void update(@ModelAttribute @ApiIgnore TableEntity table, HttpServletResponse response, HttpServletRequest request) {
/* 302 */     if (StringUtils.isBlank(table.getId())) {
/* 303 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("id") }));
/*     */       return;
/*     */     } 
/* 306 */     if (!StringUtil.checkLength(table.getId() + "", 1, 11)) {
/* 307 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("id"), "1", "11" }));
/*     */       
/*     */       return;
/*     */     } 
/* 311 */     if (StringUtils.isBlank(table.getAppId() + "")) {
/* 312 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("app.id") }));
/*     */       return;
/*     */     } 
/* 315 */     if (!StringUtil.checkLength(table.getAppId() + "", 1, 11)) {
/* 316 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("app.id"), "1", "11" }));
/*     */       
/*     */       return;
/*     */     } 
/* 320 */     if (StringUtils.isBlank(table.getTableName())) {
/* 321 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("table.name") }));
/*     */       return;
/*     */     } 
/* 324 */     if (!StringUtil.checkLength(table.getTableName() + "", 1, 255)) {
/* 325 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("table.name"), "1", "255" }));
/*     */       
/*     */       return;
/*     */     } 
/* 329 */     if (StringUtils.isBlank(table.getTableMaster())) {
/* 330 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("table.master") }));
/*     */       return;
/*     */     } 
/* 333 */     if (!StringUtil.checkLength(table.getTableMaster() + "", 1, 255)) {
/* 334 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("table.master"), "1", "255" }));
/*     */       
/*     */       return;
/*     */     } 
/* 338 */     if (StringUtils.isBlank(table.getTableMasterId())) {
/* 339 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("table.master.id") }));
/*     */       return;
/*     */     } 
/* 342 */     if (!StringUtil.checkLength(table.getTableMasterId() + "", 1, 255)) {
/* 343 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("table.master.id"), "1", "255" }));
/*     */       return;
/*     */     } 
/* 346 */     this.tableBiz.updateEntity((BaseEntity)table);
/* 347 */     outJson(response, JSONObject.toJSONString(table));
/*     */   }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\action\TableAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */