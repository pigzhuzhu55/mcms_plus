/*    */ package net.mingsoft.mdiy.action.web;
/*    */ 
/*    */ import freemarker.core.ParseException;
/*    */ import freemarker.template.MalformedTemplateNameException;
/*    */ import freemarker.template.TemplateNotFoundException;
/*    */ import io.swagger.annotations.Api;
/*    */ import io.swagger.annotations.ApiOperation;
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import net.mingsoft.basic.util.BasicUtil;
/*    */ import net.mingsoft.mdiy.action.BaseAction;
/*    */ import net.mingsoft.mdiy.util.ParserUtil;
/*    */ import org.springframework.stereotype.Controller;
/*    */ import org.springframework.web.bind.annotation.GetMapping;
/*    */ import org.springframework.web.bind.annotation.PathVariable;
/*    */ import org.springframework.web.bind.annotation.RequestMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Api("自定义页码接口")
/*    */ @Controller("webDiyPath")
/*    */ @RequestMapping({"/mdiy/page"})
/*    */ public class PageAction
/*    */   extends BaseAction
/*    */ {
/*    */   @ApiOperation("自定义页码")
/*    */   @GetMapping({"/{diy}"})
/*    */   public void diy(@PathVariable("diy") String diy, HttpServletRequest req, HttpServletResponse resp) {
/* 46 */     Map<String, Object> map = BasicUtil.assemblyRequestMap();
/*    */     
/* 48 */     map.put("isDo", Boolean.valueOf(true));
/*    */     try {
/* 50 */       String content = ParserUtil.generate(ParserUtil.buildHtmlPath(diy), map, isMobileDevice(req));
/* 51 */       outString(resp, content);
/* 52 */     } catch (TemplateNotFoundException e1) {
/* 53 */       e1.printStackTrace();
/* 54 */     } catch (MalformedTemplateNameException e1) {
/* 55 */       e1.printStackTrace();
/* 56 */     } catch (ParseException e1) {
/* 57 */       e1.printStackTrace();
/* 58 */     } catch (IOException e1) {
/* 59 */       e1.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\action\web\PageAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */