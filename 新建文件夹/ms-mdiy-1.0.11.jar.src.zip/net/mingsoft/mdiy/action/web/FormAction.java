/*     */ package net.mingsoft.mdiy.action.web;
/*     */ 
/*     */ import com.alibaba.fastjson.JSONObject;
/*     */ import io.swagger.annotations.Api;
/*     */ import io.swagger.annotations.ApiImplicitParam;
/*     */ import io.swagger.annotations.ApiOperation;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.mingsoft.basic.action.BaseAction;
/*     */ import net.mingsoft.basic.bean.EUListBean;
/*     */ import net.mingsoft.basic.util.BasicUtil;
/*     */ import net.mingsoft.mdiy.biz.IFormBiz;
/*     */ import net.mingsoft.mdiy.dao.IFormFieldDao;
/*     */ import net.mingsoft.mdiy.entity.FormEntity;
/*     */ import org.apache.commons.lang3.math.NumberUtils;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.web.bind.annotation.GetMapping;
/*     */ import org.springframework.web.bind.annotation.PathVariable;
/*     */ import org.springframework.web.bind.annotation.PostMapping;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import springfox.documentation.annotations.ApiIgnore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Api("通用自定义表单")
/*     */ @Controller("webDiyForm")
/*     */ @RequestMapping({"/mdiy/diyForm", "/mdiy/form"})
/*     */ public class FormAction
/*     */   extends BaseAction
/*     */ {
/*     */   @Autowired
/*     */   IFormBiz diyFormBiz;
/*     */   @Autowired
/*     */   IFormBiz formBiz;
/*     */   private static final String ID = "ID";
/*     */   @Autowired
/*     */   IFormFieldDao formFieldDao;
/*     */   
/*     */   @ApiOperation("保存")
/*     */   @ApiImplicitParam(name = "idBase64", value = "Base64编码数据", required = true, paramType = "path")
/*     */   @PostMapping({"{idBase64}"})
/*     */   @ResponseBody
/*     */   public void save(@PathVariable("idBase64") @ApiIgnore String idBase64, HttpServletRequest request, HttpServletResponse response) {
/*  73 */     String temp = decryptByAES(request, idBase64);
/*     */ 
/*     */     
/*  76 */     if (request.getParameter("rand_code") != null && 
/*  77 */       !checkRandCode(request)) {
/*  78 */       outJson(response, null, false);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  83 */     if (!NumberUtils.isNumber(temp)) {
/*  84 */       outJson(response, null, false);
/*     */       
/*     */       return;
/*     */     } 
/*  88 */     int formId = Integer.parseInt(temp);
/*  89 */     if (formId != 0) {
/*  90 */       this.LOG.debug("fromId:" + formId);
/*  91 */       this.diyFormBiz.saveDiyFormData(formId, BasicUtil.assemblyRequestMap());
/*  92 */       outJson(response, null, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("提供前端查询自定义表单提交数据")
/*     */   @ApiImplicitParam(name = "idBase64", value = "Base64编码数据", required = true, paramType = "path")
/*     */   @GetMapping({"{idBase64}/queryData"})
/*     */   @ResponseBody
/*     */   public void queryData(@PathVariable("idBase64") @ApiIgnore String idBase64, HttpServletRequest request, HttpServletResponse response) {
/* 106 */     String temp = decryptByAES(request, idBase64);
/*     */     
/* 108 */     String where = request.getParameter("where");
/* 109 */     Map<String, Object> whereMap = new HashMap<>();
/* 110 */     whereMap = BasicUtil.assemblyRequestMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     int formId = Integer.parseInt(temp);
/*     */     
/* 121 */     if (!NumberUtils.isNumber(temp)) {
/* 122 */       outJson(response, null, false);
/*     */       return;
/*     */     } 
/* 125 */     if (formId != 0) {
/* 126 */       int appId = BasicUtil.getAppId();
/* 127 */       FormEntity dfe = (FormEntity)this.formBiz.getEntity(formId);
/* 128 */       Map map = null;
/* 129 */       if (dfe != null) {
/*     */         
/* 131 */         map = this.diyFormBiz.queryDiyFormData(formId, appId, whereMap);
/* 132 */         if (map != null) {
/* 133 */           map.remove("fields");
/* 134 */           BasicUtil.startPage();
/* 135 */           List list = this.formBiz.queryBySQL(dfe.getFormTableName(), null, map);
/* 136 */           outJson(response, JSONObject.toJSONString(new EUListBean(list, (int)BasicUtil.endPage(list).getTotal())));
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/* 141 */     outJson(response, null, false);
/*     */   }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\action\web\FormAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */