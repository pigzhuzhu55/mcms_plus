/*    */ package net.mingsoft.mdiy.action.web;
/*    */ 
/*    */ import freemarker.cache.FileTemplateLoader;
/*    */ import freemarker.cache.TemplateLoader;
/*    */ import freemarker.template.Configuration;
/*    */ import freemarker.template.Template;
/*    */ import freemarker.template.TemplateException;
/*    */ import io.swagger.annotations.Api;
/*    */ import io.swagger.annotations.ApiOperation;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.StringWriter;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import net.mingsoft.mdiy.action.BaseAction;
/*    */ import net.mingsoft.mdiy.biz.ITagBiz;
/*    */ import net.mingsoft.mdiy.parser.TagParser;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.stereotype.Controller;
/*    */ import org.springframework.ui.ModelMap;
/*    */ import org.springframework.web.bind.annotation.GetMapping;
/*    */ import org.springframework.web.bind.annotation.RequestMapping;
/*    */ import org.springframework.web.bind.annotation.ResponseBody;
/*    */ import springfox.documentation.annotations.ApiIgnore;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Api("标签管理接口")
/*    */ @Controller("webTagAction")
/*    */ @RequestMapping({"/mdiy/tag"})
/*    */ public class TagAction
/*    */   extends BaseAction
/*    */ {
/*    */   @Autowired
/*    */   private ITagBiz tagBiz;
/*    */   
/*    */   @ApiOperation("标签列表")
/*    */   @GetMapping({"/view"})
/*    */   @ResponseBody
/*    */   public void list(HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 54 */     Map<Object, Object> map = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 60 */     String templateName = request.getRequestURI();
/* 61 */     System.out.println(templateName);
/*    */     
/*    */     try {
/* 64 */       FileTemplateLoader ft = new FileTemplateLoader(new File("/Users/killfen/dev-tools/apache-tomcat-7.0.62/wtpwebapps/mcms/templets/1/default"));
/* 65 */       Configuration cfg = new Configuration();
/* 66 */       cfg.setTemplateLoader((TemplateLoader)ft);
/*    */       try {
/* 68 */         Template template = cfg.getTemplate("index.htm", "UTF-8");
/* 69 */         StringWriter writer = new StringWriter();
/*    */         try {
/* 71 */           template.process(null, writer);
/* 72 */           TagParser tag = new TagParser(writer.toString());
/* 73 */           tag.rendering(map);
/* 74 */           outString(response, tag.getContent());
/* 75 */         } catch (TemplateException e) {
/* 76 */           e.printStackTrace();
/*    */         } 
/* 78 */       } catch (IOException e) {
/* 79 */         e.printStackTrace();
/*    */       }
/*    */     
/* 82 */     } catch (IOException e) {
/*    */       
/* 84 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\action\web\TagAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */