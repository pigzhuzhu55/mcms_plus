/*     */ package net.mingsoft.mdiy.action;
/*     */ 
/*     */ import com.alibaba.fastjson.serializer.SerializeFilter;
/*     */ import io.swagger.annotations.Api;
/*     */ import io.swagger.annotations.ApiImplicitParam;
/*     */ import io.swagger.annotations.ApiImplicitParams;
/*     */ import io.swagger.annotations.ApiOperation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.base.filter.DateValueFilter;
/*     */ import net.mingsoft.base.filter.DoubleValueFilter;
/*     */ import net.mingsoft.base.util.JSONArray;
/*     */ import net.mingsoft.base.util.JSONObject;
/*     */ import net.mingsoft.basic.bean.EUListBean;
/*     */ import net.mingsoft.basic.biz.IColumnBiz;
/*     */ import net.mingsoft.basic.entity.ColumnEntity;
/*     */ import net.mingsoft.basic.entity.ManagerSessionEntity;
/*     */ import net.mingsoft.basic.util.BasicUtil;
/*     */ import net.mingsoft.basic.util.StringUtil;
/*     */ import net.mingsoft.mdiy.biz.IContentModelFieldBiz;
/*     */ import net.mingsoft.mdiy.biz.ISearchBiz;
/*     */ import net.mingsoft.mdiy.constant.Const;
/*     */ import net.mingsoft.mdiy.entity.ContentModelFieldEntity;
/*     */ import net.mingsoft.mdiy.entity.SearchEntity;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.shiro.authz.annotation.RequiresPermissions;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.web.bind.annotation.GetMapping;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.PathVariable;
/*     */ import org.springframework.web.bind.annotation.PostMapping;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import springfox.documentation.annotations.ApiIgnore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Api("自定义搜索接口")
/*     */ @Controller
/*     */ @RequestMapping({"/${ms.manager.path}/mdiy/search"})
/*     */ public class SearchAction
/*     */   extends BaseAction
/*     */ {
/*     */   @Autowired
/*     */   private ISearchBiz searchBiz;
/*     */   @Autowired
/*     */   private IColumnBiz columnBiz;
/*     */   @Autowired
/*     */   private IContentModelFieldBiz fieldBiz;
/*     */   
/*     */   @GetMapping({"/index"})
/*     */   public String index(HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/*  79 */     model.addAttribute("searchType", BasicUtil.resToMap("net.mingsoft.mdiy.resources.search_type"));
/*  80 */     return "/mdiy/search/index";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("查询自定义搜索列表接口")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "searchName", value = "搜索名称", required = false, paramType = "query"), @ApiImplicitParam(name = "searchTemplets", value = "搜索结果模板", required = false, paramType = "query"), @ApiImplicitParam(name = "searchType", value = "搜索类型", required = false, paramType = "query")})
/*     */   @GetMapping({"/list"})
/*     */   @ResponseBody
/*     */   public void list(@ModelAttribute @ApiIgnore SearchEntity search, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 112 */     if (search == null) {
/* 113 */       search = new SearchEntity();
/*     */     }
/* 115 */     search.setAppId(BasicUtil.getAppId());
/* 116 */     BasicUtil.startPage();
/* 117 */     List searchList = this.searchBiz.query((BaseEntity)search);
/* 118 */     outJson(response, JSONArray.toJSONString(new EUListBean(searchList, (int)BasicUtil.endPage(searchList).getTotal()), new SerializeFilter[] { (SerializeFilter)new DoubleValueFilter(), (SerializeFilter)new DateValueFilter() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @GetMapping({"/form"})
/*     */   public void form(@ModelAttribute SearchEntity search, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 126 */     if (search.getSearchId() <= 0) {
/* 127 */       outJson(response, false);
/*     */       return;
/*     */     } 
/* 130 */     SearchEntity searchEntity = (SearchEntity)this.searchBiz.getEntity((BaseEntity)search);
/* 131 */     outJson(response, (BaseEntity)searchEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("获取自定义搜索详情")
/*     */   @ApiImplicitParam(name = "searchId", value = "自定义搜索编号", required = true, paramType = "query")
/*     */   @GetMapping({"/get"})
/*     */   @ResponseBody
/*     */   public void get(@ModelAttribute @ApiIgnore SearchEntity search, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 157 */     if (search.getSearchId() <= 0) {
/* 158 */       outJson(response, null, false, getResString("err.error", new String[] { getResString("search.id") }));
/*     */       return;
/*     */     } 
/* 161 */     SearchEntity _search = (SearchEntity)this.searchBiz.getEntity(search.getSearchId());
/* 162 */     outJson(response, (BaseEntity)_search);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("保存自定义搜索接口")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "searchType", value = "搜索类型", required = true, paramType = "query"), @ApiImplicitParam(name = "searchName", value = "搜索名称", required = true, paramType = "query"), @ApiImplicitParam(name = "searchTemplets", value = "搜索结果模板", required = false, paramType = "query")})
/*     */   @PostMapping({"/save"})
/*     */   @ResponseBody
/*     */   @RequiresPermissions({"mdiy:search:save"})
/*     */   public void save(@ModelAttribute @ApiIgnore SearchEntity search, HttpServletResponse response, HttpServletRequest request) {
/* 194 */     if (StringUtils.isBlank(search.getSearchType())) {
/* 195 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("search.type") }));
/*     */       return;
/*     */     } 
/* 198 */     if (!StringUtil.checkLength(search.getSearchType() + "", 1, 255)) {
/* 199 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("search.type"), "1", "255" }));
/*     */       
/*     */       return;
/*     */     } 
/* 203 */     if (StringUtils.isBlank(search.getSearchName())) {
/* 204 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("search.name") }));
/*     */       return;
/*     */     } 
/* 207 */     if (!StringUtil.checkLength(search.getSearchName() + "", 1, 255)) {
/* 208 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("search.name"), "1", "255" }));
/*     */       return;
/*     */     } 
/* 211 */     search.setAppId(BasicUtil.getAppId());
/* 212 */     this.searchBiz.saveEntity((BaseEntity)search);
/* 213 */     outJson(response, JSONObject.toJSONString(search));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("批量删除自定义搜索接口")
/*     */   @PostMapping({"/delete"})
/*     */   @ResponseBody
/*     */   @RequiresPermissions({"mdiy:search:del"})
/*     */   public void delete(@RequestBody List<SearchEntity> searchs, HttpServletResponse response, HttpServletRequest request) {
/* 232 */     int[] ids = new int[searchs.size()];
/* 233 */     for (int i = 0; i < searchs.size(); i++) {
/* 234 */       ids[i] = ((SearchEntity)searchs.get(i)).getSearchId();
/*     */     }
/* 236 */     this.searchBiz.delete(ids);
/* 237 */     outJson(response, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("更新自定义搜索信息接口")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "searchType", value = "搜索类型", required = true, paramType = "query"), @ApiImplicitParam(name = "searchName", value = "搜索名称", required = false, paramType = "query"), @ApiImplicitParam(name = "searchTemplets", value = "搜索结果模板", required = false, paramType = "query")})
/*     */   @PostMapping({"/update"})
/*     */   @ResponseBody
/*     */   @RequiresPermissions({"mdiy:search:update"})
/*     */   public void update(@ModelAttribute @ApiIgnore SearchEntity search, HttpServletResponse response, HttpServletRequest request) {
/* 270 */     if (StringUtils.isBlank(search.getSearchType())) {
/* 271 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("search.type") }));
/*     */       return;
/*     */     } 
/* 274 */     if (!StringUtil.checkLength(search.getSearchType() + "", 1, 255)) {
/* 275 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("search.type"), "1", "255" }));
/*     */       return;
/*     */     } 
/* 278 */     this.searchBiz.updateEntity((BaseEntity)search);
/* 279 */     outJson(response, JSONObject.toJSONString(search));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("查询栏目自定义的字段名接口")
/*     */   @ApiImplicitParam(name = "columnId", value = "栏目编号", required = true, paramType = "path")
/*     */   @GetMapping({"/{columnId}/queryFieldName"})
/*     */   @ResponseBody
/*     */   public Map queryFieldName(@PathVariable @ApiIgnore int columnId, HttpServletRequest request) {
/* 293 */     Map<Object, Object> model = new HashMap<>();
/*     */     
/* 295 */     ColumnEntity column = (ColumnEntity)this.columnBiz.getEntity(columnId);
/* 296 */     if (column != null) {
/*     */       
/* 298 */       int fieldCmid = column.getColumnContentModelId();
/*     */       
/* 300 */       List<ContentModelFieldEntity> listField = this.fieldBiz.queryListByCmid(fieldCmid);
/* 301 */       model.put("listField", listField);
/*     */     } 
/* 303 */     return model;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("生成搜索表单的html样式")
/*     */   @GetMapping({"/generateSreachFormHtml"})
/*     */   public String generateSreachFormHtml(@ApiIgnore ModelMap model, HttpServletRequest request) {
/* 317 */     ManagerSessionEntity managerSession = getManagerBySession(request);
/* 318 */     int searchId = 0;
/* 319 */     if (!StringUtils.isBlank(request.getParameter("searchId"))) {
/* 320 */       searchId = Integer.valueOf(request.getParameter("searchId")).intValue();
/*     */     }
/*     */ 
/*     */     
/* 324 */     Map<String, String[]> field = (Map)new HashMap<>();
/* 325 */     field = request.getParameterMap();
/* 326 */     int basicCategoryId = 0;
/* 327 */     int cmId = 0;
/* 328 */     Map<String, String> basicField = getMapByProperties(Const.BASIC_FIELD);
/* 329 */     Map<String, String> basicAttribute = getMapByProperties(Const.BASIC_ATTRIBUTE);
/* 330 */     List<Map<String, String>> listFieldName = new ArrayList<>();
/* 331 */     for (Map.Entry<String, String[]> entry : field.entrySet()) {
/* 332 */       String key = entry.getKey();
/* 333 */       String value = ((String[])entry.getValue())[0];
/* 334 */       if (key.equals("columnId") && !StringUtils.isBlank(value) && !key.equals("searchId")) {
/* 335 */         basicCategoryId = Integer.valueOf(value).intValue();
/*     */       }
/* 337 */       if (!key.equals("columnId") && !key.equals("searchId")) {
/* 338 */         Map<String, String> map = new HashMap<>();
/* 339 */         map.put("name", key);
/* 340 */         map.put("type", value);
/*     */         
/* 342 */         if (!StringUtils.isBlank(basicField.get(key))) {
/* 343 */           map.put("ch", basicField.get(key));
/*     */         } else {
/*     */           
/* 346 */           if (basicCategoryId != 0) {
/* 347 */             ColumnEntity column = (ColumnEntity)this.columnBiz.getEntity(Integer.valueOf(basicCategoryId).intValue());
/*     */             
/* 349 */             cmId = column.getColumnContentModelId();
/*     */           } 
/* 351 */           ContentModelFieldEntity fieldEntity = this.fieldBiz.getEntityByCmId(cmId, key);
/* 352 */           if (fieldEntity != null) {
/* 353 */             String fieldTipsName = fieldEntity.getFieldTipsName();
/* 354 */             map.put("ch", fieldTipsName);
/*     */           } 
/*     */         } 
/* 357 */         if (key.equals("article_type")) {
/* 358 */           map.put("default", basicAttribute.toString());
/*     */         } else {
/* 360 */           map.put("default", key.toString());
/*     */         } 
/* 362 */         listFieldName.add(map);
/*     */       } 
/*     */     } 
/* 365 */     model.addAttribute("searchId", Integer.valueOf(searchId));
/* 366 */     model.addAttribute("searchType", request.getParameter("searchType"));
/* 367 */     model.addAttribute("websiteId", Integer.valueOf(managerSession.getBasicId()));
/* 368 */     model.addAttribute("listFieldName", listFieldName);
/* 369 */     model.addAttribute("basicCategoryId", Integer.valueOf(basicCategoryId));
/* 370 */     return "/mdiy/search/search_field";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("跳转至创建搜索页面")
/*     */   @GetMapping({"/{searchId}/searchCode"})
/*     */   public String searchCode(@PathVariable int searchId, ModelMap model, HttpServletRequest request) {
/* 382 */     List<ColumnEntity> columnList = this.columnBiz.queryColumnListByWebsiteId(BasicUtil.getAppId());
/* 383 */     SearchEntity searchEntity = new SearchEntity();
/* 384 */     searchEntity.setSearchId(searchId);
/* 385 */     SearchEntity search = (SearchEntity)this.searchBiz.getEntity((BaseEntity)searchEntity);
/* 386 */     model.addAttribute("columnList", JSONArray.toJSONString(columnList, new SerializeFilter[0]));
/* 387 */     model.addAttribute("searchId", Integer.valueOf(searchId));
/* 388 */     model.addAttribute("searchType", search.getSearchType());
/* 389 */     return "/mdiy/search/search_code";
/*     */   }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\action\SearchAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */