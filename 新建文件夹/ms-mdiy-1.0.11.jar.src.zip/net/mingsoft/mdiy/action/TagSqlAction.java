/*     */ package net.mingsoft.mdiy.action;
/*     */ 
/*     */ import com.alibaba.fastjson.serializer.SerializeFilter;
/*     */ import io.swagger.annotations.Api;
/*     */ import io.swagger.annotations.ApiImplicitParam;
/*     */ import io.swagger.annotations.ApiImplicitParams;
/*     */ import io.swagger.annotations.ApiOperation;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.base.filter.DateValueFilter;
/*     */ import net.mingsoft.base.filter.DoubleValueFilter;
/*     */ import net.mingsoft.base.util.JSONArray;
/*     */ import net.mingsoft.base.util.JSONObject;
/*     */ import net.mingsoft.basic.bean.EUListBean;
/*     */ import net.mingsoft.basic.util.BasicUtil;
/*     */ import net.mingsoft.basic.util.StringUtil;
/*     */ import net.mingsoft.mdiy.biz.ITagSqlBiz;
/*     */ import net.mingsoft.mdiy.entity.TagSqlEntity;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.shiro.authz.annotation.RequiresPermissions;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.bind.annotation.GetMapping;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.PostMapping;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import springfox.documentation.annotations.ApiIgnore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Api("标签对应多个sql语句管理接口")
/*     */ @Controller
/*     */ @RequestMapping({"/${ms.manager.path}/mdiy/tagSql"})
/*     */ public class TagSqlAction
/*     */   extends BaseAction
/*     */ {
/*     */   @Autowired
/*     */   private ITagSqlBiz tagSqlBiz;
/*     */   
/*     */   @GetMapping({"/index"})
/*     */   public String index(HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/*  57 */     model.addAttribute("tagId", BasicUtil.getInt("id"));
/*  58 */     return "/mdiy/tag_sql/index";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("查询标签对应多个sql语句列表")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "tagId", value = "自定义标签编号", required = false, paramType = "query"), @ApiImplicitParam(name = "tagSql", value = "自定义sql支持ftl写法", required = false, paramType = "query"), @ApiImplicitParam(name = "sort", value = "排序升序", required = false, paramType = "query")})
/*     */   @GetMapping({"/list"})
/*     */   @ResponseBody
/*     */   public void list(@ModelAttribute @ApiIgnore TagSqlEntity tagSql, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model, BindingResult result) {
/*  86 */     BasicUtil.startPage();
/*  87 */     List tagSqlList = this.tagSqlBiz.query((BaseEntity)tagSql);
/*  88 */     outJson(response, JSONArray.toJSONString(new EUListBean(tagSqlList, (int)BasicUtil.endPage(tagSqlList).getTotal()), new SerializeFilter[] { (SerializeFilter)new DoubleValueFilter(), (SerializeFilter)new DateValueFilter() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("保存标签对应多个sql语句")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "tagSql", value = "自定义sql支持ftl写法", required = true, paramType = "query"), @ApiImplicitParam(name = "sort", value = "排序升序", required = true, paramType = "query"), @ApiImplicitParam(name = "tagId", value = "自定义标签编号", required = false, paramType = "query")})
/*     */   @PostMapping({"/save"})
/*     */   @ResponseBody
/*     */   @RequiresPermissions({"mdiy:tagSql:save"})
/*     */   public void save(@ModelAttribute @ApiIgnore TagSqlEntity tagSql, HttpServletResponse response, HttpServletRequest request, BindingResult result) {
/* 117 */     if (StringUtils.isBlank(tagSql.getTagSql())) {
/* 118 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("tag.sql") }));
/*     */       return;
/*     */     } 
/* 121 */     if (!StringUtil.checkLength(tagSql.getTagSql() + "", 1, 1000)) {
/* 122 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tag.sql"), "1", "1000" }));
/*     */       
/*     */       return;
/*     */     } 
/* 126 */     if (StringUtils.isBlank(tagSql.getSort())) {
/* 127 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("sort") }));
/*     */       return;
/*     */     } 
/* 130 */     if (!StringUtil.checkLength(tagSql.getSort() + "", 1, 255)) {
/* 131 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("sort"), "1", "255" }));
/*     */       return;
/*     */     } 
/* 134 */     this.tagSqlBiz.saveEntity((BaseEntity)tagSql);
/* 135 */     outJson(response, JSONObject.toJSONString(tagSql));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("批量删除标签属性")
/*     */   @PostMapping({"/delete"})
/*     */   @ResponseBody
/*     */   @RequiresPermissions({"mdiy:tagSql:del"})
/*     */   public void delete(@RequestBody List<TagSqlEntity> tagSqls, HttpServletResponse response, HttpServletRequest request) {
/* 160 */     int[] ids = new int[tagSqls.size()];
/* 161 */     for (int i = 0; i < tagSqls.size(); i++) {
/* 162 */       ids[i] = Integer.parseInt(((TagSqlEntity)tagSqls.get(i)).getId());
/*     */     }
/* 164 */     this.tagSqlBiz.delete(ids);
/* 165 */     outJson(response, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("更新标签对应多个sql语句")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "标签对应多个sql语句编号", required = true, paramType = "query"), @ApiImplicitParam(name = "tagId", value = "自定义标签编号", required = true, paramType = "query"), @ApiImplicitParam(name = "tagSql", value = "自定义sql支持ftl写法", required = true, paramType = "query"), @ApiImplicitParam(name = "sort", value = "排序升序", required = true, paramType = "query")})
/*     */   @PostMapping({"/update"})
/*     */   @ResponseBody
/*     */   @RequiresPermissions({"mdiy:tagSql:update"})
/*     */   public void update(@ModelAttribute @ApiIgnore TagSqlEntity tagSql, HttpServletResponse response, HttpServletRequest request) {
/* 198 */     if (StringUtils.isBlank(tagSql.getId())) {
/* 199 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("id") }));
/*     */       return;
/*     */     } 
/* 202 */     if (!StringUtil.checkLength(tagSql.getId() + "", 1, 11)) {
/* 203 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("id"), "1", "11" }));
/*     */       
/*     */       return;
/*     */     } 
/* 207 */     if (StringUtils.isBlank(tagSql.getTagId() + "")) {
/* 208 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("tag.id") }));
/*     */       return;
/*     */     } 
/* 211 */     if (!StringUtil.checkLength(tagSql.getTagId() + "", 1, 11)) {
/* 212 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tag.id"), "1", "11" }));
/*     */       
/*     */       return;
/*     */     } 
/* 216 */     if (StringUtils.isBlank(tagSql.getTagSql())) {
/* 217 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("tag.sql") }));
/*     */       
/*     */       return;
/*     */     } 
/* 221 */     if (StringUtils.isBlank(tagSql.getSort())) {
/* 222 */       outJson(response, null, false, getResString("err.empty", new String[] { getResString("tag.description") }));
/*     */       return;
/*     */     } 
/* 225 */     if (!StringUtil.checkLength(tagSql.getSort() + "", 1, 255)) {
/* 226 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("tag.description"), "1", "255" }));
/*     */       return;
/*     */     } 
/* 229 */     this.tagSqlBiz.updateEntity((BaseEntity)tagSql);
/* 230 */     outJson(response, JSONObject.toJSONString(tagSql));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("获取标签对应多个sql语句详情")
/*     */   @ApiImplicitParam(name = "id", value = "标签对应多个sql语句编号", required = true, paramType = "query")
/*     */   @GetMapping({"/get"})
/*     */   @ResponseBody
/*     */   public TagSqlEntity get(@ModelAttribute @ApiIgnore TagSqlEntity tagSql, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 254 */     if (tagSql.getId() == null) {
/* 255 */       return null;
/*     */     }
/* 257 */     TagSqlEntity _tagSql = (TagSqlEntity)this.tagSqlBiz.getEntity(Integer.parseInt(tagSql.getId()));
/* 258 */     return _tagSql;
/*     */   }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\action\TagSqlAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */