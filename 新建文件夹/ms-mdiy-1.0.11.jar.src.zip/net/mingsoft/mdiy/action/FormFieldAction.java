/*     */ package net.mingsoft.mdiy.action;
/*     */ 
/*     */ import io.swagger.annotations.Api;
/*     */ import io.swagger.annotations.ApiImplicitParam;
/*     */ import io.swagger.annotations.ApiImplicitParams;
/*     */ import io.swagger.annotations.ApiOperation;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.mingsoft.base.constant.e.TableEnum;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.basic.util.StringUtil;
/*     */ import net.mingsoft.mdiy.biz.IFormBiz;
/*     */ import net.mingsoft.mdiy.biz.IFormFieldBiz;
/*     */ import net.mingsoft.mdiy.constant.e.DiyFormFieldEnum;
/*     */ import net.mingsoft.mdiy.entity.FormEntity;
/*     */ import net.mingsoft.mdiy.entity.FormFieldEntity;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.web.bind.annotation.GetMapping;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.PathVariable;
/*     */ import org.springframework.web.bind.annotation.PostMapping;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import springfox.documentation.annotations.ApiIgnore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Api("自定义表单字段接口")
/*     */ @Controller("diyFormField")
/*     */ @RequestMapping({"/${ms.manager.path}/mdiy/form/formField"})
/*     */ public class FormFieldAction
/*     */   extends BaseAction
/*     */ {
/*     */   private static final String FIELD_ID = "id";
/*     */   private static final String FIELD_DATE = "date";
/*     */   private static final String FIELD_FORMID = "formId";
/*     */   @Autowired
/*     */   private IFormFieldBiz diyFormFieldBiz;
/*     */   @Autowired
/*     */   private IFormBiz diyFormBiz;
/*     */   
/*     */   @ApiOperation("查询字段的列表接口")
/*     */   @ApiImplicitParam(name = "diyFormId", value = "自定义表单编号", required = true, paramType = "query")
/*     */   @GetMapping({"/list"})
/*     */   @ResponseBody
/*     */   public Map list(@ApiIgnore int diyFormId, HttpServletRequest request, HttpServletResponse response) {
/*  80 */     Map<Object, Object> map = new HashMap<>();
/*     */     
/*  82 */     List<FormFieldEntity> fieldList = this.diyFormFieldBiz.queryByDiyFormId(diyFormId);
/*  83 */     map.put("fieldList", fieldList);
/*     */     
/*  85 */     Map<Integer, String> fieldType = DiyFormFieldEnum.toMap();
/*  86 */     map.put("fieldType", fieldType);
/*  87 */     map.put("fieldNum", Integer.valueOf(fieldType.size()));
/*  88 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("添加自定义字段")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "diyFormId", value = "自定义表单编号", required = true, paramType = "path"), @ApiImplicitParam(name = "diyFormFieldTipsName", value = "字段提示文字", required = true, paramType = "query"), @ApiImplicitParam(name = "diyFormFieldFieldName", value = "字段名称", required = true, paramType = "query"), @ApiImplicitParam(name = "diyFormFieldFormId", value = "对应的自定义from的id", required = true, paramType = "query"), @ApiImplicitParam(name = "diyFormFieldType", value = "字段类型1字符2日期3文本4整型5小数", required = true, paramType = "query"), @ApiImplicitParam(name = "diyFormFieldDefault", value = "字段的默认值0，null", required = true, paramType = "query"), @ApiImplicitParam(name = "diyFormFieldSort", value = "排序", required = false, paramType = "query"), @ApiImplicitParam(name = "diyFormFieldIsNull", value = "判断字段为必填还是可选", required = false, paramType = "query")})
/*     */   @PostMapping({"/{diyFormId}/save"})
/*     */   @ResponseBody
/*     */   public void save(@ModelAttribute @ApiIgnore FormFieldEntity diyFormfield, @ApiIgnore @PathVariable int diyFormId, HttpServletResponse response) {
/* 117 */     FormEntity diyForm = (FormEntity)this.diyFormBiz.getEntity(diyFormId);
/* 118 */     if (diyForm == null) {
/* 119 */       outJson(response, null, false, getResString("err.not.exist", new String[] { getResString("diy.form") }));
/*     */       
/*     */       return;
/*     */     } 
/* 123 */     if (!StringUtil.checkLength(diyFormfield.getDiyFormFieldTipsName(), 1, 20)) {
/* 124 */       outJson(response, null, false, 
/* 125 */           getResString("err.length", new String[] { getResString("diy.form.tips.name"), "1", "20" }));
/*     */       return;
/*     */     } 
/* 128 */     if (!StringUtil.checkLength(diyFormfield.getDiyFormFieldFieldName(), 1, 20)) {
/* 129 */       outJson(response, null, false, 
/* 130 */           getResString("err.length", new String[] { getResString("diy.form.table.column.name"), "1", "20" }));
/*     */       
/*     */       return;
/*     */     } 
/* 134 */     if (this.diyFormFieldBiz.getByFieldName(Integer.valueOf(diyFormfield.getDiyFormFieldFormId()), diyFormfield
/* 135 */         .getDiyFormFieldFieldName()) != null) {
/* 136 */       outJson(response, null, false, 
/* 137 */           getResString("err.exist", new String[] { getResString("diy.form.table.column.name") }));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 143 */     Map<String, String> fileds = new HashMap<>();
/*     */     
/* 145 */     fileds.put("fieldName", diyFormfield.getDiyFormFieldFieldName());
/*     */     
/* 147 */     fileds.put("fieldType", diyFormfield.getDiyFormFieldColumnType());
/* 148 */     fileds.put("default", diyFormfield.getDiyFormFieldDefault());
/*     */     
/* 150 */     this.diyFormFieldBiz.alterTable(diyForm.getFormTableName(), fileds, TableEnum.ALTER_ADD);
/* 151 */     this.diyFormFieldBiz.saveEntity((BaseEntity)diyFormfield);
/* 152 */     outJson(response, null, true, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("获取编辑的字段实体的信息接口")
/*     */   @ApiImplicitParam(name = "diyFormFieldId", value = "自定义表单字段编号", required = true, paramType = "path")
/*     */   @GetMapping({"/{diyFormFieldId}/edit"})
/*     */   @ResponseBody
/*     */   public Map edit(@PathVariable @ApiIgnore int diyFormFieldId, HttpServletRequest request) {
/* 169 */     Map<Object, Object> mode = new HashMap<>();
/* 170 */     FormFieldEntity diyFormfield = (FormFieldEntity)this.diyFormFieldBiz.getEntity(diyFormFieldId);
/* 171 */     mode.put("diyFormfield", diyFormfield);
/* 172 */     return mode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("更新字段信息接口")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "diyFormId", value = "自定义表单编号", required = true, paramType = "query"), @ApiImplicitParam(name = "diyFormFieldTipsName", value = "字段提示文字", required = true, paramType = "query"), @ApiImplicitParam(name = "diyFormFieldFieldName", value = "字段名称", required = true, paramType = "query"), @ApiImplicitParam(name = "diyFormFieldFormId", value = "对应的自定义from的id", required = true, paramType = "query"), @ApiImplicitParam(name = "diyFormFieldType", value = "字段类型1字符2日期3文本4整型5小数", required = true, paramType = "query"), @ApiImplicitParam(name = "diyFormFieldDefault", value = "字段的默认值0，null", required = true, paramType = "query"), @ApiImplicitParam(name = "diyFormFieldSort", value = "排序", required = false, paramType = "query"), @ApiImplicitParam(name = "diyFormFieldIsNull", value = "判断字段为必填还是可选", required = false, paramType = "query")})
/*     */   @PostMapping({"/update"})
/*     */   @ResponseBody
/*     */   public void update(@ModelAttribute @ApiIgnore FormFieldEntity diyFormfield, HttpServletResponse response) {
/* 198 */     if (!StringUtil.checkLength(diyFormfield.getDiyFormFieldTipsName(), 1, 20)) {
/* 199 */       outJson(response, null, false, 
/* 200 */           getResString("err.length", new String[] { getResString("fieldTipsName"), "1", "20" }));
/*     */       return;
/*     */     } 
/* 203 */     if (!StringUtil.checkLength(diyFormfield.getDiyFormFieldFieldName(), 1, 20)) {
/* 204 */       outJson(response, null, false, 
/* 205 */           getResString("err.length", new String[] { getResString("fieldFieldName"), "1", "20" }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 210 */     FormEntity diyForm = (FormEntity)this.diyFormBiz.getEntity(diyFormfield.getDiyFormFieldFormId());
/*     */     
/* 212 */     FormFieldEntity oldField = (FormFieldEntity)this.diyFormFieldBiz.getEntity(diyFormfield.getDiyFormFieldId());
/* 213 */     Map<Object, Object> fields = new HashMap<>();
/*     */     
/* 215 */     fields.put("fieldOldName", oldField.getDiyFormFieldFieldName());
/*     */     
/* 217 */     fields.put("fieldName", diyFormfield.getDiyFormFieldFieldName());
/*     */     
/* 219 */     fields.put("fieldType", diyFormfield.getDiyFormFieldColumnType());
/*     */     
/* 221 */     fields.put("default", diyFormfield.getDiyFormFieldDefault());
/* 222 */     if (diyForm == null) {
/* 223 */       outJson(response, null, false, getResString("err.not.exist"));
/*     */       
/*     */       return;
/*     */     } 
/* 227 */     this.diyFormFieldBiz.alterTable(diyForm.getFormTableName(), fields, "modify");
/* 228 */     this.diyFormFieldBiz.updateEntity((BaseEntity)diyFormfield);
/* 229 */     outJson(response, null, true, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("判断字段名是否存在重复接口")
/*     */   @ApiImplicitParam(name = "diyFormFieldFieldName", value = "字段名", required = true, paramType = "path")
/*     */   @GetMapping({"/{diyFormFieldFieldName}/checkFieldNameExist"})
/*     */   @ResponseBody
/*     */   public boolean checkFieldNameExist(@PathVariable @ApiIgnore String diyFormFieldFieldName, HttpServletRequest request) {
/* 246 */     int diyFormFieldFormId = 1;
/* 247 */     if (request.getParameter("diyFormFieldFormId") != null) {
/* 248 */       diyFormFieldFormId = Integer.parseInt(request.getParameter("diyFormFieldFormId"));
/*     */     }
/*     */     
/* 251 */     if (diyFormFieldFieldName.equalsIgnoreCase("id") || diyFormFieldFieldName.equalsIgnoreCase("date") || diyFormFieldFieldName
/* 252 */       .equalsIgnoreCase("formId") || this.diyFormFieldBiz
/* 253 */       .getByFieldName(Integer.valueOf(diyFormFieldFormId), diyFormFieldFieldName) != null) {
/* 254 */       return true;
/*     */     }
/* 256 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("删除自定义字段接口")
/*     */   @ApiImplicitParam(name = "fieldId", value = "表单编号", required = true, paramType = "path")
/*     */   @PostMapping({"/{fieldId}/delete"})
/*     */   public void delete(@PathVariable @ApiIgnore int fieldId, HttpServletRequest request, HttpServletResponse response) {
/* 276 */     FormFieldEntity diyFormField = (FormFieldEntity)this.diyFormFieldBiz.getEntity(fieldId);
/* 277 */     if (diyFormField == null) {
/* 278 */       outJson(response, null, false, 
/* 279 */           getResString("err.not.exist", new String[] { getResString("diy.form.field") }));
/*     */       return;
/*     */     } 
/* 282 */     FormEntity diyForm = (FormEntity)this.diyFormBiz.getEntity(diyFormField.getDiyFormFieldFormId());
/* 283 */     if (diyForm == null) {
/* 284 */       outJson(response, null, false, getResString("err.not.exist", new String[] { getResString("diy.form") }));
/*     */       return;
/*     */     } 
/* 287 */     Map<Object, Object> fields = new HashMap<>();
/*     */     
/* 289 */     fields.put("fieldName", diyFormField.getDiyFormFieldFieldName());
/*     */     
/* 291 */     this.diyFormFieldBiz.alterTable(diyForm.getFormTableName(), fields, "drop");
/* 292 */     this.diyFormFieldBiz.deleteEntity(diyFormField.getDiyFormFieldId());
/* 293 */     outJson(response, null, true);
/*     */   }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\action\FormFieldAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */