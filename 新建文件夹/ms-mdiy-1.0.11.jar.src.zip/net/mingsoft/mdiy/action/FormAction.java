/*     */ package net.mingsoft.mdiy.action;
/*     */ 
/*     */ import com.alibaba.fastjson.serializer.SerializeFilter;
/*     */ import io.swagger.annotations.Api;
/*     */ import io.swagger.annotations.ApiImplicitParam;
/*     */ import io.swagger.annotations.ApiImplicitParams;
/*     */ import io.swagger.annotations.ApiOperation;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.mingsoft.base.constant.e.BaseSessionEnum;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.base.filter.DateValueFilter;
/*     */ import net.mingsoft.base.filter.DoubleValueFilter;
/*     */ import net.mingsoft.base.util.JSONArray;
/*     */ import net.mingsoft.basic.bean.EUListBean;
/*     */ import net.mingsoft.basic.constant.e.SessionConstEnum;
/*     */ import net.mingsoft.basic.entity.ManagerEntity;
/*     */ import net.mingsoft.basic.util.BasicUtil;
/*     */ import net.mingsoft.basic.util.StringUtil;
/*     */ import net.mingsoft.mdiy.biz.IFormBiz;
/*     */ import net.mingsoft.mdiy.biz.IFormFieldBiz;
/*     */ import net.mingsoft.mdiy.entity.FormEntity;
/*     */ import net.mingsoft.mdiy.entity.FormFieldEntity;
/*     */ import org.apache.shiro.authz.annotation.RequiresPermissions;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.web.bind.annotation.GetMapping;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.PathVariable;
/*     */ import org.springframework.web.bind.annotation.PostMapping;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import springfox.documentation.annotations.ApiIgnore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Api("自定义表单接口")
/*     */ @Controller
/*     */ @RequestMapping({"/${ms.manager.path}/mdiy/form"})
/*     */ public class FormAction
/*     */   extends BaseAction
/*     */ {
/*     */   private static final String TABLE_NAME_PREFIX = "mdiy_";
/*     */   private static final String TABLE_NAME_SPLIT = "_";
/*     */   @Autowired
/*     */   IFormBiz formBiz;
/*     */   @Autowired
/*     */   IFormFieldBiz formFieldBiz;
/*     */   
/*     */   @GetMapping({"/index"})
/*  78 */   public String index(HttpServletResponse response, HttpServletRequest request) { return "/mdiy/form/index"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("查询自定义表单列表接口")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "formTipsName", value = "自定义表单提示文字", required = false, paramType = "query"), @ApiImplicitParam(name = "formTableName", value = "自定义表单表名", required = false, paramType = "query"), @ApiImplicitParam(name = "dfManagerid", value = "自定义表单关联的关联员id", required = false, paramType = "query")})
/*     */   @GetMapping({"/list"})
/*     */   @ResponseBody
/*     */   public void list(@ModelAttribute @ApiIgnore FormEntity form, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 118 */     form.setAppId(BasicUtil.getAppId());
/* 119 */     BasicUtil.startPage();
/* 120 */     List formList = this.formBiz.query((BaseEntity)form);
/* 121 */     outJson(response, JSONArray.toJSONString(new EUListBean(formList, (int)BasicUtil.endPage(formList).getTotal()), new SerializeFilter[] { (SerializeFilter)new DoubleValueFilter(), (SerializeFilter)new DateValueFilter() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @GetMapping({"/form"})
/*     */   public String form(@ModelAttribute FormEntity form, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 129 */     if (form.getFormId() != null) {
/* 130 */       FormEntity formEntity = (FormEntity)this.formBiz.getEntity(form.getFormId().intValue());
/* 131 */       model.addAttribute("formEntity", formEntity);
/*     */     } 
/*     */     
/* 134 */     return "/mdiy/form/form";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("获取自定义表单接口")
/*     */   @ApiImplicitParam(name = "formId", value = "自定义表单编号", required = true, paramType = "query")
/*     */   @GetMapping({"/get"})
/*     */   @ResponseBody
/*     */   public void get(@ModelAttribute @ApiIgnore FormEntity form, HttpServletResponse response, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 168 */     if (form.getFormId().intValue() <= 0) {
/* 169 */       outJson(response, null, false, getResString("err.error", new String[] { getResString("form.id") }));
/*     */       return;
/*     */     } 
/* 172 */     FormEntity _form = (FormEntity)this.formBiz.getEntity(form.getFormId().intValue());
/* 173 */     outJson(response, (BaseEntity)_form);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("批量删除自定义表单接口")
/*     */   @PostMapping({"/delete"})
/*     */   @ResponseBody
/*     */   public void delete(@RequestBody List<FormEntity> forms, HttpServletResponse response, HttpServletRequest request) {
/* 191 */     for (int i = 0; i < forms.size(); i++) {
/*     */       
/* 193 */       FormEntity form = (FormEntity)this.formBiz.getEntity(((FormEntity)forms.get(i)).getFormId().intValue());
/* 194 */       if (form == null) {
/* 195 */         outJson(response, null, false, getResString("err.not.exist", new String[] { getResString("diy.form") }));
/*     */         return;
/*     */       } 
/* 198 */       this.formBiz.dropTable(form.getFormTableName());
/* 199 */       this.formBiz.deleteEntity(((FormEntity)forms.get(i)).getFormId().intValue());
/*     */     } 
/* 201 */     outJson(response, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("保存自定义表单接口")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "formTableName", value = "自定义表单表名", required = true, paramType = "query"), @ApiImplicitParam(name = "formTipsName", value = "自定义表单提示文字", required = false, paramType = "query"), @ApiImplicitParam(name = "dfManagerid", value = "自定义表单关联的关联员id", required = false, paramType = "query"), @ApiImplicitParam(name = "formAppId", value = "自定义表单关联的应用编号", required = false, paramType = "query"), @ApiImplicitParam(name = "formUrl", value = "表单的访问地址", required = false, paramType = "query")})
/*     */   @PostMapping({"/save"})
/*     */   @RequiresPermissions({"mdiy:form:save"})
/*     */   public void save(@ModelAttribute @ApiIgnore FormEntity form, HttpServletRequest request, HttpServletResponse response) {
/* 243 */     if (!StringUtil.checkLength(form.getFormTableName(), 1, 20)) {
/* 244 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("fieldTipsName"), "1", "20" }));
/*     */       return;
/*     */     } 
/* 247 */     if (!StringUtil.checkLength(form.getFormTipsName(), 1, 20)) {
/* 248 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("fieldFieldName"), "1", "20" }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 253 */     ManagerEntity managerSession = (ManagerEntity)BasicUtil.getSession((BaseSessionEnum)SessionConstEnum.MANAGER_SESSION);
/*     */     
/* 255 */     int managerId = managerSession.getManagerId();
/*     */     
/* 257 */     String formTableName = "mdiy_" + form.getFormTableName() + "_" + managerId;
/* 258 */     FormEntity _form = new FormEntity();
/* 259 */     _form.setFormTableName(formTableName);
/*     */     
/* 261 */     if (this.formBiz.getEntity((BaseEntity)_form) != null) {
/* 262 */       outJson(response, null, false, getResString("err.exist", new String[] { getResString("diy.form.table.name") }));
/*     */       
/*     */       return;
/*     */     } 
/* 266 */     int appId = getAppId(request);
/*     */     
/* 268 */     form.setAppId(BasicUtil.getAppId());
/*     */     
/* 270 */     String tableName = "mdiy_" + form.getFormTableName() + "_" + managerId;
/* 271 */     form.setFormTableName(tableName);
/*     */ 
/*     */     
/* 274 */     this.formBiz.createDiyFormTable(form.getFormTableName(), null);
/*     */     
/* 276 */     this.formBiz.saveEntity((BaseEntity)form);
/* 277 */     _form.setAppId(BasicUtil.getAppId());
/* 278 */     _form = (FormEntity)this.formBiz.getEntity((BaseEntity)_form);
/* 279 */     int diyFormId = _form.getFormId().intValue();
/* 280 */     outJson(response, null, true, String.valueOf(diyFormId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("更新自定义表单表信息接口")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "formTableName", value = "自定义表单表名", required = true, paramType = "query"), @ApiImplicitParam(name = "formTipsName", value = "自定义表单提示文字", required = false, paramType = "query"), @ApiImplicitParam(name = "dfManagerid", value = "自定义表单关联的关联员id", required = false, paramType = "query"), @ApiImplicitParam(name = "updateBy", value = "最后更新用户编号", required = false, paramType = "query"), @ApiImplicitParam(name = "updateDate", value = "最后更新日期", required = false, paramType = "query")})
/*     */   @PostMapping({"/update"})
/*     */   @RequiresPermissions({"mdiy:form:update"})
/*     */   public void update(@ModelAttribute @ApiIgnore FormEntity form, HttpServletResponse response, HttpServletRequest request) {
/* 321 */     if (!StringUtil.checkLength(form.getFormTableName(), 1, 20)) {
/* 322 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("fieldTipsName"), "1", "20" }));
/*     */       return;
/*     */     } 
/* 325 */     if (!StringUtil.checkLength(form.getFormTipsName(), 1, 20)) {
/* 326 */       outJson(response, null, false, getResString("err.length", new String[] { getResString("fieldFieldName"), "1", "20" }));
/*     */       return;
/*     */     } 
/* 329 */     FormEntity _form = new FormEntity();
/* 330 */     _form.setFormTableName(form.getFormTableName());
/* 331 */     _form.setAppId(BasicUtil.getAppId());
/* 332 */     _form = (FormEntity)this.formBiz.getEntity((BaseEntity)_form);
/*     */     
/* 334 */     int formId = _form.getFormId().intValue();
/* 335 */     form.setFormId(Integer.valueOf(formId));
/*     */     
/* 337 */     this.formBiz.updateEntity((BaseEntity)form);
/*     */     
/* 339 */     outJson(response, null, true, String.valueOf(formId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("验证自定义表名合法性接口")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "formId", value = "自定义表单编号", required = true, paramType = "query"), @ApiImplicitParam(name = "formTableName", value = "自定义表单表名", required = true, paramType = "query")})
/*     */   @GetMapping({"/checkTableNameExist"})
/*     */   public void checkTableNameExist(@ModelAttribute @ApiIgnore FormEntity form, HttpServletRequest request, HttpServletResponse response) {
/* 356 */     ManagerEntity managerSession = (ManagerEntity)BasicUtil.getSession((BaseSessionEnum)SessionConstEnum.MANAGER_SESSION);
/*     */     
/* 358 */     int managerId = managerSession.getManagerId();
/*     */     
/* 360 */     String formTableName = "mdiy_" + form.getFormTableName() + "_" + managerId;
/* 361 */     FormEntity _form = new FormEntity();
/* 362 */     _form.setFormTableName(formTableName);
/* 363 */     _form = (FormEntity)this.formBiz.getEntity((BaseEntity)_form);
/* 364 */     if (_form == null) {
/* 365 */       outJson(response, null, false);
/*     */       return;
/*     */     } 
/* 368 */     outJson(response, null, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("加载自定义表单的数据列表页面接口")
/*     */   @ApiImplicitParam(name = "formId", value = "自定义表单编号", required = true, paramType = "query")
/*     */   @GetMapping({"/querydata"})
/*     */   public String query(@ModelAttribute @ApiIgnore FormEntity form, HttpServletRequest request, @ApiIgnore ModelMap model) {
/* 382 */     int pageNo = 1;
/*     */     
/* 384 */     if (request.getParameter("pageNo") != null) {
/* 385 */       pageNo = Integer.parseInt(request.getParameter("pageNo"));
/*     */     }
/*     */     
/* 388 */     int appId = BasicUtil.getAppId();
/* 389 */     int count = this.formBiz.countDiyFormData(form.getFormId().intValue(), appId);
/* 390 */     Map map = this.formBiz.queryDiyFormData(form.getFormId().intValue(), appId, null);
/* 391 */     if (map != null) {
/* 392 */       List<FormFieldEntity> fields = (List<FormFieldEntity>)map.get("fields");
/* 393 */       if (fields != null) {
/* 394 */         model.addAttribute("fields", fields);
/*     */       }
/* 396 */       if (map.get("list") != null) {
/* 397 */         model.addAttribute("list", map.get("list"));
/*     */       }
/*     */     } 
/*     */     
/* 401 */     model.addAttribute("title", request.getParameter("title"));
/* 402 */     return "/mdiy/diy_form/diy_form_data_list";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ApiOperation("根据id删除自定义表单接口")
/*     */   @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "记录编号", required = true, paramType = "path"), @ApiImplicitParam(name = "diyFormId", value = "表单编号", required = true, paramType = "path")})
/*     */   @PostMapping({"/{diyFormId}/{id}/delete"})
/*     */   @ResponseBody
/*     */   @RequiresPermissions({"mdiy:form:del"})
/*     */   public void delete(@ApiIgnore @PathVariable("id") int id, @ApiIgnore @PathVariable("diyFormId") int diyFormId, HttpServletRequest request, HttpServletResponse response) {
/* 421 */     this.formBiz.deleteQueryDiyFormData(id, diyFormId);
/* 422 */     outJson(response, null, true);
/*     */   }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\action\FormAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */