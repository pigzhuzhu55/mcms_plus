/*     */ package net.mingsoft.mdiy.bean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PageBean
/*     */ {
/*     */   private int nextId;
/*     */   private int total;
/*     */   private int size;
/*     */   private int preId;
/*  28 */   private int pageNo = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   private String preUrl;
/*     */ 
/*     */ 
/*     */   
/*     */   private String nextUrl;
/*     */ 
/*     */ 
/*     */   
/*     */   private String indexUrl;
/*     */ 
/*     */ 
/*     */   
/*     */   private String lastUrl;
/*     */ 
/*     */ 
/*     */   
/*     */   private int searchTotal;
/*     */ 
/*     */ 
/*     */   
/*  52 */   public int getSearchTotal() { return this.searchTotal; }
/*     */ 
/*     */   
/*  55 */   public void setSearchTotal(int searchTotal) { this.searchTotal = searchTotal; }
/*     */ 
/*     */   
/*  58 */   public int getNextId() { return this.nextId; }
/*     */ 
/*     */   
/*  61 */   public void setNextId(int nextId) { this.nextId = nextId; }
/*     */ 
/*     */   
/*  64 */   public int getTotal() { return this.total; }
/*     */ 
/*     */   
/*  67 */   public void setTotal(int total) { this.total = total; }
/*     */ 
/*     */   
/*  70 */   public int getSize() { return this.size; }
/*     */ 
/*     */   
/*  73 */   public void setSize(int size) { this.size = size; }
/*     */ 
/*     */   
/*  76 */   public int getPreId() { return this.preId; }
/*     */ 
/*     */   
/*  79 */   public void setPreId(int preId) { this.preId = preId; }
/*     */ 
/*     */   
/*  82 */   public int getPageNo() { return this.pageNo; }
/*     */ 
/*     */   
/*  85 */   public void setPageNo(int pageNo) { this.pageNo = pageNo; }
/*     */ 
/*     */   
/*  88 */   public String getPreUrl() { return this.preUrl; }
/*     */ 
/*     */   
/*  91 */   public void setPreUrl(String preUrl) { this.preUrl = preUrl; }
/*     */ 
/*     */   
/*  94 */   public String getNextUrl() { return this.nextUrl; }
/*     */ 
/*     */   
/*  97 */   public void setNextUrl(String nextUrl) { this.nextUrl = nextUrl; }
/*     */ 
/*     */   
/* 100 */   public String getIndexUrl() { return this.indexUrl; }
/*     */ 
/*     */   
/* 103 */   public void setIndexUrl(String indexUrl) { this.indexUrl = indexUrl; }
/*     */ 
/*     */   
/* 106 */   public String getLastUrl() { return this.lastUrl; }
/*     */ 
/*     */   
/* 109 */   public void setLastUrl(String lastUrl) { this.lastUrl = lastUrl; }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\bean\PageBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */