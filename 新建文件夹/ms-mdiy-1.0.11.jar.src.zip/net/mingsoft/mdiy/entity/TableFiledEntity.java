/*     */ package net.mingsoft.mdiy.entity;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import java.util.Date;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import org.springframework.format.annotation.DateTimeFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableFiledEntity
/*     */   extends BaseEntity
/*     */ {
/*     */   private static final long serialVersionUID = 1543309653139L;
/*     */   private Integer tableId;
/*     */   private Integer tfSort;
/*     */   private String tfName;
/*     */   private String tfType;
/*     */   private String tfDefault;
/*     */   private String tfDescription;
/*     */   private Integer tfUnique;
/*     */   private Integer tfRequired;
/*     */   private String tfConfig;
/*     */   private String tfHelp;
/*     */   @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
/*     */   @DateTimeFormat(pattern = "yyyy-MM-dd")
/*     */   private Date createDate;
/*     */   @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
/*     */   @DateTimeFormat(pattern = "yyyy-MM-dd")
/*     */   private Date updateDate;
/*     */   
/*  78 */   public void setTableId(Integer tableId) { this.tableId = tableId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public Integer getTableId() { return this.tableId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public void setTfName(String tfName) { this.tfName = tfName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public String getTfName() { return this.tfName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public void setTfType(String tfType) { this.tfType = tfType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public String getTfType() { return this.tfType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public void setTfDefault(String tfDefault) { this.tfDefault = tfDefault; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public String getTfDefault() { return this.tfDefault; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public void setTfDescription(String tfDescription) { this.tfDescription = tfDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public String getTfDescription() { return this.tfDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   public void setTfUnique(Integer tfUnique) { this.tfUnique = tfUnique; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public Integer getTfUnique() { return this.tfUnique; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public void setTfRequired(Integer tfRequired) { this.tfRequired = tfRequired; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public Integer getTfRequired() { return this.tfRequired; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   public void setTfConfig(String tfConfig) { this.tfConfig = tfConfig; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   public String getTfConfig() { return this.tfConfig; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public void setTfHelp(String tfHelp) { this.tfHelp = tfHelp; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 189 */   public String getTfHelp() { return this.tfHelp; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   public void setCreateDate(Date createDate) { this.createDate = createDate; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   public Date getCreateDate() { return this.createDate; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 208 */   public void setUpdateDate(Date updateDate) { this.updateDate = updateDate; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   public Date getUpdateDate() { return this.updateDate; }
/*     */ 
/*     */ 
/*     */   
/* 219 */   public Integer getTfSort() { return this.tfSort; }
/*     */ 
/*     */ 
/*     */   
/* 223 */   public void setTfSort(Integer tfSort) { this.tfSort = tfSort; }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\entity\TableFiledEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */