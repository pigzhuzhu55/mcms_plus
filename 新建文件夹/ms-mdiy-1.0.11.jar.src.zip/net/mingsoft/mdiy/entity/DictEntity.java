/*     */ package net.mingsoft.mdiy.entity;
/*     */ 
/*     */ import net.mingsoft.basic.entity.BaseEntity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DictEntity
/*     */   extends BaseEntity
/*     */ {
/*     */   private static final long serialVersionUID = 1502518956351L;
/*     */   private Integer dictId;
/*     */   private Integer dictAppId;
/*     */   private String dictValue;
/*     */   private String dictLabel;
/*     */   private String dictType;
/*     */   private String dictDescription;
/*     */   private Integer dictSort;
/*     */   private String dictParentId;
/*     */   private String isChild;
/*     */   private String dictRemarks;
/*     */   
/*  63 */   public void setDictId(Integer dictId) { this.dictId = dictId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public Integer getDictId() { return this.dictId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public void setDictAppId(Integer dictAppId) { this.dictAppId = dictAppId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public Integer getDictAppId() { return this.dictAppId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public void setDictValue(String dictValue) { this.dictValue = dictValue; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public String getDictValue() { return this.dictValue; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void setDictLabel(String dictLabel) { this.dictLabel = dictLabel; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public String getDictLabel() { return this.dictLabel; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public void setDictType(String dictType) { this.dictType = dictType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public String getDictType() { return this.dictType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public void setDictDescription(String dictDescription) { this.dictDescription = dictDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public String getDictDescription() { return this.dictDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public void setDictSort(Integer dictSort) { this.dictSort = dictSort; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public Integer getDictSort() { return this.dictSort; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public void setDictParentId(String dictParentId) { this.dictParentId = dictParentId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   public String getDictParentId() { return this.dictParentId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   public void setDictRemarks(String dictRemarks) { this.dictRemarks = dictRemarks; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 183 */   public String getDictRemarks() { return this.dictRemarks; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 189 */   public String getIsChild() { return this.isChild; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   public void setIsChild(String isChild) { this.isChild = isChild; }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\entity\DictEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */