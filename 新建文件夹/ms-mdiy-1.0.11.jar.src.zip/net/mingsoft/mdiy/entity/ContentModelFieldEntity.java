/*     */ package net.mingsoft.mdiy.entity;
/*     */ 
/*     */ import net.mingsoft.base.constant.e.TableCloumnEnum;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.mdiy.constant.e.ContentModelFieldEnum;
/*     */ import net.mingsoft.mdiy.constant.e.FieldSearchEnum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentModelFieldEntity
/*     */   extends BaseEntity
/*     */ {
/*     */   private int fieldId;
/*     */   private String fieldTipsName;
/*     */   private String fieldFieldName;
/*     */   private int fieldType;
/*     */   private String fieldTypeString;
/*     */   private String fieldDefault;
/*     */   private int fieldCmid;
/*     */   private int fieldIsNull;
/*     */   private int fieldIsSearch;
/*  69 */   private int fieldLength = 1;
/*     */ 
/*     */   
/*  72 */   public String getFieldTypeString() { return ContentModelFieldEnum.get(getFieldType()).toString(); }
/*     */ 
/*     */ 
/*     */   
/*  76 */   public void setFieldTypeString(String fieldTypeString) { this.fieldTypeString = fieldTypeString; }
/*     */ 
/*     */ 
/*     */   
/*  80 */   public int getFieldLength() { return this.fieldLength; }
/*     */ 
/*     */   
/*     */   public void setFieldLength(int fieldLength) {
/*  84 */     if (this.fieldLength <= 0) {
/*  85 */       this.fieldLength = 11;
/*     */     } else {
/*  87 */       this.fieldLength = fieldLength;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public int getFieldIsSearch() { return this.fieldIsSearch; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/* 105 */   public void setFieldIsSearch(int fieldIsSearch) { this.fieldIsSearch = fieldIsSearch; }
/*     */ 
/*     */ 
/*     */   
/* 109 */   public void setFieldIsSearch(FieldSearchEnum fieldIsSearch) { this.fieldIsSearch = fieldIsSearch.toInt(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public int getFieldId() { return this.fieldId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public void setFieldId(int fieldId) { this.fieldId = fieldId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public String getFieldTipsName() { return this.fieldTipsName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public void setFieldTipsName(String fieldTipsName) { this.fieldTipsName = fieldTipsName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public String getFieldFieldName() { return this.fieldFieldName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public void setFieldFieldName(String fieldFieldName) { this.fieldFieldName = fieldFieldName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   public int getFieldType() { return this.fieldType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldColumnType() {
/* 187 */     if (getFieldType() == ContentModelFieldEnum.DATE.toInt())
/* 188 */       return TableCloumnEnum.DATETIME.toString(); 
/* 189 */     if (getFieldType() == ContentModelFieldEnum.FLOAT.toInt())
/* 190 */       return TableCloumnEnum.FLOAT.toString() + "(10)"; 
/* 191 */     if (getFieldType() == ContentModelFieldEnum.INT.toInt())
/* 192 */       return TableCloumnEnum.INT.toString() + "(11)"; 
/* 193 */     if (getFieldType() == ContentModelFieldEnum.HTML.toInt()) {
/* 194 */       return TableCloumnEnum.TEXT.toString();
/*     */     }
/* 196 */     return TableCloumnEnum.VARCHAR.toString() + "(1000)";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 207 */   public void setFieldType(int fieldType) { this.fieldType = fieldType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 216 */   public int getFieldCmid() { return this.fieldCmid; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public void setFieldCmid(int fieldCmid) { this.fieldCmid = fieldCmid; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldDefault() {
/* 234 */     if (this.fieldType == ContentModelFieldEnum.DATE.toInt() || this.fieldType == ContentModelFieldEnum.HTML
/* 235 */       .toInt()) {
/* 236 */       return null;
/*     */     }
/*     */     
/* 239 */     if (this.fieldDefault == null || this.fieldDefault.length() == 0) {
/* 240 */       return null;
/*     */     }
/* 242 */     return this.fieldDefault;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 251 */   public void setFieldDefault(String fieldDefault) { this.fieldDefault = fieldDefault; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 260 */   public int getFieldIsNull() { return this.fieldIsNull; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 269 */   public void setFieldIsNull(int fieldIsNull) { this.fieldIsNull = fieldIsNull; }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\entity\ContentModelFieldEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */