/*    */ package net.mingsoft.mdiy.entity;
/*    */ 
/*    */ import net.mingsoft.base.entity.BaseEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TagEntity
/*    */   extends BaseEntity
/*    */ {
/*    */   private static final long serialVersionUID = 1540341874663L;
/*    */   private String tagName;
/*    */   private int tagType;
/*    */   private String tagDescription;
/*    */   
/* 32 */   public void setTagName(String tagName) { this.tagName = tagName; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   public String getTagName() { return this.tagName; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public void setTagType(int tagType) { this.tagType = tagType; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   public int getTagType() { return this.tagType; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   public void setTagDescription(String tagDescription) { this.tagDescription = tagDescription; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 65 */   public String getTagDescription() { return this.tagDescription; }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\entity\TagEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */