/*     */ package net.mingsoft.mdiy.entity;
/*     */ 
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PageEntity
/*     */   extends BaseEntity
/*     */ {
/*     */   private static final long serialVersionUID = 1502431314331L;
/*     */   private Integer pageId;
/*     */   private Integer pageModelId;
/*     */   private Integer pageAppId;
/*     */   private String pagePath;
/*     */   private String pageTitle;
/*     */   private String pageKey;
/*     */   
/*  50 */   public void setPageId(Integer pageId) { this.pageId = pageId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public Integer getPageId() { return this.pageId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public void setPageModelId(Integer pageModelId) { this.pageModelId = pageModelId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public Integer getPageModelId() { return this.pageModelId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public void setPageAppId(Integer pageAppId) { this.pageAppId = pageAppId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public Integer getPageAppId() { return this.pageAppId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public void setPagePath(String pagePath) { this.pagePath = pagePath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public String getPagePath() { return this.pagePath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public void setPageTitle(String pageTitle) { this.pageTitle = pageTitle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public String getPageTitle() { return this.pageTitle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public void setPageKey(String pageKey) { this.pageKey = pageKey; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public String getPageKey() { return this.pageKey; }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\entity\PageEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */