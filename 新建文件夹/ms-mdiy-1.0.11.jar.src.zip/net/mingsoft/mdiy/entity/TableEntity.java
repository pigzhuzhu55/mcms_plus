/*     */ package net.mingsoft.mdiy.entity;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import java.util.Date;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import org.springframework.format.annotation.DateTimeFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableEntity
/*     */   extends BaseEntity
/*     */ {
/*     */   private static final long serialVersionUID = 1543309653613L;
/*     */   private Integer appId;
/*     */   private String tableName;
/*     */   private String tableMaster;
/*     */   private String tableMasterId;
/*     */   @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
/*     */   @DateTimeFormat(pattern = "yyyy-MM-dd")
/*     */   private Date createDate;
/*     */   @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
/*     */   @DateTimeFormat(pattern = "yyyy-MM-dd")
/*     */   private Date updateDate;
/*     */   
/*  55 */   public void setAppId(Integer appId) { this.appId = appId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public Integer getAppId() { return this.appId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public void setTableName(String tableName) { this.tableName = tableName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public String getTableName() { return this.tableName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public void setTableMaster(String tableMaster) { this.tableMaster = tableMaster; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public String getTableMaster() { return this.tableMaster; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public void setTableMasterId(String tableMasterId) { this.tableMasterId = tableMasterId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public String getTableMasterId() { return this.tableMasterId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public void setCreateDate(Date createDate) { this.createDate = createDate; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public Date getCreateDate() { return this.createDate; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public void setUpdateDate(Date updateDate) { this.updateDate = updateDate; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public Date getUpdateDate() { return this.updateDate; }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\entity\TableEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */