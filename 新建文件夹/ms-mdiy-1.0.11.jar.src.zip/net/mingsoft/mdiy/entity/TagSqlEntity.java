/*    */ package net.mingsoft.mdiy.entity;
/*    */ 
/*    */ import net.mingsoft.base.entity.BaseEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TagSqlEntity
/*    */   extends BaseEntity
/*    */ {
/*    */   private static final long serialVersionUID = 1543203721085L;
/*    */   private Integer tagId;
/*    */   private String tagSql;
/*    */   private String sort;
/*    */   
/* 39 */   public void setTagId(Integer tagId) { this.tagId = tagId; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   public Integer getTagId() { return this.tagId; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   public void setTagSql(String tagSql) { this.tagSql = tagSql; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 59 */   public String getTagSql() { return this.tagSql; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 65 */   public void setSort(String sort) { this.sort = sort; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 72 */   public String getSort() { return this.sort; }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\entity\TagSqlEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */