/*     */ package net.mingsoft.mdiy.entity;
/*     */ 
/*     */ import net.mingsoft.basic.entity.BaseEntity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SearchEntity
/*     */   extends BaseEntity
/*     */ {
/*     */   private int searchId;
/*     */   private String searchName;
/*     */   private String searchTemplets;
/*     */   private String searchType;
/*     */   
/*  64 */   public int getSearchId() { return this.searchId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public void setSearchId(int searchId) { this.searchId = searchId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public String getSearchName() { return this.searchName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public void setSearchName(String searchName) { this.searchName = searchName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public String getSearchTemplets() { return this.searchTemplets; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public void setSearchTemplets(String searchTemplets) { this.searchTemplets = searchTemplets; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public String getSearchType() { return this.searchType; }
/*     */ 
/*     */ 
/*     */   
/* 113 */   public void setSearchType(String searchType) { this.searchType = searchType; }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\entity\SearchEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */