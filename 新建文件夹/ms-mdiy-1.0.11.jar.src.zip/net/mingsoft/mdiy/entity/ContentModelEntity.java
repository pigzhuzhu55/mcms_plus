/*    */ package net.mingsoft.mdiy.entity;
/*    */ 
/*    */ import net.mingsoft.basic.entity.BaseEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentModelEntity
/*    */   extends BaseEntity
/*    */ {
/*    */   private int cmId;
/*    */   private String cmTipsName;
/*    */   private String cmTableName;
/*    */   private int cmModelId;
/*    */   
/* 42 */   public int getCmId() { return this.cmId; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   public void setCmId(int cmId) { this.cmId = cmId; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   public String getCmTipsName() { return this.cmTipsName; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 66 */   public void setCmTipsName(String cmTipsName) { this.cmTipsName = cmTipsName; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 74 */   public String getCmTableName() { return this.cmTableName; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 82 */   public void setCmTableName(String cmTableName) { this.cmTableName = cmTableName; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 87 */   public int getCmModelId() { return this.cmModelId; }
/*    */ 
/*    */ 
/*    */   
/* 91 */   public void setCmModelId(int cmModelId) { this.cmModelId = cmModelId; }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\entity\ContentModelEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */