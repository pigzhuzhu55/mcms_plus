/*     */ package net.mingsoft.mdiy.entity;
/*     */ 
/*     */ import net.mingsoft.base.constant.e.TableCloumnEnum;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.mdiy.constant.e.DiyFormFieldEnum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormFieldEntity
/*     */   extends BaseEntity
/*     */ {
/*     */   private String diyFormFieldDefault;
/*     */   private String diyFormFieldFieldName;
/*     */   private int diyFormFieldFormId;
/*     */   private int diyFormFieldId;
/*     */   private int diyFormFieldIsNull;
/*     */   private int diyFormFieldSort;
/*     */   private String diyFormFieldTipsName;
/*  59 */   private int diyFormFieldLength = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int diyFormFieldType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public int getDiyFormFieldLength() { return this.diyFormFieldLength; }
/*     */ 
/*     */ 
/*     */   
/*  75 */   public void setDiyFormFieldLength(int diyFormFieldLength) { this.diyFormFieldLength = diyFormFieldLength; }
/*     */ 
/*     */   
/*     */   public String getDiyFormFieldDefault() {
/*  79 */     if ("0".equals(this.diyFormFieldDefault) || "null".equals(this.diyFormFieldDefault)) {
/*  80 */       if (this.diyFormFieldType == DiyFormFieldEnum.DATE.toInt() || this.diyFormFieldType == DiyFormFieldEnum.TEXTAREA
/*  81 */         .toInt())
/*  82 */         return "null"; 
/*  83 */       if (this.diyFormFieldType == DiyFormFieldEnum.FLOAT.toInt() || this.diyFormFieldType == DiyFormFieldEnum.INT
/*  84 */         .toInt()) {
/*  85 */         return "0";
/*     */       }
/*     */     } else {
/*  88 */       return this.diyFormFieldDefault;
/*     */     } 
/*     */     
/*  91 */     return this.diyFormFieldDefault;
/*     */   }
/*     */ 
/*     */   
/*  95 */   public String getDiyFormFieldFieldName() { return this.diyFormFieldFieldName.toUpperCase(); }
/*     */ 
/*     */ 
/*     */   
/*  99 */   public int getDiyFormFieldFormId() { return this.diyFormFieldFormId; }
/*     */ 
/*     */ 
/*     */   
/* 103 */   public int getDiyFormFieldId() { return this.diyFormFieldId; }
/*     */ 
/*     */ 
/*     */   
/* 107 */   public int getDiyFormFieldIsNull() { return this.diyFormFieldIsNull; }
/*     */ 
/*     */ 
/*     */   
/* 111 */   public int getDiyFormFieldSort() { return this.diyFormFieldSort; }
/*     */ 
/*     */ 
/*     */   
/* 115 */   public String getDiyFormFieldTipsName() { return this.diyFormFieldTipsName; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public int getDiyFormFieldType() { return this.diyFormFieldType; }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDiyFormFieldColumnType() {
/* 125 */     if (getDiyFormFieldType() == DiyFormFieldEnum.DATE.toInt())
/* 126 */       return TableCloumnEnum.DATETIME.toString(); 
/* 127 */     if (getDiyFormFieldType() == DiyFormFieldEnum.FLOAT.toInt())
/* 128 */       return TableCloumnEnum.FLOAT.toString() + "(11)"; 
/* 129 */     if (getDiyFormFieldType() == DiyFormFieldEnum.INT.toInt())
/* 130 */       return TableCloumnEnum.INT.toString() + "(11)"; 
/* 131 */     if (getDiyFormFieldType() == DiyFormFieldEnum.TEXTAREA.toInt()) {
/* 132 */       return TableCloumnEnum.TEXT.toString();
/*     */     }
/* 134 */     return TableCloumnEnum.VARCHAR.toString() + "(100)";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public void setDiyFormFieldDefault(String diyFormFieldDefault) { this.diyFormFieldDefault = diyFormFieldDefault; }
/*     */ 
/*     */   
/* 144 */   public void setDiyFormFieldFieldName(String diyFormFieldFieldName) { this.diyFormFieldFieldName = diyFormFieldFieldName; }
/*     */ 
/*     */ 
/*     */   
/* 148 */   public void setDiyFormFieldFormId(int diyFormFieldFormId) { this.diyFormFieldFormId = diyFormFieldFormId; }
/*     */ 
/*     */ 
/*     */   
/* 152 */   public void setDiyFormFieldId(int diyFormFieldId) { this.diyFormFieldId = diyFormFieldId; }
/*     */ 
/*     */ 
/*     */   
/* 156 */   public void setDiyFormFieldIsNull(int diyFormFieldIsNull) { this.diyFormFieldIsNull = diyFormFieldIsNull; }
/*     */ 
/*     */ 
/*     */   
/* 160 */   public void setDiyFormFieldSort(int diyFormFieldSort) { this.diyFormFieldSort = diyFormFieldSort; }
/*     */ 
/*     */ 
/*     */   
/* 164 */   public void setDiyFormFieldTipsName(String diyFormFieldTipsName) { this.diyFormFieldTipsName = diyFormFieldTipsName; }
/*     */ 
/*     */ 
/*     */   
/* 168 */   public void setDiyFormFieldType(DiyFormFieldEnum diyFormFieldType) { this.diyFormFieldType = diyFormFieldType.toInt(); }
/*     */ 
/*     */ 
/*     */   
/* 172 */   public void setDiyFormFieldType(int diyFormFieldType) { this.diyFormFieldType = diyFormFieldType; }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\entity\FormFieldEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */