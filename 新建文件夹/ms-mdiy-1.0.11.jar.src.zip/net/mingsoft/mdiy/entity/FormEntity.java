/*     */ package net.mingsoft.mdiy.entity;
/*     */ 
/*     */ import cn.hutool.crypto.SecureUtil;
/*     */ import net.mingsoft.basic.entity.BaseEntity;
/*     */ import net.mingsoft.basic.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormEntity
/*     */   extends BaseEntity
/*     */ {
/*     */   private static final long serialVersionUID = 1502524709328L;
/*     */   private Integer formId;
/*     */   private String formTipsName;
/*     */   private String formTableName;
/*     */   private Integer dfManagerid;
/*     */   private Integer formAppId;
/*     */   private String formUrl;
/*     */   
/*  48 */   public void setFormId(Integer formId) { this.formId = formId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public Integer getFormId() { return this.formId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public void setFormTipsName(String formTipsName) { this.formTipsName = formTipsName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public String getFormTipsName() { return this.formTipsName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public void setFormTableName(String formTableName) { this.formTableName = formTableName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public String getFormTableName() { return this.formTableName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public void setDfManagerid(Integer dfManagerid) { this.dfManagerid = dfManagerid; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public Integer getDfManagerid() { return this.dfManagerid; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public void setFormAppId(Integer formAppId) { this.formAppId = formAppId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public Integer getFormAppId() { return this.formAppId; }
/*     */   
/*     */   public String getFormUrl() {
/* 114 */     if (StringUtil.isInteger(this.formId)) {
/* 115 */       this.formUrl = SecureUtil.aes(SecureUtil.md5(getAppId() + "").substring(16).getBytes()).encryptHex(this.formId + "");
/*     */     }
/* 117 */     return this.formUrl;
/*     */   }
/*     */ 
/*     */   
/* 121 */   public void setFormUrl(String formUrl) { this.formUrl = formUrl; }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-mdiy\1.0.11\ms-mdiy-1.0.11.jar!\net\mingsoft\mdiy\entity\FormEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */