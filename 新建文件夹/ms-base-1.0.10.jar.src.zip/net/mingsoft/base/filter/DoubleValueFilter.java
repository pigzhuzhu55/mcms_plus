/*    */ package net.mingsoft.base.filter;
/*    */ 
/*    */ import com.alibaba.fastjson.serializer.ValueFilter;
/*    */ import java.math.BigDecimal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleValueFilter
/*    */   implements ValueFilter
/*    */ {
/* 37 */   private int digits = 2;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DoubleValueFilter() {}
/*    */ 
/*    */ 
/*    */   
/* 46 */   public DoubleValueFilter(int digits) { this.digits = digits; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object process(Object object, String name, Object value) {
/* 52 */     if (value instanceof BigDecimal || value instanceof Double || value instanceof Float) {
/* 53 */       return (new BigDecimal(value.toString())).setScale(this.digits, 4);
/*    */     }
/* 55 */     return value;
/*    */   }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\base\filter\DoubleValueFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */