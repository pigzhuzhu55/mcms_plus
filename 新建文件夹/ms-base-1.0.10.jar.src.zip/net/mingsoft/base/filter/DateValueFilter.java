/*    */ package net.mingsoft.base.filter;
/*    */ 
/*    */ import com.alibaba.fastjson.serializer.ValueFilter;
/*    */ import java.text.SimpleDateFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateValueFilter
/*    */   implements ValueFilter
/*    */ {
/* 40 */   private static String fmt = "yyyy-MM-dd HH:mm:ss";
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DateValueFilter() {}
/*    */ 
/*    */ 
/*    */   
/* 49 */   public DateValueFilter(String fmt) { this; DateValueFilter.fmt = fmt; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object process(Object object, String name, Object value) {
/* 55 */     if (value instanceof java.util.Date || value instanceof java.sql.Timestamp) {
/* 56 */       this; SimpleDateFormat sdf = new SimpleDateFormat(fmt);
/* 57 */       return sdf.format(value);
/*    */     } 
/* 59 */     return value;
/*    */   }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\base\filter\DateValueFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */