/*     */ package net.mingsoft.base.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseFilter
/*     */   implements Filter
/*     */ {
/*  57 */   protected Logger logger = LoggerFactory.getLogger(getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain) throws IOException, ServletException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log4jPrintOut(ServletRequest request, ServletResponse response) {
/*  79 */     HttpServletRequest httpRequest = (HttpServletRequest)request;
/*     */     
/*  81 */     if (this.logger.isDebugEnabled()) {
/*  82 */       StringBuffer sb = new StringBuffer();
/*     */       
/*  84 */       sb.append("Logging : \n");
/*  85 */       sb.append("--- Request URL: ---\n").append("\t").append(httpRequest
/*  86 */           .getRequestURL()).append("\n");
/*     */       
/*  88 */       Enumeration<String> names = httpRequest.getParameterNames();
/*  89 */       sb.append("--- Request Parameters: ---\n");
/*  90 */       while (names.hasMoreElements()) {
/*  91 */         String name = names.nextElement();
/*  92 */         sb.append("\t").append(name).append(":").append(httpRequest
/*  93 */             .getParameter(name)).append("\n");
/*     */       } 
/*  95 */       names = httpRequest.getAttributeNames();
/*  96 */       sb.append("--- Request Attributes: ---\n");
/*  97 */       while (names.hasMoreElements()) {
/*  98 */         String name = names.nextElement();
/*  99 */         sb.append("\t").append(name).append(":").append(httpRequest
/* 100 */             .getAttribute(name)).append("\n");
/*     */       } 
/* 102 */       names = httpRequest.getHeaderNames();
/* 103 */       sb.append("--- Request Heards: ---\n");
/* 104 */       while (names.hasMoreElements()) {
/* 105 */         String name = names.nextElement();
/* 106 */         sb.append("\t").append(name).append(":").append(httpRequest
/* 107 */             .getHeader(name)).append("\n");
/*     */       } 
/*     */       
/* 110 */       names = httpRequest.getSession().getAttributeNames();
/* 111 */       sb.append("--- Request Sessions: ---\n");
/* 112 */       while (names.hasMoreElements()) {
/* 113 */         String name = names.nextElement();
/* 114 */         sb.append("\t").append(name).append(":").append(httpRequest
/* 115 */             .getSession().getAttribute(name)).append("\n");
/*     */       } 
/*     */ 
/*     */       
/* 119 */       Cookie[] cookies = httpRequest.getCookies();
/* 120 */       sb.append("--- Request Cookies: ---\n");
/* 121 */       if (cookies != null) {
/* 122 */         for (int i = 0; i < cookies.length; i++) {
/* 123 */           Cookie thisCookie = cookies[i];
/* 124 */           sb.append("\t").append(thisCookie.getName()).append(":")
/* 125 */             .append(thisCookie.getValue()).append("\n");
/*     */         } 
/*     */       }
/* 128 */       this.logger.debug(sb.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void init(FilterConfig filterConfig) throws ServletException {}
/*     */   
/*     */   public void destroy() {}
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\base\filter\BaseFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */