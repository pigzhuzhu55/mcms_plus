/*    */ package net.mingsoft.base.constant;
/*    */ 
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Const
/*    */ {
/* 41 */   public static final ResourceBundle RESOURCES = ResourceBundle.getBundle("net.mingsoft.base.resources.resources");
/*    */   public static final String UTF8 = "utf-8";
/*    */   public static final String SEPARATOR = "/";
/*    */   public static final String ERROR = "error";
/*    */   public static final String ERROR_500 = "/500/error.do";
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\base\constant\Const.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */