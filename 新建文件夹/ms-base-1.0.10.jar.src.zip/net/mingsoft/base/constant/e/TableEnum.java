/*    */ package net.mingsoft.base.constant.e;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TableEnum
/*    */   implements BaseEnum
/*    */ {
/* 33 */   ALTER_ADD("add"), ALTER_MODIFY("modify"), ALTER_DROP("drop");
/*    */   
/*    */   private String obj;
/*    */   
/* 37 */   TableEnum(String obj) { this.obj = obj; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   public int toInt() { return 0; }
/*    */ 
/*    */ 
/*    */   
/* 47 */   public String toString() { return this.obj.toString(); }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\base\constant\e\TableEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */