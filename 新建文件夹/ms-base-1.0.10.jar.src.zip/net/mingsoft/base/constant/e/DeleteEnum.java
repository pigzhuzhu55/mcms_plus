/*    */ package net.mingsoft.base.constant.e;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum DeleteEnum
/*    */   implements BaseEnum
/*    */ {
/* 38 */   DEL(1, "已删除"),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   NOTDEL(0, "正常");
/*    */ 
/*    */ 
/*    */   
/*    */   private String code;
/*    */ 
/*    */   
/*    */   private int id;
/*    */ 
/*    */ 
/*    */   
/*    */   DeleteEnum(int id, String code) {
/* 55 */     this.code = code;
/* 56 */     this.id = id;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 61 */   public int toInt() { return this.id; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 66 */   public String toString() { return this.code.toString(); }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\base\constant\e\DeleteEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */