/*    */ package net.mingsoft.base.constant.e;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TableCloumnEnum
/*    */   implements BaseEnum
/*    */ {
/* 33 */   VARCHAR(1, "varchar"), TEXT(3, "text"), INT(4, "int"), DATETIME(2, "datetime"), FLOAT(5, "float");
/*    */   private int id;
/*    */   private String obj;
/*    */   
/*    */   TableCloumnEnum(int id, String obj) {
/* 38 */     this.obj = obj;
/* 39 */     this.id = id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public int toInt() { return this.id; }
/*    */ 
/*    */ 
/*    */   
/* 49 */   public String toString() { return this.obj.toString(); }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\base\constant\e\TableCloumnEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */