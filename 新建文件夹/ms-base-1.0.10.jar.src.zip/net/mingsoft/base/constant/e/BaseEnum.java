package net.mingsoft.base.constant.e;

public interface BaseEnum {
  String toString();
  
  int toInt();
}


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\base\constant\e\BaseEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */