package net.mingsoft.base.entity;

public class SessionEntity extends BaseEntity {}


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\base\entity\SessionEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */