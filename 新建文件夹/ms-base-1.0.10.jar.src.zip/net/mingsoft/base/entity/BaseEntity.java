/*     */ package net.mingsoft.base.entity;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.annotation.JsonIgnore;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import javax.xml.bind.annotation.XmlTransient;
/*     */ import net.mingsoft.base.constant.e.DeleteEnum;
/*     */ import org.springframework.format.annotation.DateTimeFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseEntity
/*     */   implements Serializable
/*     */ {
/*     */   @JsonIgnore
/*     */   @XmlTransient
/*     */   protected int createBy;
/*     */   @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
/*     */   @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
/*     */   protected Date createDate;
/*     */   @JsonIgnore
/*     */   @XmlTransient
/*     */   protected int del;
/*     */   protected String id;
/*     */   protected String remarks;
/*     */   @JsonIgnore
/*     */   @XmlTransient
/*     */   protected int updateBy;
/*     */   @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
/*     */   @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
/*     */   protected Date updateDate;
/*     */   @JsonIgnore
/*     */   @XmlTransient
/*     */   protected String sqlWhere;
/*     */   @JsonIgnore
/*     */   @XmlTransient
/*     */   protected String sqlDataScope;
/*     */   @JsonIgnore
/*     */   @XmlTransient
/*     */   protected String orderBy;
/*     */   protected String order;
/*     */   
/* 120 */   public int getCreateBy() { return this.createBy; }
/*     */ 
/*     */ 
/*     */   
/* 124 */   public void setCreateBy(int createBy) { this.createBy = createBy; }
/*     */ 
/*     */ 
/*     */   
/* 128 */   public Date getCreateDate() { return this.createDate; }
/*     */ 
/*     */ 
/*     */   
/* 132 */   public void setCreateDate(Date createDate) { this.createDate = createDate; }
/*     */ 
/*     */ 
/*     */   
/* 136 */   public int getDel() { return this.del; }
/*     */ 
/*     */ 
/*     */   
/* 140 */   public void setDel(DeleteEnum del) { this.del = del.toInt(); }
/*     */ 
/*     */ 
/*     */   
/* 144 */   public void setDel(int del) { this.del = del; }
/*     */ 
/*     */ 
/*     */   
/* 148 */   public String getId() { return this.id; }
/*     */ 
/*     */ 
/*     */   
/* 152 */   public void setId(String id) { this.id = id; }
/*     */ 
/*     */ 
/*     */   
/* 156 */   public String getRemarks() { return this.remarks; }
/*     */ 
/*     */ 
/*     */   
/* 160 */   public void setRemarks(String remarks) { this.remarks = remarks; }
/*     */ 
/*     */ 
/*     */   
/* 164 */   public int getUpdateBy() { return this.updateBy; }
/*     */ 
/*     */ 
/*     */   
/* 168 */   public void setUpdateBy(int updateBy) { this.updateBy = updateBy; }
/*     */ 
/*     */ 
/*     */   
/* 172 */   public Date getUpdateDate() { return this.updateDate; }
/*     */ 
/*     */ 
/*     */   
/* 176 */   public void setUpdateDate(Date updateDate) { this.updateDate = updateDate; }
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonIgnore
/*     */   @XmlTransient
/* 182 */   public String getSqlWhere() { return this.sqlWhere; }
/*     */ 
/*     */ 
/*     */   
/* 186 */   public void setSqlWhere(String sqlWhere) { this.sqlWhere = sqlWhere; }
/*     */ 
/*     */ 
/*     */   
/* 190 */   public String getOrderBy() { return this.orderBy; }
/*     */ 
/*     */ 
/*     */   
/* 194 */   public void setOrderBy(String orderBy) { this.orderBy = orderBy; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 199 */   public String getSqlDataScope() { return this.sqlDataScope; }
/*     */ 
/*     */ 
/*     */   
/* 203 */   public void setSqlDataScope(String sqlDataScope) { this.sqlDataScope = sqlDataScope; }
/*     */ 
/*     */ 
/*     */   
/* 207 */   public String getOrder() { return this.order; }
/*     */ 
/*     */ 
/*     */   
/* 211 */   public void setOrder(String order) { this.order = order; }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\base\entity\BaseEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */