/*     */ package net.mingsoft.base.biz.impl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.mingsoft.base.biz.IBaseBiz;
/*     */ import net.mingsoft.base.constant.e.TableEnum;
/*     */ import net.mingsoft.base.dao.IBaseDao;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseBizImpl<E extends Serializable>
/*     */   implements IBaseBiz
/*     */ {
/*     */   private IBaseDao<E> baseDao;
/*  48 */   protected final Logger LOG = LoggerFactory.getLogger(getClass());
/*     */ 
/*     */ 
/*     */   
/*  52 */   public int saveEntity(BaseEntity entity) { return getDao().saveEntity(entity); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public void deleteEntity(int id) { getDao().deleteEntity(id); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public void updateEntity(BaseEntity entity) { getDao().updateEntity(entity); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public List<E> queryAll() { return getDao().queryAll(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  79 */   public int queryCount() { return getDao().queryCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public BaseEntity getEntity(int id) { return getDao().getEntity(Integer.valueOf(id)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public List queryBySQL(String table, List fields, Map wheres, Integer begin, Integer end) { return getDao().queryBySQL(table, fields, wheres, begin, end, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public int countBySQL(String table, Map wheres) { return getDao().countBySQL(table, wheres); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public List queryBySQL(String table, List fields, Map wheres) { return getDao().queryBySQL(table, fields, wheres, null, null, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public void updateBySQL(String table, Map fields, Map wheres) { getDao().updateBySQL(table, fields, wheres); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public void deleteBySQL(String table, Map wheres) { getDao().deleteBySQL(table, wheres); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public void insertBySQL(String table, Map fields) { getDao().insertBySQL(table, fields); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public void createTable(String table, Map fileds) { getDao().createTable(table, fileds); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public void alterTable(String table, Map fileds, String type) { getDao().alterTable(table, fileds, type); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public void alterTable(String table, Map fileds, TableEnum type) { getDao().alterTable(table, fileds, type.toString()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   public void dropTable(String table) { getDao().dropTable(table); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public Object excuteSql(String sql) { return getDao().excuteSql(sql); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public void saveBatch(List list) { getDao().saveBatch(list); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public void delete(int[] ids) { getDao().delete(ids); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   public void deleteEntity(BaseEntity entity) { getDao().deleteByEntity(entity); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   public E getEntity(BaseEntity entity) { return (E)getDao().getByEntity(entity); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 184 */   public List<E> query(BaseEntity entity) { return getDao().query(entity); }
/*     */   
/*     */   protected abstract IBaseDao<E> getDao();
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\base\biz\impl\BaseBizImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */