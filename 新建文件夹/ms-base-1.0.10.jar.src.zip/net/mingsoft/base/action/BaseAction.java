/*     */ package net.mingsoft.base.action;
/*     */ 
/*     */ import com.alibaba.fastjson.JSONArray;
/*     */ import com.alibaba.fastjson.JSONObject;
/*     */ import com.alibaba.fastjson.serializer.JSONSerializer;
/*     */ import com.alibaba.fastjson.serializer.PropertyFilter;
/*     */ import com.alibaba.fastjson.serializer.SerializeWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.mingsoft.base.constant.Const;
/*     */ import net.mingsoft.base.constant.e.BaseEnum;
/*     */ import net.mingsoft.base.entity.BaseEntity;
/*     */ import net.mingsoft.base.entity.ResultJson;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseAction
/*     */ {
/*  78 */   protected final Logger LOG = LoggerFactory.getLogger(getClass());
/*     */ 
/*     */   
/*  81 */   private static String[] mobileGateWayHeaders = new String[] { "ZXWAP", "chinamobile.com", "monternet.com", "infoX", "XMS 724Solutions HTG", "wap.lizongbo.com", "Bytemobile" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   private static String[] pcHeaders = new String[] { "Windows 98", "Windows ME", "Windows 2000", "Windows XP", "Windows NT", "Ubuntu" };
/*     */ 
/*     */   
/* 104 */   private static String[] mobileUserAgents = new String[] { "Nokia", "SAMSUNG", "MIDP-2", "CLDC1.1", "SymbianOS", "MAUI", "UNTRUSTED/1.0", "Windows CE", "iPhone", "iPad", "Android", "BlackBerry", "UCWEB", "ucweb", "BREW", "J2ME", "YULONG", "YuLong", "COOLPAD", "TIANYU", "TY-", "K-Touch", "Haier", "DOPOD", "Lenovo", "LENOVO", "HUAQIN", "AIGO-", "CTC/1.0", "CTC/2.0", "CMCC", "DAXIAN", "MOT-", "SonyEricsson", "GIONEE", "HTC", "ZTE", "HUAWEI", "webOS", "GoBrowser", "IEMobile", "WAP2.0" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void outJson(HttpServletResponse response, BaseEnum code, boolean flag, String msg, Object data) {
/*     */     try {
/* 195 */       response.setContentType("application/json;charset=utf-8");
/* 196 */       ResultJson result = new ResultJson();
/* 197 */       if (code != null) {
/* 198 */         result.setCode(code.toString());
/*     */       }
/* 200 */       result.setResult(flag);
/* 201 */       result.setResultMsg(msg);
/* 202 */       result.setResultData(data);
/* 203 */       response.setCharacterEncoding("utf-8");
/* 204 */       PrintWriter out = response.getWriter();
/* 205 */       out.print(JSONObject.toJSON(result));
/* 206 */       out.flush();
/* 207 */       out.close();
/* 208 */     } catch (IOException e) {
/* 209 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   protected void outJson(HttpServletResponse response, BaseEnum code, boolean flag, String msg) { outJson(response, code, flag, msg, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 242 */   protected void outJson(HttpServletResponse response, boolean flag, String msg) { outJson(response, null, flag, msg, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 256 */   protected void outJson(HttpServletResponse response, BaseEnum code, boolean flag) { outJson(response, code, flag, null, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 268 */   protected void outJson(HttpServletResponse response, boolean flag) { outJson(response, null, flag, null, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void outJson(HttpServletResponse response, Object jsonDataStr) {
/*     */     try {
/* 281 */       response.setContentType("application/json;charset=utf-8");
/* 282 */       PrintWriter out = response.getWriter();
/* 283 */       out.print(jsonDataStr);
/* 284 */       out.flush();
/* 285 */       out.close();
/* 286 */     } catch (IOException e) {
/* 287 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 299 */   protected void outJson(HttpServletResponse response, BaseEntity entity) { outJson(response, JSONObject.toJSONString(entity)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 311 */   protected void outJson(HttpServletResponse response, List list) { outJson(response, JSONArray.toJSONString(list)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void outJson(HttpServletResponse response, List list, String... filters) {
/* 321 */     PropertyFilter filter = new PropertyFilter() {
/*     */         public boolean apply(Object source, String name, Object value) {
/* 323 */           List<String> list = Arrays.asList(filters);
/* 324 */           if (list.contains(name)) {
/* 325 */             return false;
/*     */           }
/* 327 */           return true;
/*     */         }
/*     */       };
/* 330 */     SerializeWriter sw = new SerializeWriter();
/* 331 */     JSONSerializer serializer = new JSONSerializer(sw);
/* 332 */     serializer.getPropertyFilters().add(filter);
/* 333 */     serializer.write(list);
/* 334 */     outJson(response, sw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void outJson(HttpServletResponse response, Object obj, String... filters) {
/* 344 */     PropertyFilter filter = new PropertyFilter() {
/*     */         public boolean apply(Object source, String name, Object value) {
/* 346 */           List<String> list = Arrays.asList(filters);
/* 347 */           if (list.contains(name)) {
/* 348 */             return false;
/*     */           }
/* 350 */           return true;
/*     */         }
/*     */       };
/* 353 */     SerializeWriter sw = new SerializeWriter();
/* 354 */     JSONSerializer serializer = new JSONSerializer(sw);
/* 355 */     serializer.getPropertyFilters().add(filter);
/* 356 */     serializer.write(obj);
/* 357 */     outJson(response, sw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 372 */   protected void outJson(HttpServletResponse response, List list, String dateFmt) { outJson(response, JSONArray.toJSONStringWithDateFormat(list, dateFmt, new com.alibaba.fastjson.serializer.SerializerFeature[0])); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 383 */   protected void redirect(HttpServletResponse response, String path) { outString(response, "<script>location.href='" + path + "'</script>"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void outString(HttpServletResponse response, Object dataStr) {
/*     */     try {
/* 396 */       response.setContentType("text/html;charset=utf-8");
/* 397 */       PrintWriter out = response.getWriter();
/* 398 */       out.print(dataStr);
/* 399 */       out.flush();
/* 400 */       out.close();
/* 401 */     } catch (IOException e) {
/* 402 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getUrl(HttpServletRequest request) {
/* 414 */     String path = request.getContextPath();
/* 415 */     String basePath = request.getScheme() + "://" + request.getServerName();
/* 416 */     if (request.getServerPort() == 80) {
/* 417 */       basePath = basePath + path;
/*     */     } else {
/* 419 */       basePath = basePath + ":" + request.getServerPort() + path;
/*     */     } 
/* 421 */     return basePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDomain(HttpServletRequest request) {
/* 432 */     String path = request.getContextPath();
/* 433 */     String domain = request.getServerName();
/* 434 */     if (request.getServerPort() == 80) {
/* 435 */       domain = domain + path;
/*     */     } else {
/* 437 */       domain = domain + ":" + request.getServerPort() + path;
/*     */     } 
/* 439 */     return domain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getHost(HttpServletRequest request) {
/* 450 */     String basePath = request.getServerName();
/* 451 */     if (request.getServerPort() != 80) {
/* 452 */       basePath = basePath + ":" + request.getServerPort();
/*     */     }
/* 454 */     return basePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getHostIp() {
/*     */     try {
/* 465 */       InetAddress addr = InetAddress.getLocalHost();
/* 466 */       return addr.getHostAddress().toString();
/* 467 */     } catch (UnknownHostException e) {
/*     */       
/* 469 */       e.printStackTrace();
/*     */       
/* 471 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 482 */   protected String getResString(String key) { return Const.RESOURCES.getString(key); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getResString(String key, ResourceBundle rb) {
/*     */     try {
/* 496 */       return rb.getString(key);
/* 497 */     } catch (MissingResourceException e) {
/* 498 */       return Const.RESOURCES.getString(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getResString(String key, String... fullStrs) {
/* 512 */     String temp = getResString(key);
/* 513 */     for (int i = 0; i < fullStrs.length; i++) {
/* 514 */       temp = temp.replace("{" + i + "}", fullStrs[i]);
/*     */     }
/* 516 */     return temp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getResString(String key, ResourceBundle rb, String... fullStrs) {
/* 529 */     String temp = "";
/*     */     try {
/* 531 */       temp = rb.getString(key);
/* 532 */     } catch (MissingResourceException e) {
/* 533 */       temp = getResString(key);
/*     */     } 
/* 535 */     for (int i = 0; i < fullStrs.length; i++) {
/* 536 */       temp = temp.replace("{" + i + "}", fullStrs[i]);
/*     */     }
/* 538 */     return temp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMobileDevice(HttpServletRequest request) {
/* 549 */     boolean b = false;
/* 550 */     boolean pcFlag = false;
/* 551 */     boolean mobileFlag = false;
/* 552 */     String via = request.getHeader("Via");
/* 553 */     String userAgent = request.getHeader("user-agent");
/* 554 */     for (int i = 0; via != null && !via.trim().equals("") && i < mobileGateWayHeaders.length; i++) {
/* 555 */       if (via.contains(mobileGateWayHeaders[i])) {
/* 556 */         mobileFlag = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 560 */     int i = 0;
/* 561 */     for (; !mobileFlag && userAgent != null && !userAgent.trim().equals("") && i < mobileUserAgents.length; i++) {
/* 562 */       if (userAgent.contains(mobileUserAgents[i])) {
/* 563 */         mobileFlag = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 567 */     for (int i = 0; userAgent != null && !userAgent.trim().equals("") && i < pcHeaders.length; i++) {
/* 568 */       if (userAgent.contains(pcHeaders[i])) {
/* 569 */         pcFlag = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 573 */     if (mobileFlag == true && !pcFlag) {
/* 574 */       b = true;
/*     */     }
/* 576 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, String> getMapByProperties(String filePath) {
/* 586 */     if (StringUtils.isBlank(filePath)) {
/* 587 */       return null;
/*     */     }
/* 589 */     ResourceBundle rb = ResourceBundle.getBundle(filePath);
/* 590 */     return getMapByProperties(rb);
/*     */   }
/*     */   
/*     */   protected Map<String, String> getMapByProperties(ResourceBundle rb) {
/* 594 */     Map<String, String> map = new HashMap<>();
/* 595 */     Enumeration<String> en = rb.getKeys();
/* 596 */     while (en.hasMoreElements()) {
/* 597 */       String key = en.nextElement();
/* 598 */       map.put(key, rb.getString(key));
/*     */     } 
/* 600 */     return map;
/*     */   }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\base\action\BaseAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */