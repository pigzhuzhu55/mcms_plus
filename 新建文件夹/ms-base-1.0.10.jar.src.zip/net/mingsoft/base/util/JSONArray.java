/*    */ package net.mingsoft.base.util;
/*    */ 
/*    */ import com.alibaba.fastjson.JSONArray;
/*    */ import com.alibaba.fastjson.serializer.SerializeFilter;
/*    */ import com.alibaba.fastjson.serializer.SerializerFeature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JSONArray
/*    */ {
/* 45 */   public static final String toJSONString(Object object, SerializeFilter... filters) { return JSONArray.toJSONString(object, filters, new SerializerFeature[] { SerializerFeature.WriteMapNullValue }); }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\bas\\util\JSONArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */