/*     */ package net.mingsoft.base.util;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertiesUtil
/*     */ {
/*     */   public static String get(String properties, String key) throws IOException {
/*  47 */     InputStream in = PropertiesUtil.class.getClassLoader().getResourceAsStream(properties);
/*  48 */     Properties props = new Properties();
/*  49 */     props.load(in);
/*  50 */     String value = props.getProperty(key);
/*     */     
/*  52 */     in.close();
/*  53 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, String> getMap(String properties) throws FileNotFoundException, IOException {
/*  65 */     Map<String, String> map = new HashMap<>();
/*  66 */     InputStream in = PropertiesUtil.class.getClassLoader().getResourceAsStream(properties);
/*  67 */     Properties props = new Properties();
/*  68 */     props.load(in);
/*  69 */     Enumeration<?> en = props.propertyNames();
/*  70 */     while (en.hasMoreElements()) {
/*  71 */       String key = (String)en.nextElement();
/*  72 */       String Property = props.getProperty(key);
/*  73 */       map.put(key, Property);
/*     */     } 
/*  75 */     in.close();
/*  76 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String properties, String key, String value) throws IOException {
/*  91 */     Properties prop = new Properties();
/*  92 */     InputStream fis = new FileInputStream(PropertiesUtil.class.getClassLoader().getResource(properties).getPath());
/*     */     
/*  94 */     prop.load(fis);
/*     */ 
/*     */ 
/*     */     
/*  98 */     OutputStream fos = new FileOutputStream(PropertiesUtil.class.getClassLoader().getResource(properties).getPath());
/*  99 */     prop.setProperty(key, value);
/*     */ 
/*     */     
/* 102 */     prop.store(fos, "last update");
/*     */     
/* 104 */     fis.close();
/* 105 */     fos.close();
/*     */   }
/*     */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\bas\\util\PropertiesUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */