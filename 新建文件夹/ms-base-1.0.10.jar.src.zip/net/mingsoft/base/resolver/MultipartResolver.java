/*    */ package net.mingsoft.base.resolver;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.springframework.web.multipart.commons.CommonsMultipartResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultipartResolver
/*    */   extends CommonsMultipartResolver
/*    */ {
/*    */   private String excludeUrls;
/*    */   private String[] excludeUrlArray;
/*    */   
/* 39 */   public String getExcludeUrls() { return this.excludeUrls; }
/*    */   
/*    */   public void setExcludeUrls(String excludeUrls) {
/* 42 */     this.excludeUrls = excludeUrls;
/* 43 */     this.excludeUrlArray = excludeUrls.split(",");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isMultipart(HttpServletRequest request) {
/* 53 */     for (String url : this.excludeUrlArray) {
/*    */       
/* 55 */       if (request.getRequestURI().contains(url)) {
/* 56 */         return false;
/*    */       }
/*    */     } 
/* 59 */     return super.isMultipart(request);
/*    */   }
/*    */ }


/* Location:              D:\User\Maven\repository\net\mingsoft\ms-base\1.0.10\ms-base-1.0.10.jar!\net\mingsoft\base\resolver\MultipartResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */